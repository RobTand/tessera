#!/usr/bin/env python
"""Export a dense checkpoint as Tessera wires for Tessera's own vLLM plugin.

SUPPORTED ENTRY POINT (tessera#687): ``python -m tessera.export_serving``.
The historical ``experiments/export_tessera_serving.py`` path is a shim that
imports this module.

THREE FAMILIES, ONE PLUGIN.  ``tessera.serving.scheme`` names a family by the
stock tile a module decodes to: ``TESSERA_NVFP4`` (an E2M1-based grid over the
LUT plane, span-2 TCQ body -> the NVFP4 tile, W4A4), ``TESSERA_FP8`` (the
E4M3 grid over the CHANNEL plane, window body -> the per-channel FP8 pair,
W8A8), or ``TESSERA_BF16`` (the BF16 grid over the CHANNEL plane, window body
-> a plain bfloat16 tile, W16A16).  ``--grid``/``--q256`` set the default per
Linear and ``--plan-json`` overrides it per tensor, so one checkpoint may
carry all three and a single serve executes each on its own path: that is the
product an allocator targets.  The 16-bit route exists because the E4M3
*alphabet* -- not the trellis -- floors the window body's error from R=6
upward, so above ~6 bpp an 8-bit tile has nothing left to buy
(``docs/measurements/tessera-bf16-route-2026-09-02.md``).

ALL THREE HAVE A PLUGIN ROUTE.  ``TESSERA_BF16`` was the exception until #9:
``serving/bf16_route.py`` decodes its window body to a plain bfloat16 tile in
both residency modes, ``runtime_contract.json`` v5 attests q256 1792 on
sm_121, and ``--grid BF16`` needs no override.  The ``--stock-twin`` of a BF16
arm is still worth writing -- it is the control the route is measured against,
and the served pair is in the receipt above -- but it is no longer the only
thing that arm can serve.

WHAT THIS SCRIPT MAY WRITE IS WHAT THE PLUGIN PUBLISHES A DECODE FOR.
``check_recipe`` gates the default ``(grid, q256)`` and every ``--plan-json``
override against the packaged ``runtime_contract.json`` before the first
encode, so a wire the pinned runtime cannot read is refused at export rather
than at load (#41).  The encoder is untouched: ``wire_recipe`` still writes
the sub-cap window body and every research encode of it still runs.  What a
served ROUTED stack carries is a spelling above it -- ``served_recipe``
promotes every NVFP4 rung to the span-2 TCQ body the routed path decodes, for
``STRUCTURE_ROUTED_MOE`` only, because a sub-cap rung served through the
WINDOW recipe would be unreadable by the one decoder that path has; a DENSE
module keeps the ``wire_recipe`` spelling (WINDOW below the cap), which the
route refuses at export (tessera#560 D2b).  That promotion is necessary and
measured-worse (TCQ span-2 at
1.36-1.43x EXL3 at 2.5-3.5 bpp against window L=12 at 1.06-1.10x,
``docs/tessera-one-format.md`` §4); ``served_recipe``'s docstring states both.
The override is ``--allow-unserveable``, and it is stamped into the manifest.

The checkpoint declares ``quantization_config.quant_method: "tessera"``, which
is what selects the plugin: there is no serve flag to enable it, only
``TESSERA_SERVE_MODE`` to declare the residency.

ONE BLOB PER vLLM MODULE.  Every role a vLLM fusion stacks (q/k/v, gate/up)
is encoded as its own Tessera unit and framed into a ``tessera.fused``
container in stacking order; unfused Linears are a one-member container.  A
fused module's roles must share one family -- vLLM builds one method per
module -- and with it the grid, body and scale plane that method's route
decodes (``module_scheme_key``).  They need NOT share a RATE: every decoder in
``tessera.serving`` reads a role from that role's own manifest, so a fused
group whose members took different rungs is written as one container with a
per-role ``q256`` list in its scheme, and the runtime publishes that rule as a
value a producer's group allocator reads (``runtime_contract.json``'s
``fused_module``, contract v6, #37).  An NVFP4 module's roles are additionally
checked at export for the exact binade shift the lane applies at load
(``shared_lut_global``), so an unserveable group is refused here, not there.

THE STOCK TWIN.  ``--stock-twin DIR`` also writes the materialisation of the
SAME wires (``tessera.stock.materialize_stock``; NVFP4 groups moved onto one
shared global) that vanilla vLLM serves with no plugin, so a served
comparison is between one encode and its two servings rather than between two
encodes.  A BF16 module's twin tensor is a plain ``<module>.weight`` bfloat16
tile and rides no config group; a twin all of whose modules are BF16 carries
**no** ``quantization_config`` at all, because it is then an ordinary BF16
checkpoint and declaring one would only invite a runtime to look for
tensors that are not there.

The manifest states what is on disk and what the plugin holds resident per
mode.  ``lm_head`` and the embeddings stay BF16 (PrismaQuant's body-only
convention); a Linear whose rows are not a whole number of tuples, or a
fused module not all of whose roles are quantizable, is passed through as
BF16 and named in ``ignore``.  Naming it there is not bookkeeping: the plugin
REFUSES a Linear that is neither declared nor ignored, so one mistyped target
is a refusal rather than a silently BF16 artifact.  The naming follows the
tensors WRITTEN, not the tensors the body pattern matched
(``ignored_modules``), so a Linear outside the decoder body -- a vision tower,
an MTP sidecar -- is named too.

THE ARTIFACT IS TENSOR-PARALLELISM-AGNOSTIC, and this exporter never encodes
per rank.  One whole unit per role is written once; a serve with tp_size > 1
loads the whole unit on every rank and cuts it at load
(``tessera.serving.sharding``), so the same checkpoint serves any TP degree and
re-sharding is a serve flag rather than a re-export.  Encoding per rank would
make the bytes a function of the machine they were built for, and a unit cut
for 4 ranks could not be re-cut for 8.  Pricing is the one place the rank
enters: a routed FP8/BF16 stack's ``resident_bytes_resident_mode`` is what
the compact window lane holds for the WHOLE stack (its repacked planes,
tables, permutations and bookkeeping plus the fused lane's composed tables,
run pairs and block descriptors where the shape admits them; never a decoded
tile, which that lane does not allocate -- tessera#624), and
``totals.per_rank`` (``--fit-tp-size``) prices
each rank's cut of every routed stack beside the MTP draft's embed/head
duplicate as its own line item (tessera#645).

ROUTED-MoE EXPERTS ARE EXPORTED FROM AN EXPLICIT SOURCE LAYOUT, and the
executed module is the STACK. A ``--plan-json`` entry keyed ``<moe>.experts``
sets its baseline rung and may override individual projections via ``unit_q256``; the
exporter writes ONE ``tessera.fused`` container per expert per PROJECTION under
``<moe>.experts.{e}.{proj}.wire`` and declares one ``config_groups`` entry with
``structure: "routed_moe"``, the two groups ``w13`` (gate then up, the row order
``RoutedExperts._load_w13`` narrows to) and ``w2``, and a per-group
``wire_stride``.  The stride is the MAXIMUM over the group's blobs, derived here
rather than passed in, because the blob length follows the data (the manifest's
exact-ratio ``global_scale`` rides as a varint whose width follows its value)
and ``moe_layout.unpack_moe_wires`` refuses a stride that is not what the
loaded lengths imply.  The consumer is ``tessera.serving.moe_route``, which
decodes those containers into vLLM's stock per-channel FP8 expert parameters
and runs the runtime's own fused-MoE kernel.

Everything about a stack is refused BEFORE the first encode
(``plan_expert_stack``): a family with no expert route
(``scheme.MOE_BUILDERS``), an expert index set that is not ``0..E-1``, a
missing projection, geometry that differs across experts, and rows or columns
the route's mainloop cannot take.  A dense Linear that fails the last of those
is passed through -- safe, because it is one module; a routed stack cannot be
half passed through, because vLLM builds ONE method for the whole stack.  The
construction gate runs on the stack name too: the census receipt's
``offered_non_linear`` row is what says the runtime asks this plugin about
``...mlp.experts`` at all.

Not planning a stack leaves it where it was -- source precision, named in
``ignore`` at the ``FusedMoE`` prefix -- so every checkpoint written before
this is byte-identical under the same command line.

THE PACKED 3-D SOURCE LAYOUT (``mlp.experts.gate_up_proj``,
``...down_proj``) is accepted only when the stack's plan states one of two
closed conventions: ``out_first_chunked`` means ``[E, 2N, K]`` with gate then
up and ``[E, K, N]`` down; ``in_first_interleaved`` means ``[E, K, 2N]`` with
gate/up alternating and ``[E, N, K]`` down.  The exporter checks those exact
shapes against config.json, slices them into canonical per-expert matrices,
and stamps the source convention on the scheme and every manifest role.  It
never infers a convention from dimensions: ``hidden_size == 2 *
moe_intermediate_size`` makes a gate/up source square, while dimensions never
state chunked versus interleaved.  Missing or invented conventions therefore
refuse before encoding.  ``quantizable`` separates both layouts from the 2-D
body, and an unplanned stack of either kind passes through at source precision
named in ``ignore``.  The grouping rule that a fused module's roles must share
one family holds for experts exactly as it does for q/k/v: vLLM builds one
method per module.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
from fractions import Fraction
from pathlib import Path

import torch
from safetensors import safe_open
from safetensors.torch import save_file

from tessera.stock import (  # noqa: E402
    FP8_INPUTS, FP8_WEIGHTS, NVFP4_INPUTS, NVFP4_WEIGHTS, regex_target,
    stock_quantization_config)
from tessera import producer_authority as producer_authority_option  # noqa: E402
from tessera.cached_unit import CachedUnitIdentity, HESSIAN_IDENTITY_MODES  # noqa: E402
from tessera.alphabet import (  # noqa: E402
    BF16_GRID, E2M1_GRID, E4M3_GRID, tuple_grid)
from tessera.bf16_route import BF16_FAMILY  # noqa: E402
from tessera.container import SCHEMA_MINOR  # noqa: E402
from tessera.layout import tp_agnostic_at_minor  # noqa: E402
from tessera.manifest import body_rate_cap  # noqa: E402
from tessera.export import (  # noqa: E402
    DEFAULT_CODE, DEFAULT_LDLQ_BLOCK, DEFAULT_LDLQ_SIGMA,
    ActivationSource, encode_linear_planes, encode_linears_planes, served_recipe)
from tessera.fused import pack_fused, shared_input_global_scale, shared_lut_global  # noqa: E402
from tessera.serving.contract import (  # noqa: E402
    PAYLOAD_FAMILY_BY_ROUTE, cell_covers_rung, classify_construction, construction_entry,
    format_entry, load_serving_contract, output_partitions)
from tessera.serving.dense_ownership import (  # noqa: E402
    FUSED, fused_module as _fused_module, partition_members, source_padding_rows)
from tessera.serving.scheme import (  # noqa: E402
    MOE_GROUP_PROJECTIONS, MOE_GROUPS,
    MOE_SHARD_PROJECTIONS as SHARD_PROJECTION, STRUCTURE_DENSE,
    STRUCTURE_ROUTED_MOE, MOE_SOURCE_IN_FIRST_INTERLEAVED,
    MOE_SOURCE_OUT_FIRST_CHUNKED, MOE_SOURCE_UNPACKED,
    attested_cells, refuse_a_family_with_no_expert_route, refuse_unreachable_lane,
    refuse_unserveable_wire, validate_tessera_moe_scheme)
from tessera.stock import (  # noqa: E402
    FLOAT_QUANTIZED, MIXED_PRECISION, NVFP4_PACK_QUANTIZED, materialize_stock,
    share_global, stock_bytes, vllm_fp4_predicate)
from tessera.unit_artifact import parse_unit_artifact  # noqa: E402
from tessera.decode import replay_table_bytes  # noqa: E402
from tessera.serving_parts import (  # noqa: E402
    BODY_LAYER, SCHEMA as PART_SCHEMA, dense_resident_bytes_resident_mode, export_identity,
    exporter_code_root, git_hash,
    mtp_draft_embed_head_duplicate_bytes, parse_partition, make_artifact_readable,
    partition_owner, per_rank_fit_items, require_json, routed_fused_unit_bytes,
    routed_window_part_resident_bytes, routed_window_unit_resident_bytes, sha256_file,
    summarize_modules, validate_explicit_plan, write_serving_manifest)
from tessera.serving_plan import (  # noqa: E402
    SERVING_PLAN_SCHEMA, family_for, module_scheme_key, validate_serving_plan)


def save_serving_shard(payload: dict, destination: Path) -> None:
    """Publish complete, host-readable main/twin bytes in one rename (#366)."""
    descriptor, temporary = tempfile.mkstemp(prefix=f".{destination.name}.",
                                             suffix=".partial", dir=destination.parent)
    os.close(descriptor)
    staging = Path(temporary)
    try:
        save_file({key: value.contiguous() for key, value in payload.items()},
                  str(staging), metadata={"format": "pt"})
        make_artifact_readable(staging)
        staging.replace(destination)
    finally:
        staging.unlink(missing_ok=True)


#: A body Linear, and WHICH decoder layer it belongs to.  Not
#: ``startswith("model.layers.")``: a multimodal checkpoint roots its decoder
#: under a sub-model (GLM-5.3-Flash is ``model.language_model.layers.N.``), and
#: the prefix test silently found NOTHING there -- an "export" that quantized
#: zero Linears and reported success.  The vision tower is ``model.visual.
#: blocks.N.``, which this does not match, so it stays BF16 -- and is named in
#: ``ignore`` by ``ignored_modules``, which runs over the tensors WRITTEN rather
#: than over the ones this pattern matched.  Staying BF16 and being named are
#: different facts and the plugin reads the second one (#86).
# BODY_LAYER is shared with the whole-layer partition ownership rule.

#: GLM writes descriptive names; LFM writes shard ids. The shared scheme
#: table normalises both, while the emitted wire retains the source spelling
#: so the model's own FusedMoE mapping can hand it the shard id.
EXPERT_SOURCE_PROJECTIONS = tuple(
    dict.fromkeys((*SHARD_PROJECTION.values(), *SHARD_PROJECTION.keys())))

#: A ROUTED expert leaf in the unpacked (per-expert 2-D) source layout.  The
#: ``\d+`` segment is load-bearing: it is what distinguishes a routed expert
#: from ``mlp.shared_experts.gate_proj``, which is an ordinary dense Linear and
#: is quantized as one.  The owner is named ``mlp`` by GLM and ``feed_forward``
#: by LFM; its source projections are respectively gate/up/down and w1/w3/w2.
#: The MoE owner's two spellings, in ONE place: every MoE pattern below
#: interpolates this, so a third spelling is one edit rather than three.
MOE_OWNER = r"(?:mlp|feed_forward)"

ROUTED_EXPERT_2D = re.compile(
    rf"^(?P<moe>.*\.{MOE_OWNER})\.experts\.(?P<expert>\d+)\."
    rf"(?P<proj>{'|'.join(map(re.escape, EXPERT_SOURCE_PROJECTIONS))})\.weight$")

# Routers stay at source precision unless a plan selects them explicitly.
# The construction census must offer the selected GateLinear route.
MOE_ROUTER = re.compile(
    rf"^(?P<moe>.*\.{MOE_OWNER})\.(?:gate|router)\.weight$")

#: A PACKED expert stack: one rank-3 tensor holding every expert of a layer.
#: Rank alone does NOT identify one -- GLM-5.3-Flash's attention carries
#: ``k_conv1d.weight [8192, 1, 4]``, and treating that as an expert stack put
#: ``...self_attn`` (the whole attention block, every Linear in it) into the
#: checkpoint's ``ignore`` list.  A tensor is a packed expert stack because of
#: where it sits, not because it has three axes.
#:
#: THE SUFFIX IS NOT WHAT MAKES A STACK, so callers match this pattern against
#: the name in its ``.weight`` spelling rather than against the name as it sits
#: on disk.  transformers-5 stores a packed stack as an ``nn.Parameter`` on the
#: experts module rather than as a child Linear's ``weight``, so the tensor on
#: disk is ``...mlp.experts.gate_up_proj`` with no suffix at all -- 98 of them
#: on ``/mnt/shared/models/Qwen3.8-Flash-Next``, the one packed-source
#: checkpoint on this box (96 decoder-body stacks plus two MTP-sidecar stacks
#: outside ``BODY_LAYER``).  ``quantizable`` used to require the suffix before
#: it looked at anything, so those tensors were classified as NOTHING and no
#: plan-time refusal could name them; ``ignored_modules`` reads them through
#: the same probe (#86).  ``packed_expert_orientation`` already read both
#: spellings, which is how far the inconsistency reached before it was found.
PACKED_EXPERT_ND = re.compile(
    rf"^(?P<moe>.*\.{MOE_OWNER})\.experts\.(?P<proj>gate_up_proj|down_proj|gate_proj|up_proj)\.weight$")

#: A module vLLM builds under a SECOND name, beside the checkpoint's spelling.
#: Not a taste and not a guess: CONSTRUCTED on the pinned build
#: ``prismaquant/glm53-mia-sm121:487ecf187`` with a recording quant config, the
#: GLM vision tower offers ``visual.blocks.N.attn.qkv_proj`` -- because
#: ``Glm5NextVisionAttention`` builds its projection at
#: ``f"{prefix}.qkv_proj" if quant_config else f"{prefix}.qkv"``
#: (``models/glm5next/nvidia/multimodal.py:167``) -- while the tensor on disk is
#: ``...attn.qkv.weight`` and the module ATTRIBUTE path is ``...attn.qkv``.  The
#: run, its script and its verbatim output are
#: ``docs/measurements/glm53-vision-tower-prefixes-2026-09-03.md``.
#: Which name exists depends on whether that runtime
#: passes a quant config, which the producer cannot know; an ignore entry is
#: only ever LOOKED UP or prefix-mapped -- never silently dropped, since
#: ``TesseraConfig.apply_vllm_mapper`` refuses a name the mapper maps away --
#: so carrying both spellings costs nothing and carrying
#: one is a load-time refusal in whichever world the runtime turns out to be
#: in.  Body attention never reaches here: its q/k/v arrive unmerged and the
#: FUSED table already names ``qkv_proj``.
MERGED_ALIASES = ((re.compile(r"^(.*\.)qkv\.weight$"), "qkv_proj"),)
VISION_LINEAR = re.compile(
    r"^model\.visual\.(?:blocks\.\d+\.(?:attn\.(?:qkv|proj)|mlp\.(?:gate_proj|up_proj|down_proj))"
    r"|merger\.(?:proj|gate_proj|up_proj|down_proj))\.weight$")

NVFP4 = "TESSERA_NVFP4"
FP8 = "TESSERA_FP8"
BF16 = BF16_FAMILY


# --------------------------------------------------------------------------
# THE SELECTED PRODUCER (TESSERA_PRODUCER_PYTHON / TESSERA_PRODUCER_SOURCE).
#
# A partition producer that claims a genuine lineage names its interpreter and
# its source; this module authenticates both BEFORE any source or output
# operation, and seals the receipt into the partition identity.  The three
# facts the receipt binds are each proved, never asserted: the interpreter by
# exact path (different environments share one resolved binary, so the file
# alone proves nothing), the source by its checkout's own Git object store --
# clean at a HEAD that descends from the genuine ancestor -- and the bytes by
# a projection to exactly the payload a wheel built from that packaging
# config ships, equal to the installed distribution the selected interpreter
# actually imported.  No environment claim (``TESSERA_GIT`` least of all)
# substitutes for any of it.

PRODUCER_PYTHON = "TESSERA_PRODUCER_PYTHON"
PRODUCER_SOURCE = "TESSERA_PRODUCER_SOURCE"
PRODUCER_RECEIPT_SCHEMA = "tessera.producer_python.v1"
GENUINE_PRODUCER_ANCESTOR = "b770727c50eef822132518bdc4fd6efe84359c9e"


def _git_proof(directory: Path, *args: str) -> str:
    """A git answer from the source reference's own object store, or a refusal."""
    done = subprocess.run(["git", "-C", str(directory), *args],
                          capture_output=True, text=True)
    if done.returncode != 0:
        raise SystemExit(
            f"{PRODUCER_SOURCE}: {directory} is not a usable Git checkout "
            f"(git {' '.join(args[:2])} failed: {done.stderr.strip()[:300] or done.returncode}); "
            "a selected producer's source reference is proved from its checkout's "
            "object store, and no environment claim substitutes for it")
    return done.stdout


def _source_package_dir(named: Path) -> Path:
    """The package directory the source reference names.

    Wrappers provide ``checkout/src/tessera``; a checkout root that holds
    ``src/tessera`` is accepted in the same spelling.  Anything else is
    refused by variable name rather than guessed at.
    """
    if (named / "serving").is_dir():
        return named
    if (named / "src" / "tessera" / "serving").is_dir():
        return named / "src" / "tessera"
    raise SystemExit(
        f"{PRODUCER_SOURCE}: {named} is neither a tessera package directory "
        "(holding serving/) nor a checkout root (holding src/tessera/)")


def _require_clean_head(package_dir: Path) -> None:
    """The package's tracked files are HEAD's, and no untracked file joins them.

    A dirty clone cannot claim its HEAD commit: the expected payload is
    hashed from the worktree precisely because this check proved those bytes
    ARE the committed ones.
    """
    status = subprocess.run(
        ["git", "-C", str(package_dir), "status", "--porcelain=v1",
         "--untracked-files=all", "--", "."],
        capture_output=True, text=True)
    if status.returncode != 0:
        raise SystemExit(f"{PRODUCER_SOURCE}: git status failed in {package_dir}: "
                         f"{status.stderr.strip()[:300]}")
    dirty = [line for line in status.stdout.splitlines() if line.strip()]
    if dirty:
        raise SystemExit(
            f"{PRODUCER_SOURCE}: {package_dir} is dirty at HEAD ({len(dirty)} "
            f"modified or untracked file(s), e.g. {dirty[:3]}). A source "
            "reference must be clean at its HEAD, so its committed content -- "
            "not merely its ancestry -- is what the projection digests.")


def _git_archive_files(checkout_root: Path, paths: "list[str]") -> "dict[str, bytes]":
    """The HEAD-tree bytes of ``paths``, one ``git archive`` pass, or a refusal.

    The expected payload is read from the OBJECT STORE, never the worktree:
    assume-unchanged and skip-worktree can conceal tracked edits from a
    status check, and the committed bytes are what a receipt may bind.
    """
    done = subprocess.run(
        ["git", "-C", str(checkout_root), "archive", "HEAD", "--", *paths],
        capture_output=True)
    if done.returncode != 0:
        raise SystemExit(
            f"{PRODUCER_SOURCE}: reading {paths[:2]} from the HEAD tree of "
            f"{checkout_root} failed: {done.stderr.decode().strip()[:300]}")
    import io
    import tarfile

    with tarfile.open(fileobj=io.BytesIO(done.stdout)) as tar:
        return {member.name: tar.extractfile(member).read()
                for member in tar.getmembers() if member.isfile()}


def _expected_payload(checkout_root: Path, package_dir: Path) -> "dict[str, bytes]":
    """The committed package, projected to what a wheel built here ships.

    ``tessera._dev`` is repository tooling and no wheel carries it; the
    packaging owners decide, via the projection owner -- which speaks
    checkout-relative names, so the tracked paths are passed in that
    spelling and the answer normalised back to package-relative.  Every
    byte, the packaging config included, comes from the HEAD tree's objects.
    """
    from tessera.source_profiles import packaged_projection_config, shipped_payload_paths

    packaged = _git_archive_files(checkout_root, ["pyproject.toml"])
    if "pyproject.toml" not in packaged:
        raise SystemExit(
            f"{PRODUCER_SOURCE}: HEAD of {checkout_root} carries no pyproject.toml; "
            "the shipped-payload projection is derived from the committed packaging "
            "owners, and a commit without them projects nothing")
    config = packaged_projection_config(packaged["pyproject.toml"])
    listing = _git_proof(checkout_root, "ls-tree", "-r", "--name-only", "-z", "HEAD")
    tracked = [path for path in listing.split("\0") if path]
    prefix = package_dir.relative_to(checkout_root).as_posix() + "/"
    under_package = [path for path in tracked if path.startswith(prefix)]
    if not under_package:
        raise SystemExit(
            f"{PRODUCER_SOURCE}: HEAD of {checkout_root} carries no package under "
            f"{prefix}; a source reference must name the genuine checkout's package")
    # The owner's answer is where-root-relative ("tessera/x.py"); the payload
    # is package-relative ("x.py").
    shipped = shipped_payload_paths(config, under_package)
    wanted = [f"{prefix}{name.split('/', 1)[1]}" for name in shipped]
    files = _git_archive_files(checkout_root, wanted)
    absent = sorted(set(wanted) - set(files))
    if absent:
        raise SystemExit(
            f"{PRODUCER_SOURCE}: the packaging config projects {absent[:3]} but "
            f"HEAD's tree does not carry them under {prefix}")
    return {name[len(prefix):]: files[name] for name in wanted}


def _installed_payload() -> "tuple[Path, dict[str, bytes]]":
    """The tessera the selected interpreter actually imported, as an install.

    The import must come from the selected interpreter's INSTALLED
    distribution -- ``importlib.metadata`` restricted to the holder of the
    imported package, and ``locate_file`` demonstrating that this is the
    payload that distribution provides.  A sys.path insert (the legacy
    experiments shim, or an inherited PYTHONPATH) has no distribution behind
    it and is refused by variable name whatever its bytes say.
    """
    import tessera

    from importlib.metadata import distributions

    imported_init = Path(tessera.__file__).resolve()
    holder = imported_init.parents[1]
    distribution_name = getattr(tessera, "DISTRIBUTION", "tessera-quant")
    found = None
    for dist in distributions(path=[str(holder)]):
        if (dist.metadata.get("Name") or "").strip().lower() == distribution_name.lower():
            found = dist
            break
    if found is None:
        raise SystemExit(
            f"{PRODUCER_PYTHON}: the running interpreter imported tessera from "
            f"{holder}, which provides no installed {distribution_name} distribution. "
            "That is a sys.path/PYTHONPATH shadow (an experiments shim or an "
            "inherited environment), not the selected interpreter's install: "
            "run the exporter with ``python -m tessera.export_serving`` under the "
            "selected interpreter's installed distribution.")
    installed_init = Path(found.locate_file("tessera/__init__.py")).resolve()
    if installed_init != imported_init:
        raise SystemExit(
            f"{PRODUCER_PYTHON}: this process imported tessera from {imported_init}, "
            f"but the selected interpreter's installed {distribution_name} provides "
            f"{installed_init}. A PYTHONPATH override is not the installed payload, "
            "and the exporter never runs from one.")
    installed_pkg = installed_init.parent
    payload = {path.relative_to(installed_pkg).as_posix(): path.read_bytes()
               for path in sorted(installed_pkg.rglob("*"))
               if path.is_file() and "__pycache__" not in path.parts}
    return installed_pkg, payload


def _require_loaded_origins(installed_pkg: Path, payload: "dict[str, bytes]") -> None:
    """Every loaded tessera module comes from the authenticated payload.

    An installed ``tessera/__init__`` beside a submodule imported from
    elsewhere (an experiments shim inserting ``checkout/src``, an inherited
    PYTHONPATH) is a MIXED ORIGIN: the running code is not the payload the
    digest binds, however equal the bytes.  This exporter's own module is
    bound explicitly -- it is the code executing this check.
    """
    # Bind THIS executing module, including Python's real -m __main__.
    # Importing a canonical copy would authenticate different code.
    exporter = sys.modules.get(__name__)
    if exporter is None or getattr(exporter, "__file__", None) != __file__:
        raise SystemExit(f"{PRODUCER_PYTHON}: the executing exporter states no file origin")
    loaded = [(name, module) for name, module in sys.modules.items()
              if name == "tessera" or name.startswith("tessera.")]
    if __name__ != "tessera.export_serving":
        loaded.append((__name__, exporter))
    for name, module in sorted(loaded):
        # ``__file__`` is a file of the payload and is bound to it by
        # module-relative name; ``__path__`` entries are package DIRECTORIES
        # and are bound by containment alone.
        file = getattr(module, "__file__", None)
        if file is not None:
            origin = Path(file).resolve()
            if installed_pkg not in origin.parents:
                raise SystemExit(
                    f"{PRODUCER_PYTHON}: loaded module {name!r} comes from {origin}, "
                    f"outside the authenticated installed payload {installed_pkg}. A "
                    "mixed origin is a refusal: the running code is not the payload "
                    "the receipt binds.")
            relative = origin.relative_to(installed_pkg).as_posix()
            if relative not in payload:
                raise SystemExit(
                    f"{PRODUCER_PYTHON}: loaded module {name!r} is {relative}, which "
                    f"the authenticated payload of {installed_pkg} does not ship")
            continue
        paths = getattr(module, "__path__", None) or ()
        if not paths:
            raise SystemExit(
                f"{PRODUCER_PYTHON}: loaded module {name!r} states no file origin; "
                "a selected producer's modules must come from the authenticated "
                "installed payload")
        for path in paths:
            path = Path(path).resolve()
            if installed_pkg not in path.parents:
                raise SystemExit(
                    f"{PRODUCER_PYTHON}: loaded package {name!r} resolves at {path}, "
                    f"outside the authenticated installed payload {installed_pkg}")


def authenticate_producer_python(expected_package=None, *,
                                 descends_from: str = GENUINE_PRODUCER_ANCESTOR,
                                 ) -> "dict | None":
    """Authenticate the selected producer interpreter, or return ``None``.

    Reads ``TESSERA_PRODUCER_PYTHON`` in the real exporter, before any
    source or output operation.  With no selection the exporter keeps its
    existing behaviour and this returns ``None``; with one, every refusal
    names its variable, and the exporter never silently runs a different
    interpreter.  The receipt binds requested and actual interpreter, the
    executable's hash, ``sys.prefix``, the observed Python and torch of the
    producer process, the projected expected package digest and the actual
    installed digest (equal, and equal to the exact shipped roster a wheel
    built from the packaging config carries, with ``runtime_contract.json``
    proved byte-equal besides -- the source profiles cover code, not data),
    and the verified source commit with its ancestry.  ``descends_from``
    exists so tests can exercise the ancestry machinery on fixture trees;
    the exporter main passes the genuine reference.

    ``expected_package`` overrides the source reference's package directory
    for the projection; it does not relax any check.
    """
    selected = os.environ.get(PRODUCER_PYTHON)
    if not selected:
        return None
    if not os.path.isabs(selected):
        raise SystemExit(
            f"{PRODUCER_PYTHON}: {selected!r} is not an absolute executable path")
    if os.path.abspath(selected) != os.path.abspath(sys.executable):
        raise SystemExit(
            f"{PRODUCER_PYTHON}: selected {selected}, but this exporter is running "
            f"under {sys.executable}. Different environments share one resolved "
            "binary, so the resolved file alone proves nothing: the exporter never "
            "silently runs an interpreter other than the one selected.")
    source_named = os.environ.get(PRODUCER_SOURCE)
    if not source_named:
        raise SystemExit(
            f"{PRODUCER_SOURCE}: a selected producer ({selected}) requires "
            f"{PRODUCER_SOURCE} naming the genuine checkout (its src/tessera package)")
    source_dir = Path(source_named)
    if not source_dir.is_dir():
        raise SystemExit(f"{PRODUCER_SOURCE}: {source_named} is not a directory")
    package_dir = _source_package_dir(source_dir)
    _require_clean_head(package_dir)
    checkout_root = Path(_git_proof(package_dir, "rev-parse", "--show-toplevel").strip())
    head = _git_proof(package_dir, "rev-parse", "HEAD").strip()
    if not re.fullmatch(r"[0-9a-f]{40}", head):
        raise SystemExit(f"{PRODUCER_SOURCE}: HEAD of {checkout_root} is {head!r}, "
                         "not a 40-hex commit")
    ancestry = subprocess.run(
        ["git", "-C", str(package_dir), "merge-base", "--is-ancestor", descends_from, head],
        capture_output=True, text=True)
    if ancestry.returncode == 1:
        raise SystemExit(
            f"{PRODUCER_SOURCE}: HEAD {head} of {checkout_root} does not descend from "
            f"{descends_from}; a selected producer must be a genuine descendant")
    if ancestry.returncode != 0:
        raise SystemExit(
            f"{PRODUCER_SOURCE}: ancestry check failed in {checkout_root} "
            f"({descends_from} against HEAD {head}): {ancestry.stderr.strip()[:300]}")
    expected = (Path(expected_package) if expected_package is not None else package_dir)
    expected_payload = _expected_payload(checkout_root, expected)
    from tessera.source_profiles import PACKAGE_SOURCE_V2, shipped_payload_profiles

    expected_profiles = shipped_payload_profiles(expected_payload)
    installed_pkg, actual_payload = _installed_payload()
    # Before anything else passes: the code ALREADY LOADED in this process --
    # this exporter module included -- must come from the payload that is
    # about to be digested.  All of this precedes any source or output
    # operation of the exporter.
    _require_loaded_origins(installed_pkg, actual_payload)
    missing = sorted(set(expected_payload) - set(actual_payload))
    extra = sorted(set(actual_payload) - set(expected_payload))
    if missing or extra:
        raise SystemExit(
            f"{PRODUCER_PYTHON}: the installed payload {installed_pkg} is not the "
            f"projected wheel roster (missing {missing[:3]}, extra {extra[:3]}); the "
            "shipped code and declared package-data must match exactly")
    actual_profiles = shipped_payload_profiles(actual_payload)
    if actual_profiles[PACKAGE_SOURCE_V2] != expected_profiles[PACKAGE_SOURCE_V2]:
        raise SystemExit(
            f"{PRODUCER_SOURCE}: the installed payload {installed_pkg} does not match "
            f"the source reference {expected} (package source "
            f"{actual_profiles[PACKAGE_SOURCE_V2]} vs "
            f"{expected_profiles[PACKAGE_SOURCE_V2]}). A transient "
            "install-vs-checkout mismatch is a refusal, not a tolerance.")
    contract = "serving/runtime_contract.json"
    if actual_payload.get(contract) != expected_payload.get(contract):
        raise SystemExit(
            f"{PRODUCER_SOURCE}: {contract} differs between the source reference and "
            "the installed payload; source profiles cover code, not data, so the "
            "runtime contract is compared explicitly")
    return {
        "schema": PRODUCER_RECEIPT_SCHEMA,
        # The interpreter, bound by exact path and by the executable's own bytes.
        "selection": PRODUCER_PYTHON,
        "requested_interpreter": selected,
        "interpreter": sys.executable,
        "executable_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
        "sys_prefix": sys.prefix,
        # The producer process's observed environment, as observed -- never a
        # claim about the reader/runtime image the parts are destined for.
        "python_version": platform.python_version(),
        "torch_version": torch.__version__,
        # The source reference and its verified Git proof.
        "source": PRODUCER_SOURCE,
        "source_root": str(source_dir),
        "git_head": head,
        "descends_from": descends_from,
        # The bytes: projected expected payload vs actual installed payload.
        "installed_package": str(installed_pkg),
        "expected_package_sha256": expected_profiles[PACKAGE_SOURCE_V2],
        "package_sha256": actual_profiles[PACKAGE_SOURCE_V2],
        "shipped_files": len(actual_payload),
        "runtime_contract_sha256": hashlib.sha256(actual_payload[contract]).hexdigest(),
    }


def read_input_scales(path: "Path | None") -> "tuple[dict, str | None]":
    """The ``--input-scales`` scalars, parsed from ONE snapshot of the bytes.

    The identity seals ``input_scales_sha256`` of exactly these bytes, and
    the roles consume exactly these scalars: one read, one object.  The
    previous two-pass shape -- a digest of the file here, a re-open of the
    path there -- let a file rewritten in between seal a digest the run
    never consumed.  Same scalar conversion and refusals as the per-key
    ``safe_open`` read it replaces.
    """
    if path is None:
        return {}, None
    from safetensors.torch import load

    data = path.read_bytes()
    scales = {}
    for key, tensor in load(data).items():
        if not key.endswith(".input_global_scale"):
            continue
        if tensor.numel() != 1:
            raise SystemExit(f"--input-scales {key} must contain one scalar")
        scales[key] = float(tensor.float().reshape(-1)[0])
    return scales, hashlib.sha256(data).hexdigest()


class PricedInputsSnapshot:
    """Allocation input expectations from one digest-bound build snapshot.

    A campaign may republish its capture and scalar files at any time. The
    caller passes the digest produced with its validated build anchor, and
    this gate compares expectations to the objects the encoder will consume,
    never to a second read of those filenames (PrismaQuant #231).
    """

    def __init__(self, path: Path, expected_sha256: str):
        raw = Path(path).read_bytes()
        self.sha256 = hashlib.sha256(raw).hexdigest()
        if self.sha256 != expected_sha256:
            raise SystemExit("--priced-inputs build SHA-256 does not match the preflight snapshot")
        try:
            build = json.loads(raw)
        except (ValueError, UnicodeError) as exc:
            raise SystemExit(f"--priced-inputs is not valid JSON: {exc}") from exc
        block = build.get("priced_inputs") if isinstance(build, dict) else None
        fields = {"schema", "hessian_capture_sha256", "input_global_scales"}
        indexed = isinstance(block, dict) and block.get('schema') == 'tessera.priced_export_inputs.v2'
        if indexed:
            fields.add('hessian_reference_binding')
        if not isinstance(block, dict) or set(block) != fields:
            raise SystemExit("--priced-inputs needs a closed priced_inputs block")
        if block["schema"] not in {"tessera.priced_export_inputs.v1", "tessera.priced_export_inputs.v2"}:
            raise SystemExit("--priced-inputs has an unsupported priced_inputs schema")
        digest = block["hessian_capture_sha256"]
        if digest is not None and (not isinstance(digest, str) or
                                   re.fullmatch(r"[0-9a-f]{64}", digest) is None):
            raise SystemExit("--priced-inputs hessian_capture_sha256 must be a SHA-256 or null")
        scales = block["input_global_scales"]
        if not isinstance(scales, dict) or any(
                not isinstance(key, str) or not key.endswith(".input_global_scale")
                or isinstance(value, bool) or not isinstance(value, (int, float))
                or not math.isfinite(value) or value <= 0
                for key, value in scales.items()):
            raise SystemExit("--priced-inputs input_global_scales must map scale keys to positive finite scalars")
        self.capture_sha256 = digest
        self.scales = scales
        self.reference_binding = None
        if indexed:
            from tessera.hessian_capture import normalize_reference_binding
            from tessera.errors import GrammarError
            try:
                self.reference_binding = normalize_reference_binding(block['hessian_reference_binding'])
            except GrammarError as error:
                raise SystemExit(f'--priced-inputs: {error}') from error
            if digest is None:
                raise SystemExit('--priced-inputs reference handoff requires a Hessian capture seal')

    def require(self, activation, input_scales):
        # capture_sha256 seals this loaded owner; for_unit subsequently checks
        # every H against that same seal, including cached expert intake.
        actual = activation.capture_sha256() if activation is not None else None
        if actual != self.capture_sha256:
            raise SystemExit("--priced-inputs Hessian capture differs from the allocation: "
                             f"loaded={actual}, priced={self.capture_sha256}")
        binding = (activation.reference_binding() if activation is not None and
                   hasattr(activation, 'reference_binding') else None)
        if binding != self.reference_binding:
            raise SystemExit('--priced-inputs canonical Hessian reference differs from the allocation')
        for key, expected in self.scales.items():
            if input_scales.get(key) != expected:
                raise SystemExit(f"--priced-inputs {key} differs from the allocation: "
                                 f"loaded={input_scales.get(key)!r}, priced={expected!r}")


class PlanSnapshot:
    """The ``--plan-json`` file as ONE logical object, read once and never reread.

    Four separate consumers used to open the path for themselves -- the
    override loop that drives planning, a partition's sealed
    ``export_identity``, the pre-publication gate, and the manifest's
    provenance block -- and an export is long.  A planner that regenerates or
    atomically replaces its output part-way through therefore let the encoded
    artifact and the published plan describe different allocations, and the
    gate could not catch it because it reread the replacement too: a tensor
    written as an E4M3 q1024 wire was published as ``PASSTHROUGH`` and
    accepted (#301).

    The plan that drove the encode is the plan that is published.  This object
    is that snapshot; the file is not consulted again, so a replacement during
    the export is neither adopted nor able to fail the run half-written.  Its
    ``sha256`` is over the exact bytes read and is printed with the plan, so
    the export log says which revision of a mutable file this artifact
    implements.  Every consumer that *stores* the plan takes ``published()``
    -- its own deep copy -- so no reader can mutate what another one writes.
    """

    __slots__ = ("path", "sha256", "entries", "schema")

    def __init__(self, path: Path, raw: bytes):
        self.path = Path(path)
        self.sha256 = hashlib.sha256(raw).hexdigest()
        try:
            entries = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise SystemExit(f"--plan-json {self.path} is not valid JSON: {exc}") from exc
        if not isinstance(entries, dict):
            raise SystemExit(
                f"--plan-json {self.path} must be a JSON object mapping tensor or "
                "stack names to entries")
        # The published schema (``tessera.serving_plan``, #687), asked at
        # ARGUMENT time: a malformed entry is a typo in the run's
        # instructions, and finding it after the first encode costs
        # the encode.  The reserved schema key (#691 item 5) is popped
        # before the entry loop: it declares the object, it is not an
        # entry, and the manifest records the declaration beside the
        # published plan.
        try:
            validate_serving_plan(entries)
        except ValueError as exc:
            raise SystemExit(f"--plan-json {self.path}: {exc}") from exc
        self.schema = entries.pop("schema", None)
        self.entries = entries

    @classmethod
    def read(cls, path: Path) -> "PlanSnapshot":
        return cls(Path(path), Path(path).read_bytes())

    def published(self) -> dict:
        """A private copy, for a consumer that keeps or serialises the plan."""
        return copy.deepcopy(self.entries)


def grid_for(name: str):
    if name == "E4M3":
        return E4M3_GRID
    if name == "BF16":
        return BF16_GRID
    match = re.fullmatch(r"(E2M1)(?:x(\d+))?", name)
    if not match:
        raise SystemExit(
            f"unknown grid {name!r}; one of E2M1, E2M1x2 (NVFP4 route), E4M3 "
            "(FP8 route) or BF16 (the 16-bit route)")
    return tuple_grid(E2M1_GRID, int(match.group(2) or 1))


# ``served_recipe`` is the package's (``tessera.export.served_recipe``,
# tessera#662): the exporter, the cached-unit receipt and the export intake read
# one statement of the served wire per (grid, q256, structure). It is imported
# above and re-exported here for the callers and tests that name it on this
# module.
#
# ``family_for`` and ``module_scheme_key`` moved into the package
# (``tessera.serving_plan``, #687): a producer checks the fused-group rule
# BEFORE writing a plan, without importing this entry module. They are
# imported above and re-exported here unchanged for the same callers.


def check_recipe(grid, q256: int, where: "str | None" = None, *,
                 allow_unserveable: bool = False, overrides: "list | None" = None,
                 structure: str = STRUCTURE_DENSE, research_selected=None,
                 research_records: "list | None" = None):
    """The recipe this plugin build publishes a decode for, or a refusal.

    THE SEAM IS HERE, and it is the export-time half of the load-time gate.
    ``refuse_unserveable_wire`` lives in ``tessera.serving.scheme`` -- beside
    ``validate_tessera_scheme``, off the same ``ROUTES`` table and the same
    packaged ``runtime_contract.json``, importable without torch -- so the
    producer and the consumer read one authority rather than two opinions.
    What lives HERE is only the call, and it is placed before the first encode:
    the plan's default grid and every ``--plan-json`` override are checked at
    argument time, which is every path into the encode loop.  A refusal that
    arrives after the encode is not a refusal; it is a bill.

    It refuses at the SERVING boundary and nowhere else.  ``wire_recipe`` and
    ``encode_linear`` keep their full range: sub-cap ``E2M1x2`` is the rate
    frontier's own body of work and every research encode of it still runs.
    This script is the one that writes ``quant_method: "tessera"``, so this is
    where the pinned runtime's reach becomes a constraint.

    IT FAILS CLOSED WITH AN EXPLICIT, STAMPED OVERRIDE, which is the shape
    principle 9 gives this carve-out: refuse unless the run carries an explicit
    per-run override, and stamp it on the artifact.  ``--allow-unserveable``
    is that override, and it exists because real workflows need it: ``--grid
    E2M1``, whose route holds the grid while the contract publishes no measured
    range for it, and sub-cap ``E2M1x2``, which the rate frontier encodes
    constantly.  The reason to export either is the ``--stock-twin``, which
    vanilla vLLM serves with no plugin at all.  (``--grid BF16`` was the
    original example and is no longer one: the 16-bit route (#9) decodes it,
    so it passes the gate rather than needing the override.)  Overridden refusals land verbatim in the manifest's
    ``serving_gate`` block, so an artifact that cannot be served says so in its
    own bytes rather than in a shell history.

    ``structure`` is what the wire will be served AS, and it picks the bound
    (#135): a dense module is held to the route's reader range, a
    ``routed_moe`` stack to the rungs the contract's ``routed_moe`` cells
    attest -- the format row's range is the dense reader's, and a stack at
    a rung only the dense route reads used to pass here and reach the
    encode.  The override record carries the structure for the same reason
    the refusal does.
    """
    recipe = served_recipe(grid, q256, structure)
    target = where or f"--grid {grid.name} --q256 {q256}"
    if research_selected is not None and structure == STRUCTURE_ROUTED_MOE:
        try:
            family = research_selected.require_wire_recipe(
                grid=grid.name, q256=q256, body=recipe.body.name,
                plane=recipe.scale_plane.name, span=recipe.span, target=target)
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
        if research_records is not None:
            research_records.append({"target": target, "family": family,
                                     "grid": grid.name, "q256": int(q256),
                                     "qualification": "research_decoder_only"})
        return recipe
    try:
        # The family this checkpoint will declare for the wire, so the gate
        # reads THAT route's published range rather than resolving the route
        # from the grid alone -- ambiguous the moment two routes hold one
        # grid, with the winner decided by dict order (#51).
        refuse_unserveable_wire(grid.name, q256, recipe.body.name, recipe.scale_plane.name,
                                family=family_for(grid), span=recipe.span, target=target,
                                structure=structure)
    except ValueError as exc:
        if not allow_unserveable:
            raise SystemExit(
                f"{exc}\n\nThis script writes a checkpoint that declares quant_method "
                "\"tessera\", so a wire the plugin cannot decode is refused HERE rather than "
                "hours later at load. Pass --allow-unserveable to write it anyway as a research "
                "artifact: the refusal is then stamped verbatim into the manifest's "
                "serving_gate block. This does not establish loadability or qualification "
                "under this plugin build.") from exc
        print(f"  --allow-unserveable: writing a research wire that failed the export serving gate. {exc}",
              flush=True)
        if overrides is not None:
            overrides.append({"target": target, "grid": grid.name, "q256": int(q256),
                              "body": recipe.body.name, "plane": recipe.scale_plane.name,
                              "structure": structure, "refusal": str(exc)})
    return recipe


def unrouted_modules(src_config, modules):
    """Which of these vLLM modules the pinned runtime will NOT route to a plugin.

    THE PRODUCER MAY NOT KEEP THIS ROSTER.  ``LinearBase.__init__`` takes
    ``UnquantizedLinearMethod()`` in the ``quant_config is None`` branch
    *without calling* ``get_quant_method`` (vLLM 0.28,
    ``model_executor/layers/linear.py:258``), so a projection a model builds
    with ``quant_config=None`` is invisible to every quantization plugin --
    ours cannot refuse it, warn about it, or even see the prefix.  A wire
    written there deletes the ``<module>.weight`` the runtime wants and puts
    bytes in its place that no loader maps: not a slow route, no route, and no
    refusal either.

    The runtime-attestation rule says what a runtime DOES is derived from a
    machine-readable table that runtime publishes.  The table is
    ``runtime_contract.json``'s ``construction`` block (contract v11), whose
    rows are generated from the census receipts under
    ``docs/measurements/construction/`` -- and the census itself
    (``tools/tessera_construction_census.py``) OBSERVES the answer by building
    the model the way the loader does with a probe quant config that records
    every prefix it is offered.  Nothing here reads source, and nothing here
    keeps a list.

    Returns ``{checkpoint module: (verdict, vllm module pattern)}`` for every
    module that is not ``offered``:

    * ``never_offered`` -- the runtime builds this module with
      ``quant_config=None``.  On GLM-5.3-Flash that is every attention
      projection, the whole KDA layer, the indexer and the vision tower.
    * ``absent`` -- the runtime builds no module of this name at all.  It is
      what a fused role named at the wrong seam looks like: the checkpoint has
      ``self_attn.{q,k,v}_proj`` on a KDA layer and vLLM builds ONE
      ``self_attn.in_proj_qkvbfg_a``, so the ``qkv_proj`` this script would
      declare corresponds to nothing.
    * ``disagreement`` -- the census observed the members of this normalised
      pattern answering differently and recorded which ones.  A pattern that
      answered both ways clears none of its members, and the ones it did not
      observe least of all.
    * ``uncensused`` -- no census covers this architecture.  That is an honest
      gap, not a clearance: the answer is unknown, so the wire is unpriced.
    """
    architectures = list(src_config.get("architectures") or ())
    entry = construction_entry(architectures)
    if entry is None:
        return {module: ("uncensused", "-") for module in modules}, None
    verdicts = {}
    for module in modules:
        verdict, pattern = classify_construction(entry, module)
        if verdict != "offered":
            verdicts[module] = (verdict, pattern)
    return verdicts, entry


def _unrouted_refusal(verdicts, architectures) -> str:
    kinds = {}
    for module, (verdict, pattern) in sorted(verdicts.items()):
        kinds.setdefault(verdict, []).append((module, pattern))
    lines = [f"{len(verdicts)} planned module(s) are not routed through this plugin by the "
             f"pinned runtime, so a wire written there is dead weight and the "
             f"<module>.weight it replaced is gone:"]
    reasons = {
        "never_offered": "built with quant_config=None -- vLLM's own BF16 method, and "
                         "get_quant_method is never called, so this plugin cannot even refuse it",
        "absent": "the runtime builds no module of this name (a fused role named at the wrong "
                  "seam, or a name from another architecture)",
        "disagreement": "the census observed the members of this pattern answering differently "
                        "(see the entry's disagreements rows), so the pattern clears none of "
                        "them -- census this architecture on the full model, or name the "
                        "modules the runtime actually offers",
        "uncensused": f"no construction census covers {architectures}; run "
                      "tools/tessera_construction_census.py inside the serving image and add "
                      "the receipt under docs/measurements/construction/",
    }
    for verdict, rows in sorted(kinds.items()):
        lines.append(f"  {verdict} ({len(rows)}): {reasons[verdict]}")
        for module, pattern in rows[:12]:
            lines.append(f"    {module}   -> {pattern}")
        if len(rows) > 12:
            lines.append(f"    ... and {len(rows) - 12} more")
    return "\n".join(lines)

def check_lanes(lanes, grid, q256: int, where: "str | None" = None,
                structure: str = STRUCTURE_DENSE) -> None:
    """Refuse the plan unless every requested LANE can read this rung's wire.

    The second half of the export-time seam, and the half #104 says was
    missing.  ``check_recipe`` asks whether the ROUTE publishes a decode for
    these bytes; this asks whether a named lane INSIDE that route can read
    them -- a different question, and one whose answer was previously
    discovered per module at LOAD, where the route catches it and serves the
    same bytes through its other path.  So a checkpoint built to exercise the
    window GEMV exercised nothing and said so nowhere.

    Placed at the same call sites as ``check_recipe`` -- the default rung and
    every ``--plan-json`` override, at argument time -- because a refusal
    after the encode is not a refusal; it is a bill.  There is no override:
    ``--require-lane`` is itself the opt-in, and a run that wants the rung
    without the lane simply does not pass the flag.
    """
    if not lanes:
        return
    recipe = served_recipe(grid, q256, structure)
    target = where or f"--grid {grid.name} --q256 {q256}"
    for lane in lanes:
        try:
            rates = refuse_unreachable_lane(
                lane, grid=grid.name, q256=int(q256), rate_cap=body_rate_cap(recipe.body, grid),
                body=recipe.body.name, plane=recipe.scale_plane.name,
                window_bits=int(recipe.window_bits), target=target)
        except ValueError as exc:
            raise SystemExit(
                f"{exc}\n\n--require-lane {lane} was passed, so this plan is refused HERE -- "
                "before a single unit is encoded. Drop the flag to write the rung anyway (it "
                "serves, through the route's other path), or re-plan onto a rung the lane "
                "reads.") from exc
        print(f"  --require-lane {lane}: {target} -> column rates {list(rates)}, readable",
              flush=True)


def module_of(tensor_name: str) -> str:
    return tensor_name[: -len(".weight")]


def fused_module(tensor_name: str, architecture: str | None = None, *, config=None, tensor_names=None):
    """Use the shared member rule for every export declaration."""
    return _fused_module(tensor_name, architecture, config=config, tensor_names=tensor_names)


def ignored_modules(tensor_name: str, shape, architecture: str | None = None, *,
                    config=None, tensor_names=None) -> tuple[str, ...]:
    """The vLLM module names ``ignore`` must carry for a tensor written at source precision.

    Empty when the tensor is not a Linear weight the plugin can be asked
    about.  ``architecture`` is the checkpoint's HF ``architectures[0]``,
    threaded to ``fused_module`` so an architecture whose q/k/v stay
    separate Linears names those, not a ``qkv_proj`` vLLM never builds.  This is a RULE over the tensors the export actually writes, not a
    roster beside them: a roster is a second place to remember, and it goes
    stale in silence -- which is how the vision tower came to be passed
    through and never named.  The plugin refuses a ``LinearBase`` that is
    neither declared nor ignored, so the completeness has to follow the bytes.

    Three cases, and the two expert ones are why this is not simply
    ``module_of``:

    * a FUSED role names its fused parent, because vLLM builds one method per
      fused module.  Ignoring ``q_proj``/``k_proj``/``v_proj`` leaves
      ``qkv_proj`` neither declared nor ignored, which is the refusal again.
      The rule reaches outside the body too: ``Glm5NextVisionMLP`` builds one
      ``MergedColumnParallelLinear`` at ``{prefix}.gate_up_proj``
      (pinned build ``prismaquant/glm53-mia-sm121:487ecf187``,
      ``models/glm5next/nvidia/multimodal.py:102-107``), exactly as the body's
      MLP does.
    * a ROUTED expert leaf names the FusedMoE's OWN prefix, not one of its
      2592 checkpoint leaves.  Attested against the same build, three hops:
      ``models/glm5next/nvidia/model.py:239`` ``FusedMoEFactory(prefix=
      f"{prefix}.experts")``; ``layers/fused_moe/layer.py:221`` ``layer_name =
      prefix``; ``layers/fused_moe/routed_experts.py:122,:201``
      ``quant_config.get_quant_method(self, self.layer_name)``.  So the string
      the plugin tests is ``<layer>.mlp.experts`` and no leaf name is ever
      offered to it.  Naming the parent cannot reach the shared experts beside
      it: ``shared_experts`` is a SIBLING of ``experts``, and both the plugin's
      test and compressed-tensors' are exact/fnmatch, not prefix subsumption.
    * a PACKED expert stack (rank 3 or more) names the same FusedMoE prefix.
      Rank alone does not identify one -- GLM-5.3-Flash's attention carries
      ``k_conv1d.weight [8192, 1, 4]`` and a conv is not a Linear the plugin
      is ever asked about -- so the test is where the tensor sits.

    Over-naming is cheap here and under-naming is a load-time refusal: an
    ignore entry for a module the runtime never builds is never looked up,
    which is why a 2-D weight that is not a Linear at all (an embedding table)
    is named rather than second-guessed.
    """
    # A packed expert stack may carry NO ``.weight`` suffix -- transformers-5
    # stores it as a parameter on the experts module -- so the patterns are
    # matched against the name in its ``.weight`` spelling and the suffix is
    # not what decides whether a rank-3 tensor is a stack.
    probe = tensor_name if tensor_name.endswith(".weight") else tensor_name + ".weight"
    if len(shape) >= 3:
        packed = PACKED_EXPERT_ND.match(probe)
        return (packed.group("moe") + ".experts",) if packed else ()
    if not tensor_name.endswith(".weight") or len(shape) != 2:
        return ()
    routed = ROUTED_EXPERT_2D.match(probe)
    if routed:
        return (routed.group("moe") + ".experts",)
    fused = fused_module(probe, architecture, config=config, tensor_names=tensor_names)
    if fused:
        return (fused[0],)
    names = [module_of(probe)]
    if architecture != "Glm5NextForConditionalGeneration":
        names.extend(match.group(1) + alias for pattern, alias in MERGED_ALIASES
                     if (match := pattern.match(probe)))
    return tuple(names)


def quantizable(src: Path, *, selected=()):
    """The body's ``.weight`` tensors, split by WHAT KIND OF LAYER OWNS THEM.

    Returns ``(shards, shapes, expert_shapes, routed_shapes)``:

    * ``shapes`` -- every 2-D dense-Linear weight, one blob per vLLM module.
      Shared experts live here: ``mlp.shared_experts.gate_proj`` is a plain
      ``Glm5NextMLP`` Linear, not a routed unit.
    * ``expert_shapes`` -- every ``.weight`` of rank 3 or more, a
      transformers-5 PACKED expert stack.
    * ``routed_shapes`` -- 2-D routed-expert leaves, the UNPACKED per-expert
      layout (``...mlp.experts.7.gate_proj.weight``).

    The third split is the one that has to exist.  These are 2-D, so without
    it they land in ``shapes`` and are planned as ordinary dense Linears --
    864 of them per projection on GLM-5.3-Flash -- and the export succeeds,
    hours later, into a checkpoint whose ``config_groups`` name modules that
    vLLM does not build, which the plugin then refuses at LOAD.  A refusal
    that arrives after the encode is not a refusal; it is a bill.
    """
    index = src / "model.safetensors.index.json"
    if index.exists():
        weight_map = json.loads(index.read_text())["weight_map"]
        shards: dict[str, list[str]] = {}
        for tensor, shard in weight_map.items():
            shards.setdefault(shard, []).append(tensor)
    else:
        shards = {}
        for path in sorted(src.glob("*.safetensors")):
            with safe_open(str(path), framework="pt") as handle:
                shards[path.name] = list(handle.keys())
    shapes, expert_shapes, routed_shapes = {}, {}, {}
    for shard, names in shards.items():
        with safe_open(str(src / shard), framework="pt") as handle:
            for name in names:
                if not BODY_LAYER.match(name) and not (name in selected and VISION_LINEAR.match(name)):
                    continue
                # ``.weight`` is not what makes a tensor a body weight, and
                # gating on it here is what dropped a whole layout: a
                # transformers-5 packed expert stack is an ``nn.Parameter`` on
                # the experts module, so the tensor on disk is
                # ``...mlp.experts.gate_up_proj`` with no suffix at all.  It
                # landed in NO bucket -- not dense, not packed, not routed -- so
                # the export succeeded, encoded the dense body for hours, and
                # produced a checkpoint the plugin refuses at load because the
                # FusedMoE module reached neither ``config_groups`` nor the
                # plan-time refusal.  ``probe`` is the same idiom
                # ``ignored_modules`` uses (#86): match the patterns against the
                # name in its ``.weight`` spelling, so one convention decides
                # what a name means and the suffix decides nothing.
                probe = name if name.endswith(".weight") else name + ".weight"
                bare_packed = not name.endswith(".weight") and PACKED_EXPERT_ND.match(probe)
                if not name.endswith(".weight") and not bare_packed:
                    continue
                shape = tuple(handle.get_slice(name).get_shape())
                if bare_packed:
                    # RANK IS STILL ASKED, and a bare name that fails it is
                    # REFUSED rather than filed.  "Nothing else in a decoder
                    # layer is called ``experts.<projection>``" would be an
                    # assertion about every checkpoint yet to exist, and that
                    # is the same shape as the ``len(shape) >= 3`` rule §9.2
                    # already retired once.  A packed stack stacks experts, so
                    # it has an expert axis; a two-axis tensor under this name
                    # is something this exporter has not been shown, and the
                    # honest answer is to say so before the encode rather than
                    # to file it in whichever bucket happens to be nearest.
                    if len(shape) < 3:
                        raise SystemExit(
                            f"{name} {list(shape)} is named like a packed expert stack "
                            f"(``<moe>.experts.<projection>``) but has rank {len(shape)}, and a "
                            "packed stack carries an expert axis. Refusing rather than guessing: "
                            "filing it as an expert stack would leave the module BF16 and named "
                            "in ignore, and filing it as a dense Linear would declare a module "
                            "vLLM never builds -- and neither is a fact about this tensor. Teach "
                            "the exporter this architecture's layout explicitly.")
                    expert_shapes[name] = shape
                elif len(shape) >= 3:
                    # Only an expert stack by NAME; anything else of rank 3 is
                    # not a Linear at all (a conv1d), so it is not a Linear the
                    # plugin must be told about and needs no ignore entry.
                    if PACKED_EXPERT_ND.match(name):
                        expert_shapes[name] = shape
                elif len(shape) == 2:
                    (routed_shapes if ROUTED_EXPERT_2D.match(name) else shapes)[name] = shape
    return shards, shapes, expert_shapes, routed_shapes


def body_layer(name: str) -> int:
    """The decoder-layer index owning this tensor."""
    match = BODY_LAYER.match(name)
    if match is None:
        raise SystemExit(f"{name} is not a body tensor; BODY_LAYER should have filtered it out")
    return int(match.group(1))


def packed_expert_orientation(name: str, shape, config: dict):
    """Which axis of a PACKED expert stack is the output, from the config.

    ``[E, A, B]`` is ambiguous on its face and the conventions genuinely
    differ across transformers-5 architectures (``gate_up_proj`` appears both
    as ``[E, hidden, 2*inter]`` and as ``[E, 2*inter, hidden]``).  So the
    answer is read off ``hidden_size``/``moe_intermediate_size`` rather than
    assumed -- and REFUSED when the dims cannot decide it.

    That refusal is not hypothetical.  On GLM-5.3-Flash
    ``hidden_size == 4096`` and ``moe_intermediate_size == 2048``, so a packed
    ``gate_up_proj`` would be ``[E, 4096, 4096]`` and NO dim comparison can
    orient it.  A guess there transposes every expert in silence.
    """
    text = config.get("text_config", config)
    hidden = text.get("hidden_size")
    inter = text.get("moe_intermediate_size", text.get("intermediate_size"))
    if hidden is None or inter is None:
        raise SystemExit(f"cannot orient the packed expert stack {name} {list(shape)}: "
                         "config.json declares no hidden_size/moe_intermediate_size")
    _experts, a, b = shape
    gate_up = name.endswith("gate_up_proj.weight") or name.endswith("gate_up_proj")
    out_dim = 2 * inter if gate_up else hidden
    in_dim = hidden if gate_up else inter
    a_is_out, b_is_out = (a == out_dim and b == in_dim), (b == out_dim and a == in_dim)
    if a_is_out and b_is_out:
        raise SystemExit(
            f"cannot orient the packed expert stack {name} {list(shape)}: both axis orders fit "
            f"(out={out_dim}, in={in_dim}). Re-export this checkpoint unpacked, or teach the "
            "exporter this architecture's convention explicitly -- guessing transposes every "
            "expert silently.")
    if a_is_out:
        return "out_first"
    if b_is_out:
        return "in_first"
    raise SystemExit(
        f"cannot orient the packed expert stack {name} {list(shape)}: neither axis order fits "
        f"hidden_size={hidden} moe_intermediate_size={inter} (expected out={out_dim}, in={in_dim})")


#: The scheme owns canonical roles and their runtime row order, for both
#: the sidecar reader and this writer.
EXPERT_PROJECTIONS = tuple(p for g in MOE_GROUPS for p in MOE_GROUP_PROJECTIONS[g])
#: Which group a projection rides, inverted from the table above.
PROJECTION_GROUP = {p: g for g, ps in MOE_GROUP_PROJECTIONS.items() for p in ps}


def expert_stacks(routed_shapes):
    """``{<moe>.experts: {expert index: {projection: (tensor name, shape)}}}``.

    The stack is the executed module; each expert projection is plannable.
    vLLM builds one method per ``RoutedExperts`` module and the sidecar
    declares one scheme, so family/grid/body/plane remain stack facts.
    Individual selected rungs travel through ``unit_q256`` on that stack
    entry, not as top-level dense Linear declarations.
    """
    stacks: dict[str, dict[int, dict[str, tuple]]] = {}
    for name, shape in routed_shapes.items():
        match = ROUTED_EXPERT_2D.match(name)
        stack = match.group("moe") + ".experts"
        expert = stacks.setdefault(stack, {}).setdefault(int(match.group("expert")), {})
        source_projection = match.group("proj")
        projection = SHARD_PROJECTION.get(source_projection, source_projection)
        if projection in expert:
            other = expert[projection][0]
            raise SystemExit(
                f"the expert stack {stack} supplies canonical projection {projection!r} twice: "
                f"{other} and {name}. They are two source spellings for one runtime shard; "
                "refusing rather than letting checkpoint order choose which bytes are served.")
        expert[projection] = (name, tuple(shape))
    return stacks


def packed_expert_stacks(expert_shapes):
    """Group physical rank-3 expert tensors by the runtime stack they feed.

    A physical projection may be spelled with or without ``.weight``.  The
    suffix cannot decide identity, and two spellings of the same projection
    are refused instead of allowing safetensors order to choose the bytes.
    """
    stacks: dict[str, dict[str, tuple]] = {}
    for name, shape in expert_shapes.items():
        probe = name if name.endswith(".weight") else name + ".weight"
        match = PACKED_EXPERT_ND.match(probe)
        if match is None:  # ``quantizable`` owns this classification.
            raise SystemExit(
                f"{name} {list(shape)} was classified as a packed expert tensor but does "
                "not match PACKED_EXPERT_ND; refusing a source the planner cannot name")
        stack = match.group("moe") + ".experts"
        projection = match.group("proj")
        found = stacks.setdefault(stack, {})
        if projection in found:
            other = found[projection][0]
            raise SystemExit(
                f"the packed expert stack {stack} supplies {projection!r} twice: {other} "
                f"and {name}. They are two physical spellings for one source tensor; "
                "refusing rather than letting checkpoint order choose which bytes are served.")
        found[projection] = (name, tuple(shape))
    return stacks


def plan_expert_stack(stack: str, experts: dict, grid, q256: int, *,
                      source_layout: str = MOE_SOURCE_UNPACKED, config: dict,
                      research_selected: bool = False):
    """Everything about a planned expert stack that must be refused BEFORE the encode.

    A routed stack is 864 units on GLM-5.3-Flash and ~75 minutes of GPU per
    layer, so every disagreement between what the checkpoint holds and what the
    plugin's expert route reads is asked here rather than discovered at load.
    Returns the stack's plan record: the family, the two groups' geometry, and
    the per-unit work list in the row order the groups stack.

    The refusals, and why each is a refusal rather than a repair:

    * a family with no expert route -- ``scheme.MOE_BUILDERS`` is the one home
      for that rule, and its absences are measured (the NVFP4 oracle's
      ``swiglu_limit`` clamp, a 16-bit stack being the passthrough already);
    * an expert population that is not exactly the source config's declared
      ``0..E-1`` -- the parameter is ``[E, ...]`` and the loader indexes it by
      ``expert_id``, so a gap is a row of zeros served as an expert, and a
      truncated contiguous prefix (a missing TAIL expert) is the same defect
      that ``range(len(indices))`` could never see (#213).  The declared count
      comes from ``config.json``, the same geometry contract the packed path
      has always proved against;
    * a missing projection -- ``w13`` is the gate/up PAIR, and a stack missing
      one has no second half for the tile;
    * geometry that differs across experts, or that disagrees with the
      config's ``hidden_size``/``moe_intermediate_size`` -- one stack is one
      tile, and its dimensions are the model's;
    * rows or columns the route's mainloop cannot take.  A dense Linear that
      fails this is passed through, which is safe because it is one module; a
      routed stack cannot be half passed through, because vLLM builds ONE
      method for it.
    """
    family = family_for(grid)
    try:
        if not (research_selected and family == "TESSERA_BF16"):
            refuse_a_family_with_no_expert_route(family, stack)
    except ValueError as exc:
        raise SystemExit(
            f"the plan gives the expert stack {stack} grid {grid.name} ({family}): {exc}") from exc
    declared, config_hidden, config_inter = _stack_config_geometry(config, stack)
    indices = sorted(experts)
    if indices != list(range(declared)):
        missing = sorted(set(range(declared)) - set(indices))
        extra = sorted(set(indices) - set(range(declared)))
        problems = []
        if missing:
            problems.append(f"is missing expert(s) {missing[:8]}")
        if extra:
            problems.append(f"carries undeclared expert(s) {extra[:8]}")
        raise SystemExit(
            f"the expert stack {stack} {' and '.join(problems)} of the {declared} the source "
            "config declares (n_routed_experts/num_experts/num_local_experts). The wire "
            "parameter is [E, ...] and the loader writes row expert_id, so a gap or a "
            "truncated population is not a smaller stack -- it is a row of zeros decoded as "
            "an expert. Refusing rather than renumbering.")
    geometry: dict[str, tuple] = {}
    for index in indices:
        found = experts[index]
        absent = [p for p in EXPERT_PROJECTIONS if p not in found]
        if absent:
            raise SystemExit(
                f"the expert stack {stack} expert {index} carries {sorted(found)} and is missing "
                f"{absent}. A group is exactly the shards the runtime loads into it "
                f"({dict(MOE_GROUP_PROJECTIONS)}, scheme.MOE_GROUP_SHARDS): w13 is the gate/up "
                "PAIR, so a stack missing one half has no second half for the tile.")
        for projection, (_name, shape) in found.items():
            if geometry.setdefault(projection, shape) != shape:
                raise SystemExit(
                    f"the expert stack {stack} holds {projection} at {list(geometry[projection])} "
                    f"and at {list(shape)} on expert {index}. One stack is one tile, so one "
                    "shape; a stack whose experts disagree cannot be [E, rows, cols].")
    hidden = geometry["gate_proj"][1]
    inter = geometry["gate_proj"][0]
    if (hidden, inter) != (config_hidden, config_inter):
        raise SystemExit(
            f"the expert stack {stack} holds gate_proj [{inter}, {hidden}] but the source "
            f"config declares hidden_size={config_hidden} and intermediate size "
            f"{config_inter}. One stack is one tile and its geometry is the model's; "
            "refusing rather than serving rows the runtime never computes.")
    for projection, shape in geometry.items():
        want = (hidden, inter) if projection == "down_proj" else (inter, hidden)
        if shape != want:
            raise SystemExit(
                f"the expert stack {stack} holds {projection} at {list(shape)}; with gate_proj "
                f"[{inter}, {hidden}] the runtime's tile wants {list(want)}. w13 is [2N, K] and "
                "w2 is [K, N] over the same expert, so the two groups' geometry is one pair of "
                "numbers and this checkpoint's is not.")
    groups = {}
    for group in MOE_GROUPS:
        projections = MOE_GROUP_PROJECTIONS[group]
        rows_each = geometry[projections[0]][0]
        columns = geometry[projections[0]][1]
        if rows_each % (grid.arity * 32) or columns % 16:
            raise SystemExit(
                f"the expert stack {stack} group {group} is {rows_each}x{columns} per "
                f"projection, which the {grid.name} encoder cannot cut: rows must be a whole "
                f"number of tuples (grid.arity * 32 = {grid.arity * 32}) and columns a multiple "
                "of 16. A dense Linear that fails this is passed through; a routed stack cannot "
                "be half passed through, because vLLM builds ONE method per stack.")
        groups[group] = {"rows": rows_each * len(projections), "columns": columns,
                         "roles": [[p, rows_each] for p in projections],
                         "rows_each": rows_each}
    units = []
    for index in indices:
        for group in MOE_GROUPS:
            for projection in MOE_GROUP_PROJECTIONS[group]:
                name, shape = experts[index][projection]
                units.append({"tensor": name, "wire": name[: -len(".weight")] + ".wire",
                              "source_tensor": name, "source_layout": source_layout,
                              "source_slice": {"expert": index, "selector": "whole",
                                               "transpose": False},
                              "expert": index, "projection": projection, "group": group,
                              "rows": shape[0], "cols": shape[1]})
    return {"stack": stack, "family": family, "grid": grid, "q256": int(q256),
            "experts": len(indices), "hidden_size": hidden, "intermediate_size": inter,
            "source_layout": source_layout, "groups": groups, "units": units}


def _stack_config_geometry(config: dict, stack: str) -> tuple[int, int, int]:
    """The three dimensions a source expert stack must prove against config.json.

    One contract for both source layouts (#213): the packed path has always
    read it, and the unpacked path reads the same three numbers, because a
    per-expert 2-D source can silently be a truncated population -- a missing
    tail expert leaves a perfectly contiguous ``0..E-2`` -- and only the
    model's own config says what ``E`` is.
    """
    text = config.get("text_config", config)
    hidden = text.get("hidden_size")
    inter = text.get("moe_intermediate_size", text.get("intermediate_size"))
    experts = next((text.get(key) for key in
                    ("n_routed_experts", "num_experts", "num_local_experts")
                    if text.get(key) is not None), None)
    if not all(isinstance(value, int) and value > 0
               for value in (experts, hidden, inter)):
        raise SystemExit(
            f"cannot validate expert stack {stack}: config.json must declare positive "
            "integer expert count (n_routed_experts/num_experts/num_local_experts), "
            f"hidden_size, and moe_intermediate_size/intermediate_size; got experts={experts!r} "
            f"hidden_size={hidden!r} intermediate_size={inter!r}")
    return experts, hidden, inter


def routed_unit_rank_cut(layout: dict, tp_size: int, tp_rank: int) -> dict:
    """One routed unit's rank-local layout, cut as the runtime cuts it.

    ``serving.moe_route._packed_group_shard_plan`` cuts ``w13`` (gate/up) by
    output rows -- ``intermediate_size // tp`` each -- and ``w2`` (down) by
    input columns, so a down unit keeps its rows and this rank's slice of the
    columns AND of the per-column rates.  TP1 is the whole unit.
    """
    tp_size, tp_rank = int(tp_size), int(tp_rank)
    if tp_size < 1 or not 0 <= tp_rank < tp_size:
        raise SystemExit(f"tensor-parallel rank {tp_rank} of {tp_size} is not a rank")
    rows, cols = int(layout["rows"]), int(layout["cols"])
    rates = layout.get("rates")
    if layout["group"] == "w13":
        if rows % tp_size:
            raise SystemExit(
                f"{layout['projection']} rows {rows} do not divide across {tp_size} ranks")
        return {**layout, "rows": rows // tp_size}
    if cols % tp_size:
        raise SystemExit(
            f"{layout['projection']} columns {cols} do not divide across {tp_size} ranks")
    local = cols // tp_size
    cut = {**layout, "cols": local}
    if rates is not None:
        cut["rates"] = tuple(rates[tp_rank * local:(tp_rank + 1) * local])
    return cut


def require_plannable_unit_layout(layout, q256, target, *, manifest=None):
    """Refuse a mixed unit whose TP sizes cannot be declared from its rung.

    Full/quota-aligned cuts have exact grammar counts for every legal
    placement. Other cuts are accepted only when the actual verified
    manifest has the canonical count/stride the loader can preallocate.
    This runs before the shard is written, never as a late load surprise.
    """
    from tessera.grammar import bresenham_rate_schedule, root_from_q256

    canonical = bresenham_rate_schedule(root_from_q256(q256), int(layout["cols"]), cap=8)
    for size in (1, 2):
        if manifest is not None and size > 1:
            from tessera.layout import can_shard, shard_granularity
            axis = "row" if layout["group"] == "w13" else "column"
            if not can_shard(manifest, size, axis):
                granularity = shard_granularity(manifest)
                raise SystemExit(
                    f"{target}: TP{size} {axis} cut is refused by the wire grammar "
                    f"(granularity {granularity}); refusing before the shard write")
        for rank in range(size):
            try:
                actual = routed_unit_rank_cut(layout, size, rank)
                expected = routed_unit_rank_cut(dict(layout, rates=canonical), size, rank)
            except SystemExit as exc:
                raise SystemExit(f"{target}: TP{size} rank {rank}: {exc}") from exc
            got = (sum(actual["rates"]), len(set(actual["rates"])))
            want = (sum(expected["rates"]), len(set(expected["rates"])))
            if got != want:
                raise SystemExit(
                    f"{target}: TP{size} rank {rank} has rate word/run counts {got}, "
                    f"but q256={q256} declares {want}; a non-aligned importance "
                    "placement is not plannable. Refusing before the shard write.")

def routed_stack_resident_bytes(family: str, experts: int, layouts, *,
                                tp_size: int = 1, tp_rank: int = 0) -> tuple[int, int]:
    """``(unit_bytes, stack_bytes)`` one rank retains of a routed stack.

    ``unit_bytes`` is the sum over expert projections of what the lane holds
    per unit; ``stack_bytes`` the terms the lane holds once per stack: for
    the compact window lane one ``run_off`` per part
    (:func:`~tessera.serving_parts.routed_window_part_resident_bytes`) and,
    when every unit's wire shape admits the fused lane and the projection
    schedules/strides agree across experts (gate/up also share tile_words), its
    composed table (#685), run pair and block descriptors (contract v45,
    tessera#694) per unit (:func:`~tessera.serving_parts.
    routed_fused_unit_bytes`) -- since v45 at every one- or two-rate shape
    the lane reads, not rate 4 alone.  An NVFP4 stack is the stock tile per
    unit and nothing per stack.  ``layouts`` are the units' verified wire
    layouts as the write loop recorded them; a TP cut prices each rank's
    rows/columns/rates through :func:`routed_unit_rank_cut`.
    """
    from tessera.kernel_window_gemv import TILE_ROWS
    from tessera.routed_fused import fused_routed_unit_shape_refusal

    units_total, parts, refused, fused_total = 0, set(), False, 0
    schedules = {}
    for layout in layouts:
        cut = routed_unit_rank_cut(layout, tp_size, tp_rank)
        if family == NVFP4:
            units_total += cut["rows"] * cut["cols"] // 2 + cut["rows"] * cut["cols"] // 16 + 8
            continue
        units_total += routed_window_unit_resident_bytes(
            family, cut["rows"], cut["cols"], cut["rates"],
            window_bits=cut["window_bits"], tile_rows=TILE_ROWS)
        part = "down" if cut["group"] == "w2" else str(cut["projection"]).removesuffix("_proj")
        parts.add(part)
        counts = tuple((rate, cut["rates"].count(rate)) for rate in sorted(set(cut["rates"])))
        signature = (cut["rows"], cut["cols"], int(cut["window_bits"]), counts)
        if schedules.setdefault(part, signature) != signature:
            refused = True
        window_bits = int(cut["window_bits"])
        if fused_routed_unit_shape_refusal(
                "value" if family == BF16 else "e4m3", part, rows=cut["rows"],
                cols=cut["cols"], rates=cut["rates"], window_bits=window_bits) is not None:
            refused = True
        elif not refused:
            fused_total += routed_fused_unit_bytes(window_bits, cut["cols"])
    gate, up = schedules.get("gate"), schedules.get("up")
    if gate is not None and up is not None:
        if sum(r * n for r, n in gate[-1]) != sum(r * n for r, n in up[-1]):
            refused = True
    if family == NVFP4 or not layouts:
        return units_total, 0
    stack_total = len(parts) * routed_window_part_resident_bytes(experts)
    if not refused:
        stack_total += fused_total
    return units_total, stack_total


def plan_packed_expert_stack(stack: str, sources: dict, grid, q256: int, *,
                             source_layout: str, config: dict,
                             research_selected: bool = False):
    """Normalise one explicitly-described packed source to canonical units.

    The convention is deliberately not inferred from shape.  Orientation and
    gate/up split are independent facts, and the square ``hidden == 2 * inter``
    case demonstrates that shape cannot establish even the first one.
    """
    packed_layouts = (MOE_SOURCE_OUT_FIRST_CHUNKED,
                      MOE_SOURCE_IN_FIRST_INTERLEAVED)
    if source_layout not in packed_layouts:
        raise SystemExit(
            f"the packed expert stack {stack} requires source_layout to be one of "
            f"{packed_layouts}, got {source_layout!r}; the tensor does not state its "
            "orientation or whether gate/up is chunked or interleaved")
    if set(sources) != {"gate_up_proj", "down_proj"}:
        raise SystemExit(
            f"the packed expert stack {stack} carries physical projections "
            f"{sorted(sources)}, expected exactly ['down_proj', 'gate_up_proj']. The "
            "supported conventions describe one fused gate/up tensor and one down tensor; "
            "a different roster needs its own explicit source layout.")

    experts, hidden, inter = _stack_config_geometry(config, stack)
    expected = {
        MOE_SOURCE_OUT_FIRST_CHUNKED: {
            "gate_up_proj": (experts, 2 * inter, hidden),
            "down_proj": (experts, hidden, inter),
        },
        MOE_SOURCE_IN_FIRST_INTERLEAVED: {
            "gate_up_proj": (experts, hidden, 2 * inter),
            "down_proj": (experts, inter, hidden),
        },
    }[source_layout]
    for projection, want in expected.items():
        name, shape = sources[projection]
        if tuple(shape) != want:
            raise SystemExit(
                f"the packed expert stack {stack} declares source_layout={source_layout!r}, "
                f"under which {projection} must be {list(want)} from config.json; "
                f"{name} is {list(shape)}. Refusing rather than transposing or slicing a "
                "source whose convention disagrees with its plan.")

    synthetic: dict[int, dict[str, tuple]] = {}
    for expert in range(experts):
        synthetic[expert] = {
            "gate_proj": (f"{stack}.{expert}.gate_proj.weight", (inter, hidden)),
            "up_proj": (f"{stack}.{expert}.up_proj.weight", (inter, hidden)),
            "down_proj": (f"{stack}.{expert}.down_proj.weight", (hidden, inter)),
        }
    record = plan_expert_stack(
        stack, synthetic, grid, q256, source_layout=source_layout, config=config,
        research_selected=research_selected)
    for unit in record["units"]:
        projection = unit["projection"]
        physical_projection = ("gate_up_proj" if projection in
                               ("gate_proj", "up_proj") else "down_proj")
        unit["source_tensor"] = sources[physical_projection][0]
        if source_layout == MOE_SOURCE_OUT_FIRST_CHUNKED:
            selector = {"gate_proj": "first_half", "up_proj": "second_half",
                        "down_proj": "whole"}[projection]
            transpose = False
        else:
            selector = {"gate_proj": "even", "up_proj": "odd",
                        "down_proj": "whole"}[projection]
            transpose = True
        unit["source_slice"] = {
            "expert": unit["expert"], "selector": selector,
            "transpose": transpose,
        }
    record["source_tensors"] = sorted(name for name, _shape in sources.values())
    return record


def packed_expert_weight(source: torch.Tensor, unit: dict) -> torch.Tensor:
    """Slice one canonical ``[rows, columns]`` matrix from a source tensor."""
    if unit.get("source_layout") == MOE_SOURCE_UNPACKED:
        weight = source
    else:
        spec = unit["source_slice"]
        weight = source[int(spec["expert"])]
        selector = spec["selector"]
        if selector == "first_half":
            weight = weight[:unit["rows"]]
        elif selector == "second_half":
            weight = weight[unit["rows"]:]
        elif selector == "even":
            weight = weight[:, 0::2]
        elif selector == "odd":
            weight = weight[:, 1::2]
        elif selector != "whole":
            raise SystemExit(
                f"{unit['tensor']}: unknown packed source selector {selector!r}")
        if spec["transpose"]:
            weight = weight.transpose(0, 1)
    want = (unit["rows"], unit["cols"])
    if tuple(weight.shape) != want:
        raise SystemExit(
            f"{unit['tensor']}: source slice produced {list(weight.shape)}, expected "
            f"canonical expert matrix {list(want)}")
    return weight.contiguous()


def project_expert_plan(source_shapes: dict, source_config: dict,
                        stack_plan: dict, *, research_selected: bool = False) -> dict:
    """JSON producer view of source slices and the groups the exporter writes.

    Header shapes and explicit stack choices go through the same planners as
    export. The result is a plan, not a serving qualification or an allocation
    for any unplanned stack.
    """
    from tessera.control import grid_for_name

    routed = {name: tuple(shape) for name, shape in source_shapes.items()
              if ROUTED_EXPERT_2D.fullmatch(name)}
    packed = {name: tuple(shape) for name, shape in source_shapes.items()
              if PACKED_EXPERT_ND.fullmatch(
                  name if name.endswith(".weight") else name + ".weight")}
    unpacked_stacks, packed_stacks = expert_stacks(routed), packed_expert_stacks(packed)
    overlap = set(unpacked_stacks) & set(packed_stacks)
    if overlap:
        raise SystemExit(f"source stack appears in both packed and unpacked layouts: {sorted(overlap)}")
    unknown = set(stack_plan) - (set(unpacked_stacks) | set(packed_stacks))
    if unknown:
        raise SystemExit(f"producer plan has unknown expert stacks: {sorted(unknown)}")
    result = {}
    for stack, choice in sorted(stack_plan.items()):
        # The choice SHAPE is the published schema's one implementation
        # (#691 item 3): this planner used to repeat its own check, so a
        # producer annotation the schema accepts was refused here after the
        # argument-time gate had accepted it.  ValueError becomes the
        # SystemExit this producer-facing entry point raises.
        try:
            validate_serving_plan({stack: choice})
        except ValueError as exc:
            raise SystemExit(f"{stack}: {exc}") from exc
        grid = grid_for_name(choice["grid"])
        if stack in packed_stacks:
            planned = plan_packed_expert_stack(
                stack, packed_stacks[stack], grid, choice["q256"],
                source_layout=choice.get("source_layout"), config=source_config,
                research_selected=research_selected)
        else:
            layout = choice.get("source_layout", MOE_SOURCE_UNPACKED)
            if layout != MOE_SOURCE_UNPACKED:
                raise SystemExit(f"{stack}: unpacked source requires source_layout={MOE_SOURCE_UNPACKED}")
            planned = plan_expert_stack(stack, unpacked_stacks[stack], grid,
                                        choice["q256"], config=source_config,
                                        research_selected=research_selected)
        assign_expert_unit_rungs(planned, choice.get("unit_q256", {}))
        result[stack] = dict(planned, grid=grid.name)
    return json.loads(json.dumps({"schema": "tessera.expert_projection.v1", "stacks": result}))


def pack_cached_expert_unit(blob: bytes, record: dict, expected_identity: dict):
    """Verify the exact campaign unit and frame it without another encode."""
    from tessera.cached_unit import verify_cached_unit

    accepted = verify_cached_unit(blob, record, expected_identity)
    projection = expected_identity["projection"]
    return accepted, pack_fused([(projection["projection"], projection["rows"], accepted.blob)])


def cached_input_identity(producer, weight, unit_name, unit, grid, q256, *, activation=None):
    """Derive original inputs under the exact producer that wrote the receipt.

    The structure is the one this exporter serves the unit AS: a projected
    ``unit`` is one projection of a routed expert stack, and ``unit is None``
    is a dense Linear.  It picks the served wire the expected identity stamps
    (``served_recipe``, tessera#662).  A historical producer whose identity
    functions predate the ``structure`` argument is asked without it, which is
    exact wherever the served wire is the research one; at a rung where it is
    not (a routed E2M1x2 stack below the cap) no such producer ever wrote the
    served wire, so its receipt is refused by name rather than compared
    against a block it could not have stamped.
    """
    import inspect

    structure = STRUCTURE_DENSE if unit is None else STRUCTURE_ROUTED_MOE
    if producer is None:
        from tessera import cached_unit
        original_grid = grid
        dense_identity = cached_unit.encoding_input_identity
        projected_identity = cached_unit.unit_input_identity
    else:
        original_grid = producer.grid_for_name(grid.name)
        dense_identity = producer.dense_identity
        projected_identity = producer.input_identity
    derive = dense_identity if unit is None else projected_identity
    kwargs = {"activation": activation}
    if "structure" in inspect.signature(derive).parameters:
        kwargs["structure"] = structure
    elif served_recipe(grid, q256, structure) != served_recipe(grid, q256):
        raise ValueError(
            f"{unit_name}: the historical producer that wrote this receipt stamps no "
            f"structure, and a {structure} unit on {grid.name} at q256={q256} is served "
            "on a wire other than the research one; it cannot have written that wire")
    if unit is None:
        return derive(weight, unit_name, original_grid, q256, **kwargs)
    return derive(weight, unit, original_grid, q256, **kwargs)


def _warm_encoder_fixture_id(build) -> None:
    """Fill the encoder identity memo; the caller's own call reports a failure."""
    try:
        build()
    except Exception:
        pass


def default_intake_threads() -> int:
    """One worker per CPU this process may run on: the intake is read + hash bound."""
    try:
        return max(1, len(os.sched_getaffinity(0)))
    except (AttributeError, OSError):
        return max(1, os.cpu_count() or 1)


DEFAULT_INTAKE_WINDOW_BYTES = 8 << 30


def expert_unit_q256(record, unit):
    """The selected rung of this logical source unit, not its executed stack."""
    return int(record.get("unit_q256", {}).get(
        unit["tensor"].removesuffix(".weight"), record["q256"]))


def assign_expert_unit_rungs(record, assignments):
    """Resolve projected names before reading weights; uniform spelling stays exact."""
    names = {u["tensor"].removesuffix(".weight") for u in record["units"]}
    unknown = sorted(set(assignments) - names)
    if unknown:
        raise SystemExit(f"{record['stack']}: unknown projected unit(s) {unknown[:5]}")
    base = module_scheme_key(record["grid"], record["q256"], STRUCTURE_ROUTED_MOE)
    for name, rung in assignments.items():
        if type(rung) is not int or rung <= 0:
            raise SystemExit(f"{name}: unit_q256 must be a positive integer, got {rung!r}")
        if module_scheme_key(record["grid"], rung, STRUCTURE_ROUTED_MOE) != base:
            raise SystemExit(f"{name}: selected rung changes the stack grid/body/plane")
    effective = {name: assignments.get(name, record["q256"]) for name in names}
    if len(set(effective.values())) == 1:
        record["q256"] = next(iter(effective.values()))
        record.pop("unit_q256", None)
    else:
        if record["family"] == NVFP4:
            raise SystemExit(
                f"{record['stack']}: per-unit routed rungs require the WINDOW "
                "E4M3/BF16 loader; mixed NVFP4 expert schedules are not supported")
        record["unit_q256"] = {name: rung for name, rung in sorted(effective.items())
                               if rung != record["q256"]}
    return record


def expert_group_q256(record, group):
    """Reuse the role list; only across-expert differences need a rate matrix."""
    roles = MOE_GROUP_PROJECTIONS[group]
    by_slot = {(u["expert"], u["projection"]): expert_unit_q256(record, u)
               for u in record["units"] if u["group"] == group}
    matrix = [[by_slot[e, role] for role in roles] for e in range(record["experts"])]
    from tessera.serving.scheme import expert_group_q256 as spell_group_q256
    return spell_group_q256(matrix)


def expert_work_units(stack, record):
    """Bind the source slices to their selected unit rung in original plan order."""
    if "unit_q256" not in record:
        return [dict(unit, stack=stack) for unit in record["units"]]
    return [dict(unit, stack=stack, q256=expert_unit_q256(record, unit))
            for unit in record["units"]]


def fresh_expert_units(names, plan, expert_units):
    """One shard's fresh expert units, in the shard loop's commit order.

    The order is the loop's: names in shard order, units in plan order.  The
    cached intake's task list and the joined-encode planner both take this
    sequence, so everything downstream sees the order the shard loop commits.
    A name in ``plan`` is a dense body Linear and never an expert unit; the
    exclusion is stated because it is the seam the two callers share.
    """
    return [(name, unit) for name in names
            if name not in plan and name in expert_units
            for unit in expert_units[name]]


def split_by_shared_schedule(prepared, shared=None):
    """Split prepared members into groups whose shared settings agree.

    ``prepared`` is ``[(unit, weight, mapping)]`` in loop order, each mapping
    exactly what ``ActivationSource.for_unit`` returned.  The batched entry's
    grammar (``encode_linears_planes``) owns which mapping keys must be
    shared and refuses a mixed mapping by key; this owner partitions on the
    mapping's own content -- ``--ldlq-block-budget`` derives each unit's LDLQ
    block from its own Hessian, so one join key can legitimately hold
    differing schedules -- so the exporter splits where the run actually
    differs instead of refusing an otherwise valid multi-unit export.  Groups
    keep first-seen order, members their loop order.
    """
    from tessera.export import SHARED_PER_UNIT_SETTINGS

    shared = SHARED_PER_UNIT_SETTINGS if shared is None else shared
    groups: dict = {}
    for index, (_unit, _weight, mapping) in enumerate(prepared):
        schedule = tuple(sorted((key, mapping[key]) for key in shared if key in mapping))
        groups.setdefault(schedule, []).append(index)
    return list(groups.values())


def fresh_joined_encode(members, *, stack_plan, activation, device, no_verify,
                        batch_observed) -> list:
    """One join key's fresh routed-expert encodes, the exporter's own finish.

    ``members`` is ``[(unit, source tensor)]`` of ONE join key; the return is
    one ``(exported, blob, payload, own_global, manifest)`` per member, in
    member order.  The same per-unit calls the fresh branch makes --
    ``for_unit``, the encode with ``verify``, the manifest off the bytes, the
    container -- with the encode itself one ``encode_linears_planes`` call
    per SHARED SCHEDULE (``split_by_shared_schedule``: differing per-unit
    block schedules are split, not refused; ``--ldlq-block-budget`` derives
    each unit's block from its own Hessian).  Every unit's blob is that
    unit's one-unit blob (``tests/test_batched_encode_identity.py``), so this
    is a machine schedule; each call's width is appended to
    ``batch_observed``, and the manifest records the histogram.  A probe may
    drive this owner directly on real selected units -- original names,
    shapes and Hessians -- and compare every unit against the per-unit path,
    without publishing a checkpoint.

    ``stack_plan`` is the exporter's plan record for the members' stack;
    ``activation`` is the run's ``ActivationSource`` or ``None``.
    """
    stack_spec = stack_plan[members[0][0]["stack"]]
    unit_grid = stack_spec["grid"]
    unit_q256 = expert_unit_q256(stack_spec, members[0][0])
    if any(expert_unit_q256(stack_plan[u["stack"]], u) != unit_q256 for u, _ in members):
        raise ValueError("a joined encode must share the selected per-unit rung")
    unit_recipe = served_recipe(unit_grid, unit_q256, STRUCTURE_ROUTED_MOE)
    prepared = []
    for unit, source in members:
        weight = packed_expert_weight(source, unit).to(device, torch.float32).contiguous()
        mapping = ({} if activation is None else activation.for_unit(
            unit["tensor"], weight.shape[1], device,
            scale_plane=unit_recipe.scale_plane))
        prepared.append((unit, weight, mapping))
    by_unit = {}
    for indices in split_by_shared_schedule(prepared):
        subset = [prepared[i] for i in indices]
        batch_observed.append(len(subset))
        encoded = encode_linears_planes(
            [weight for _unit, weight, _mapping in subset],
            grid=unit_grid, q256=unit_q256,
            names=[unit["tensor"] for unit, _weight, _mapping in subset],
            per_unit=[mapping for _unit, _weight, mapping in subset],
            body=unit_recipe.body, verify=not no_verify)
        for (unit, weight, _mapping), (exported, unit_artifact_, _forests) in zip(subset, encoded):
            del weight
            unit_manifest = parse_unit_artifact(exported.blob, device=device).manifest
            blob = pack_fused([(unit["projection"], exported.rows, exported.blob)])
            payload = torch.frombuffer(bytearray(blob), dtype=torch.uint8).clone()
            by_unit[unit["tensor"]] = (exported, blob, payload,
                                       float(unit_artifact_.scale_global), unit_manifest)
    # Commit in the members' own order, whatever the schedule splits did.
    return [by_unit[unit["tensor"]] for unit, _weight, _mapping in prepared]


def plan_joined_encodes(keys: "list", batch: int) -> "list[list[int]]":
    """Group one shard's fresh expert encodes into joined calls of ``batch`` units.

    ``keys[i]`` is the ``i``-th unit's join key in the shard loop's order: the
    units one ``encode_linears_planes`` call may carry together, which is one
    stack (so one grid, rung and recipe) at one ``[rows, cols]``.  Returns the
    batches as lists of positions.  Each key's units are taken in loop order,
    ``batch`` at a time, so a batch's first position is the earliest of its
    members, and the loop reaches that position before any other member: the
    batch is encoded when its first unit comes up and every later member
    finds its bytes waiting.  A batch never reaches back past a unit the loop
    has already written.
    """
    if batch < 1:
        raise ValueError(f"an encode batch is at least one unit, got {batch}")
    groups: dict = {}
    for position, key in enumerate(keys):
        groups.setdefault(key, []).append(position)
    batches = [members[i:i + batch] for members in groups.values()
               for i in range(0, len(members), batch)]
    return sorted(batches, key=lambda members: members[0])


class JoinedExpertEncode:
    """One shard's fresh routed-expert encodes, ``batch`` same-shape units per call.

    The routed census encodes one expert projection at a time under LDLQ, so
    every window-Viterbi call is one ``ldl_block`` (32) of columns.
    ``encode_linears_planes`` joins ``B`` units' calls along the column axis,
    and every unit's blob is byte-identical to the blob
    ``encode_linear_planes`` writes for it alone, so joining is a machine
    schedule and moves no byte.

    A REAL census checkpoint names every expert projection as its own source
    tensor, so ``expert_units[name]`` holds ONE unit and only grouping ACROSS
    source names within the shard ever joins anything; the key is the unit's
    ``(stack, rows, cols)``, and down/up orientations simply flush as
    different keys.  ``take`` returns ``(exported, blob, payload, own_global,
    manifest)`` for one unit, encoding the unit's whole batch when its first
    member comes up.  Members later in the shard are read from ``handle``
    once and held in ``staged`` until the loop reaches their tensor, which it
    then takes from here instead of reading it again.
    """

    def __init__(self, handle, shard_units, batch, encode):
        self.handle = handle
        self.encode = encode
        self.staged: dict = {}
        self.done: dict = {}
        keys = [(unit["stack"], int(unit["rows"]), int(unit["cols"]), unit.get("q256"))
                for _name, unit in shard_units]
        self.batch_of: dict = {}
        for positions in plan_joined_encodes(keys, batch):
            members = [shard_units[i] for i in positions]
            for _name, unit in members:
                self.batch_of[unit["tensor"]] = members

    def source(self, name):
        """The loop's tensor for ``name``: the staged read if a batch took it, else a fresh one."""
        tensor = self.staged.pop(name, None)
        return self.handle.get_tensor(name) if tensor is None else tensor

    def take(self, name, unit, tensor):
        key = unit["tensor"]
        if key not in self.done:
            members = []
            for member_name, member in self.batch_of[key]:
                if member_name == name:
                    held = tensor
                else:
                    held = self.staged.get(member_name)
                    if held is None:
                        held = self.staged[member_name] = self.handle.get_tensor(member_name)
                members.append((member, held))
            for (member, _held), result in zip(members, self.encode(members)):
                self.done[member["tensor"]] = result
        return self.done.pop(key)


class CachedExpertIntake:
    """Cached expert units read, digested, verified and framed on a thread pool,
    committed on the caller's thread in the order the shard loop writes them.

    The serial loop was the defect (tessera#497): one unit at a time, each a
    source slice off the checkpoint, the cached wire off the bundle, a sha256
    of both and a parse, with nineteen cores idle.  Every one of those steps
    is a file read or a ``hashlib``/tensor op that releases the GIL, so the
    per-unit work runs on ``threads`` workers, ahead of the caller by at most
    ``window_units`` units and ``window_bytes`` of estimated resident bytes,
    across shard boundaries.  ``take`` hands back the next unit in task
    order -- the caller's order -- so the shard payload, the records and the
    manifest are built exactly as the serial loop built them; a worker's
    refusal surfaces at the ``take`` for its unit, in that order, as the same
    exception.

    One ``safe_open`` handle per source shard, shared by the workers (the
    handle is mmap-backed and ``get_tensor`` on it is concurrency-safe) and
    closed once the caller has taken the shard's last unit.
    """

    def __init__(self, src: Path, tasks: list, work, *, threads: int,
                 window_units: int, window_bytes: int, estimate):
        import collections
        import threading
        from concurrent.futures import ThreadPoolExecutor

        if threads < 1 or window_units < 1 or window_bytes < 1:
            raise SystemExit("cached intake needs at least one thread, one unit and one byte of window")
        self.src = src
        self.tasks = tasks
        self.work = work
        self.estimate = estimate
        self.threads = threads
        self.window_units = window_units
        self.window_bytes = window_bytes
        self._pool = ThreadPoolExecutor(max_workers=threads, thread_name_prefix="cached-intake")
        self._handles: dict[str, object] = {}
        self._handle_lock = threading.Lock()
        self._pending = collections.deque()
        self._in_flight_bytes = 0
        self._next_submit = 0
        self._next_take = 0
        self._remaining_per_shard = collections.Counter(shard for shard, _name, _unit in tasks)
        self.peak_in_flight_units = 0
        self.peak_in_flight_bytes = 0

    def handle(self, shard: str):
        with self._handle_lock:
            handle = self._handles.get(shard)
            if handle is None:
                handle = self._handles[shard] = safe_open(str(self.src / shard), framework="pt")
            return handle

    def prime(self):
        """Run the first unit on the caller's thread before any worker starts.

        The first cached unit is the one that witnesses the committed Hessian
        identity and warms every per-process memo (encoder fixture identity,
        producer source seal, capture seal); doing it here keeps those
        first-use paths off the pool.
        """
        if self.tasks and self._next_submit == 0:
            from concurrent.futures import Future
            shard, name, unit = self.tasks[0]
            future = Future()
            try:
                future.set_result(self.work(self.handle(shard), shard, name, unit))
            except BaseException as error:
                future.set_exception(error)
            size = self.estimate(unit)
            self._pending.append((0, future, size))
            self._in_flight_bytes += size
            self._next_submit = 1
        self._fill()

    def _fill(self):
        while self._next_submit < len(self.tasks) and len(self._pending) < self.window_units:
            index = self._next_submit
            shard, name, unit = self.tasks[index]
            size = self.estimate(unit)
            if self._pending and self._in_flight_bytes + size > self.window_bytes:
                break
            future = self._pool.submit(self.work, self.handle(shard), shard, name, unit)
            self._pending.append((index, future, size))
            self._in_flight_bytes += size
            self._next_submit = index + 1
        self.peak_in_flight_units = max(self.peak_in_flight_units, len(self._pending))
        self.peak_in_flight_bytes = max(self.peak_in_flight_bytes, self._in_flight_bytes)

    def take(self, shard: str, name: str, unit: dict):
        """The result for exactly the next task, which must be this unit."""
        index = self._next_take
        if index >= len(self.tasks) or self.tasks[index] != (shard, name, unit):
            raise SystemExit(f"cached intake order broke at {unit.get('tensor')}: "
                             "the shard loop asked for a unit out of task order")
        self._fill()
        taken, future, size = self._pending.popleft()
        assert taken == index
        try:
            result = future.result()
        except BaseException:
            # The refusal is this unit's and it ends the export; nothing
            # queued behind it is wanted.
            self.close()
            raise
        finally:
            self._in_flight_bytes -= size
            self._next_take = index + 1
            self._remaining_per_shard[shard] -= 1
            if self._remaining_per_shard[shard] == 0:
                self._close_handle(shard)
        self._fill()
        return result

    @property
    def taken(self) -> int:
        return self._next_take

    def _close_handle(self, shard):
        with self._handle_lock:
            handle = self._handles.pop(shard, None)
        if handle is not None:
            handle.__exit__(None, None, None)

    def record(self) -> dict:
        return {"threads": self.threads, "window_units": self.window_units,
                "window_bytes": self.window_bytes, "units": len(self.tasks),
                "peak_in_flight_units": self.peak_in_flight_units,
                "peak_in_flight_bytes": self.peak_in_flight_bytes}

    def close(self):
        # Queued units are dropped; a unit already on a worker finishes, so no
        # handle is closed under a worker's borrow of it.
        self._pool.shutdown(wait=True, cancel_futures=True)
        for shard in list(self._handles):
            self._close_handle(shard)


def stock_targets(modules):
    """compressed-tensors targets for member modules plus their fused names (the stock exporter's rule)."""
    found = sorted(set(modules))
    fused_names = set()
    by_prefix: dict[str, set[str]] = {}
    for m in found:
        for pattern, fused, member_names in FUSED:
            match = pattern.match(m + ".weight")
            if match:
                by_prefix.setdefault(match.group(1) + fused, set()).add(match.group(2))
    for fused_name, present in by_prefix.items():
        for pattern, fused, member_names in FUSED:
            if fused_name.endswith(fused) and present == set(member_names):
                fused_names.add(fused_name)
    return [regex_target(m) for m in sorted(set(found) | fused_names)]


def load_producer_authority(path):
    """Load a producer's authority file for cached-unit and Hessian-reference intake.

    ``tessera.producer_authority.load`` does the work, so this exporter and
    every other driver that takes ``--producer-authority`` read the file with
    one set of refusals (tessera#599).
    """
    from tessera.producer_authority import load
    return load(path)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("src", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--shared-candidate-pricing", action="store_true",
                    help="add versioned per-process/rank replay-table composition; legacy unit prices stay intact")
    ap.add_argument("--grid", default="E2M1x2",
                    help="default grid per Linear: E2M1, E2M1x2 (NVFP4), E4M3 (FP8) or BF16 (W16A16)")
    ap.add_argument("--q256", type=int, default=896, help="default body bits per 256 weights")
    ap.add_argument("--plan-json", type=Path, default=None,
                    help='{"tensor.weight": {"grid": "E4M3"|"BF16", "q256": 1024} | '
                         '"PASSTHROUGH", "<moe>.experts": {"grid": "E4M3", '
                         '"q256": 1024, "source_layout": "out_first_chunked"|'
                         '"in_first_interleaved"}, ...}')
    ap.add_argument("--input-scales", type=Path, default=None,
                    help="safetensors carrying <module>.input_global_scale per NVFP4 Linear (a stock NVFP4 "
                         "export); required when any module takes the NVFP4 route")
    ap.add_argument("--priced-inputs", type=Path, default=None,
                    help="preflight build JSON with the expected priced_inputs block")
    ap.add_argument("--priced-inputs-sha256", default=None,
                    help="SHA-256 returned with the preflight build; required with --priced-inputs")
    ap.add_argument("--stock-twin", type=Path, default=None,
                    help="also write the compressed-tensors materialisation of the same wires here")
    ap.add_argument("--device", default="cuda")
    cache_options = ap.add_mutually_exclusive_group()
    cache_options.add_argument("--cached-expert-units", type=Path, default=None,
                    help="closed exact-unit cache manifest for every planned expert; "
                         "missing/unmeasured units refuse, with no re-encode fallback")
    cache_options.add_argument("--cached-units", type=Path, default=None,
                    help="closed exact-unit cache manifest for every planned dense and expert unit; "
                         "requires whole source tensors for dense roles, with no re-encode fallback")
    ap.add_argument("--cached-encoder-source-proof-mode", choices=("strict", "permissive"),
                    default="strict",
                    help="strict requires each encoder adoption's covering source proof; "
                         "permissive records unproven adoptions in cached intake warnings, "
                         "without relaxing identity, digest or wire checks")
    producer_authority_option.add_argument(ap)
    ap.add_argument("--cached-producer-package", type=Path,
                    help="original producer's immutable src/tessera package for cached intake")
    ap.add_argument("--cached-producer-source-sha256",
                    help="full source SHA256 of that original producer package")
    ap.add_argument("--cached-hessian-identity", choices=list(HESSIAN_IDENTITY_MODES),
                    default="committed",
                    help="how cached intake establishes each unit's calibration Hessian "
                         "identity against a --hessian reference document: 'committed' takes "
                         "the document's sealed commitment (exact: the reader refuses any H "
                         "whose identity differs from it, and the cached path consumes no H "
                         "bytes), after one witness unit is derived both ways and required to "
                         "agree; 'digested' reads and digests every unit's H, the path before "
                         "tessera#497. A legacy .pt capture is always digested. Recorded in "
                         "the manifest's cached_units.hessian_identity block; never an "
                         "identity input, since the accepted bytes are the same either way.")
    ap.add_argument("--cached-intake-threads", type=int, default=None,
                    help="workers for the cached expert intake (source slice, wire read, "
                         "digests, verify, framing); default one per CPU this process may "
                         "run on. The commit order is the shard loop's whatever the count.")
    ap.add_argument("--cached-intake-window-bytes", type=int, default=DEFAULT_INTAKE_WINDOW_BYTES,
                    help="bound on the estimated bytes the cached intake holds ahead of the "
                         "shard loop (source slices plus wires), default 8 GiB")
    ap.add_argument("--no-verify", action="store_true")
    ap.add_argument("--encode-batch", type=int, default=1, metavar="UNITS",
                    help="fresh routed-expert encodes joined UNITS same-shape units per "
                         "trellis call (encode_linears_planes); every blob is byte-identical "
                         "to the one-unit encode, and the effective value is recorded in the "
                         "manifest and sealed in a part identity's options, so parts batched "
                         "differently refuse to merge. Default 1: one unit per call.")
    ap.add_argument("--layers", type=int, default=None, help="encode only the first N layers (smoke)")
    ap.add_argument("--partition", type=parse_partition, metavar="INDEX/COUNT",
                    help="write only whole layers owned by layer %% COUNT == INDEX; "
                         "non-body tensors belong to index 0. Merge every part before serving.")
    ap.add_argument("--partition-runtime-image",
                    help="exact repository@sha256 image pinned by the part's dispatch command: "
                         "the READER/runtime the parts are destined to serve on. It is never a "
                         "claim about the process that WROTE the part -- a selected host "
                         "producer's own environment is its authenticated receipt "
                         "(TESSERA_PRODUCER_PYTHON), and it does not execute this image.")
    ap.add_argument("--source-digest-cache", type=Path, default=None,
                    help="directory of stat-bound source shard digests for cached or partition export: a shard "
                         "whose inode, size, mtime_ns and ctime_ns match a recorded full read "
                         "is not re-read for the part's source stamp. Reuse is recorded in "
                         "export_partition.source_digest_receipt, never in the identity.")
    ap.add_argument("--research-selected-moe-json", type=Path,
                    help="explicit versioned packed research execution input; snapshotted once "
                         "and emitted in the checkpoint, without changing encoded wires")
    ap.add_argument("--hessian", type=Path, default=None,
                    help="capture_h_full.py payload: full input Hessians keyed by the tensor's module "
                         "name.  Enables the activation-aware encoder settings below; an encode that "
                         "uses them is not reproducible from the weights alone, so the file's own "
                         "provenance is copied into the manifest.")
    ap.add_argument("--ldlq-sigma", type=float, default=DEFAULT_LDLQ_SIGMA,
                    help="Hessian regulariser for LDLQ cross-column feedback; a negative value turns LDLQ off")
    ap.add_argument("--ldlq-block", type=int, default=DEFAULT_LDLQ_BLOCK, help="LDLQ input-feature block")
    ap.add_argument("--ldlq-block-budget", type=float, default=None,
                    help="derive each unit's LDLQ block from its own Hessian instead "
                         "of stating one: the largest block whose predicted penalty "
                         "against full feedback (compensate.block_penalty) is within "
                         "this ratio, floored at 1 column. Mutually exclusive with "
                         "--ldlq-block. Prices the same axis the two measured "
                         "populations disagree about by a factor of 70 at b=32.")
    ap.add_argument("--refit-metric", default=None,
                    help="error the scale refit minimises: plain | hessian | h^ALPHA. "
                         "Default: the measured objective for each unit's own scale "
                         "plane (export.DEFAULT_REFIT_OBJECTIVE), which is not one "
                         "value -- the exact quadratic on the CHANNEL plane, the "
                         "diagonal h^1.0 on the LUT plane")
    ap.add_argument("--refit-metric-trailing", default=None,
                    help="error the LAST refit minimises, when it should differ from "
                         "--refit-metric: plain | hessian | h^ALPHA, at the SAME pass "
                         "count (tessera#75's fair pair). Unset is the uniform "
                         "schedule -- the encode that was already there, byte for "
                         "byte. Recorded in the checkpoint's activation_aware block "
                         "and compared by the merge guard (tessera#103), so a part "
                         "encoded under one trailing objective cannot merge with a "
                         "part encoded under another.")
    ap.add_argument("--refit-reach-floor", action="store_true",
                    help="hold every refit row scale high enough that the pass's target stays inside the body's reach")
    ap.add_argument("--passthrough-unrouted", action="store_true",
                    help="pass a Linear the pinned runtime will not route through this plugin "
                         "through at source precision instead of refusing the export. The SAFE "
                         "direction: it never writes a wire nothing executes. See "
                         "unrouted_modules.")
    ap.add_argument("--allow-unrouted", action="store_true",
                    help="write the wire anyway for a Linear the pinned runtime will not route "
                         "(or that no census covers). A RESEARCH escape: the module keeps "
                         "vLLM's BF16 method, the weight it wants is not in the checkpoint, and "
                         "the refusal is stamped verbatim into the manifest's serving_gate "
                         "block.")
    ap.add_argument("--fit-tp-size", type=int, default=1, metavar="TP",
                    help="tensor-parallel size the manifest's totals.per_rank fit block prices "
                         "each routed stack's rank-local cut and the MTP draft's embed/head "
                         "duplicate for (tessera#624, #645). The artifact itself stays "
                         "TP-agnostic; this only changes the per-rank accounting.")

    ap.add_argument("--require-lane", action="append", default=None, metavar="LANE",
                    help="refuse the PLAN unless every wire it writes can be read by LANE -- a "
                         "lane named by the extension module_name_prefix runtime_contract.json "
                         "publishes it under (tessera_window_gemv). A lane is one launch inside "
                         "a route, and its eligibility is a function of the RUNG: a rung is a "
                         "root rate and bresenham mixes the two rates bracketing it, so q256 "
                         "1006 (root 3.93) is columns at rate 3 and 4 and every unit of that "
                         "checkpoint refuses the window GEMV at load -- silently, module by "
                         "module, while the census meant to measure the lane records the "
                         "fallback (issue #104). Checked at ARGUMENT time, before one unit is "
                         "encoded, and stamped into the manifest as requires_lanes so the "
                         "census requires it off the bytes. Repeatable.")
    ap.add_argument("--allow-unserveable", action="store_true",
                    help="write wires this plugin build publishes no decode for (see check_recipe). "
                         "The checkpoint is then a RESEARCH artifact that will not load under this "
                         "plugin; every refusal is stamped verbatim into the manifest's "
                         "serving_gate block. Admission depends on the selected recipe's "
                         "published runtime contract, including BF16 recipes.")
    args = ap.parse_args()
    if bool(args.cached_producer_package) != bool(args.cached_producer_source_sha256):
        ap.error("historical cached producer package and source SHA256 must be paired")
    if args.cached_producer_package is not None and not (args.cached_units or args.cached_expert_units):
        ap.error("historical cached producer requires cached unit intake")
    if args.encode_batch < 1:
        ap.error(f"--encode-batch is at least one unit, got {args.encode_batch}")
    if args.encode_batch > 1 and (args.cached_units or args.cached_expert_units):
        ap.error("--encode-batch joins fresh expert encodes; cached unit intake encodes nothing")
    # The selected producer is authenticated BEFORE any source or output
    # operation: a refusal must cost nothing, and the receipt below seals
    # into the partition identity.
    producer_receipt = authenticate_producer_python()
    producer_authority = canonical_capture = None
    if args.producer_authority is not None:
        producer_authority, canonical_capture = load_producer_authority(args.producer_authority)
    research_execution = None
    if args.research_selected_moe_json is not None:
        from tessera.moe_execution import ResearchSelectedMoeInput
        try:
            research_execution = ResearchSelectedMoeInput.read(args.research_selected_moe_json)
        except (OSError, ValueError) as exc:
            raise SystemExit(f"--research-selected-moe-json: {exc}") from exc
        if args.stock_twin is not None:
            raise SystemExit("research_selected_moe refuses --stock-twin")
        if args.allow_unserveable:
            raise SystemExit("research_selected_moe has its own decoder gate and refuses --allow-unserveable")
    if (args.priced_inputs is None) != (args.priced_inputs_sha256 is None):
        ap.error("--priced-inputs and --priced-inputs-sha256 must be supplied together")
    priced_inputs = (PricedInputsSnapshot(args.priced_inputs, args.priced_inputs_sha256)
                     if args.priced_inputs is not None else None)
    if args.partition:
        if args.stock_twin is not None:
            ap.error("--partition does not support --stock-twin; assemble the wire checkpoint first")
        if args.out.exists():
            ap.error(f"partition output already exists: {args.out}; use a fresh directory")
        if not args.partition_runtime_image:
            ap.error("--partition requires --partition-runtime-image")
    elif args.partition_runtime_image:
        ap.error("--partition-runtime-image requires --partition")

    # Fail fast on an unstampable commit (tessera#714): the manifest and the
    # stock twin both stamp this value at the end, long after the shard
    # writes. Resolving once, here -- before any byte is written -- turns a
    # streamed whole-model export into an up-front refusal with the same
    # message. The git, TESSERA_GIT and install paths resolve identically
    # at start and at end; nothing below re-resolves.  A SELECTED producer
    # stamps its receipt's verified head instead: a wheel built from a local
    # source archive has neither .git above it nor a direct_url commit, and
    # the receipt's exact Git payload proof is the stronger authority --
    # a HEAD or environment assertion alone never substitutes for it.
    tessera_commit = (producer_receipt["git_head"] if producer_receipt is not None
                      else git_hash())

    # The --input-scales bytes are read ONCE, here, before anything seals a
    # digest of them: the identity's input_scales_sha256 and the scalars the
    # roles consume are one object (read_input_scales).
    input_scales, input_scales_sha256 = read_input_scales(args.input_scales)

    # The activation-aware settings fire when, and only when, a Hessian is
    # here: the encoder cannot invent one, and a weights-only export must stay
    # the byte-for-byte artifact it was.  Given one, the defaults are the
    # measured recipe (export.DEFAULT_LDLQ_*), overridable per run.  The recipe
    # itself lives in ``ActivationSource``, not here: this script and the
    # library exporters must not carry two copies of it, which is the drift
    # that let the library path encode weights-only while the script did not.
    activation = None
    if args.hessian:
        block: "int | dict" = args.ldlq_block
        if args.ldlq_block_budget is not None:
            if "--ldlq-block" in sys.argv:
                ap.error("--ldlq-block and --ldlq-block-budget both state the "
                         "block: one names it, the other derives it. Pass one.")
            block = {"max_penalty": args.ldlq_block_budget}
        settings = {"ldlq_sigma": args.ldlq_sigma, "ldlq_block": block,
                    "refit_reach_floor": args.refit_reach_floor}
        if args.refit_metric is not None:      # else: the measured per-plane map
            settings["refit_objective"] = args.refit_metric
        if args.refit_metric_trailing is not None:   # else: the uniform schedule
            settings["refit_objective_trailing"] = args.refit_metric_trailing
        activation = ActivationSource.from_capture(args.hessian, canonical_capture=canonical_capture,
                                                   **settings)

    default_grid = grid_for(args.grid)
    # THE PLAN IS READ ONCE, HERE, and this snapshot is the only plan the rest
    # of the run knows about: planning, a partition's sealed identity, the
    # pre-publication gate and the manifest all read it rather than the file
    # (#301).  A ``--plan-json`` path is a mutable file and an export is long.
    plan_snapshot = PlanSnapshot.read(args.plan_json) if args.plan_json else None
    if plan_snapshot is not None:
        print(f"plan: {plan_snapshot.path} sha256={plan_snapshot.sha256} "
              f"({len(plan_snapshot.entries)} entries), read once", flush=True)
    # Every path into the encode loop passes through here: a tensor takes the
    # default (grid, q256) or a --plan-json override, and both are gated before
    # a single unit is encoded.
    gate_overrides: list = []
    research_gate_records: list = []
    required_lanes = list(dict.fromkeys(args.require_lane or ()))
    check_recipe(default_grid, args.q256,
                 allow_unserveable=args.allow_unserveable, overrides=gate_overrides)
    check_lanes(required_lanes, default_grid, args.q256)
    src_config = json.loads((args.src / "config.json").read_text())
    # The HF architecture name keys the dense-owner rule's per-architecture
    # data (``SEPARATE_QKV_ARCHITECTURES``, tessera#706); derived once here
    # and threaded to every ``fused_module``/``ignored_modules`` call below.
    architecture = (list(src_config.get("architectures") or ()) or [None])[0]
    selected_names = set(plan_snapshot.entries) if plan_snapshot is not None else set()
    shards, shapes, expert_shapes, routed_shapes = quantizable(args.src, selected=selected_names)
    source_tensor_names = {name for names in shards.values() for name in names}
    if not shapes and not expert_shapes and not routed_shapes:
        raise SystemExit(
            f"no body weight tensors found under {args.src}. BODY_LAYER matches "
            f"``model.<...>.layers.<N>.``; this checkpoint's names do not, so there is nothing "
            "to export rather than nothing to do.")

    # THE EXECUTED MODULE REMAINS THE ROUTED STACK. Its expert projections
    # are plannable through unit_q256 inside the stack entry; top-level
    # leaf declarations still falsely claim dense Linears the runtime never builds.
    # This split happens before plan application, because a plan entry
    # depends on it: a stack is served as ``routed_moe`` and is held to that
    # structure's attested rungs, not to the dense reader's range (#135).
    stacks = expert_stacks(routed_shapes)
    packed_stacks = packed_expert_stacks(expert_shapes)
    overlap = sorted(set(stacks) & set(packed_stacks))
    if overlap:
        raise SystemExit(
            f"expert stack(s) {overlap} exist in both unpacked per-expert and packed 3-D "
            "source layouts. They are two sources for the same runtime tile; refusing rather "
            "than letting checkpoint or shard order choose which bytes are served.")
    overrides = {}
    source_layout_overrides: dict[str, str] = {}
    if plan_snapshot is not None:
        for name, spec in plan_snapshot.entries.items():
            if spec in ("BF16", "PASSTHROUGH"):
                # The bare string is PASSTHROUGH -- copy the source tensor,
                # quantise nothing.  ``{"grid": "BF16", "q256": N}`` is the
                # opposite: the 16-bit trellis route at rate N, whose tile is
                # bf16 but whose wire is 4-8 bpp.  ``"BF16"`` is kept as a
                # spelling of passthrough because plans were written with it;
                # ``"PASSTHROUGH"`` is the one that cannot be misread.
                overrides[name] = None
            else:
                g = grid_for(spec["grid"])
                structure = (STRUCTURE_ROUTED_MOE if name in stacks or name in packed_stacks
                             else STRUCTURE_DENSE)
                check_recipe(g, int(spec["q256"]), where=name, structure=structure,
                             allow_unserveable=args.allow_unserveable, overrides=gate_overrides,
                             research_selected=(research_execution.config
                                                if research_execution is not None else None),
                             research_records=research_gate_records)
                check_lanes(required_lanes, g, int(spec["q256"]), where=name,
                            structure=structure)
                overrides[name] = (g, int(spec["q256"]))
                if "source_layout" in spec:
                    source_layout_overrides[name] = spec["source_layout"]
    all_stacks = {**stacks, **packed_stacks}
    stack_overrides = {name: overrides.pop(name)
                       for name in sorted(set(overrides) & set(all_stacks))}

    # A routed expert LEAF must be refused HERE -- before a single unit is
    # encoded.  These leaves are 2-D, so the only thing standing between them
    # and being planned as dense Linears is this check.
    planned_routed = sorted(set(overrides) & set(routed_shapes))
    if planned_routed:
        first = planned_routed[0]
        raise SystemExit(
            f"the plan names {len(planned_routed)} ROUTED expert tensor(s), e.g. {first} "
            f"{list(routed_shapes[first])}. A routed expert is not a dense Linear: vLLM builds "
            "one FusedMoE module per layer, not one Linear per expert, so a checkpoint declaring "
            f"{module_of(first)} in config_groups names a module vLLM never creates and the "
            "plugin refuses it at load. The expert route is not what is missing -- name the "
            f"STACK instead: a plan entry keyed {module_of(first).rsplit('.experts.', 1)[0]}"
            ".experts sets the common scheme and baseline rung; unit_q256 inside that entry "
            "overrides individual expert projections. Or remove "
            "these entries to pass the stack through as BF16.")
    planned_experts = sorted(set(overrides) & set(expert_shapes))
    if planned_experts:
        first = planned_experts[0]
        raise SystemExit(
            f"the plan names {len(planned_experts)} packed expert tensor(s), e.g. {first} "
            f"{list(expert_shapes[first])}. A packed expert tensor is not a plannable module: "
            "vLLM builds one method for the whole stack. Name <moe>.experts instead and state "
            f"source_layout as one of {(MOE_SOURCE_OUT_FIRST_CHUNKED, MOE_SOURCE_IN_FIRST_INTERLEAVED)}, "
            "or remove the physical entry to pass the stack through at source precision.")
    misplaced_layouts = sorted(set(source_layout_overrides) - set(stack_overrides))
    if misplaced_layouts:
        raise SystemExit(
            f"source_layout is a routed-MoE stack property, but the plan attaches it to "
            f"{misplaced_layouts[:5]}. Put it on <moe>.experts; a dense tensor or physical "
            "expert leaf has no packed-source convention to apply.")
    unknown = sorted(set(overrides) - set(shapes))
    if unknown:
        raise SystemExit(f"plan names tensors that are not 2-D body weights here: {unknown[:5]}; "
                         f"a routed-MoE stack is planned under its own name "
                         f"({sorted(stacks)[0] if stacks else '<moe>.experts'}), not per leaf")

    # THE EXPERT PLAN, gated before the first encode.  Every check the plugin's
    # expert route makes at load has a producer-side twin here, because a
    # refusal that arrives after 864 units is not a refusal; it is a bill.
    stack_plan: dict[str, dict] = {}
    for stack in sorted(stack_overrides):
        spec = stack_overrides[stack]
        if spec is None:                     # PASSTHROUGH, spelled deliberately
            continue
        grid, q256 = spec
        source_layout = source_layout_overrides.get(stack)
        if stack in packed_stacks:
            if source_layout not in (MOE_SOURCE_OUT_FIRST_CHUNKED,
                                     MOE_SOURCE_IN_FIRST_INTERLEAVED):
                raise SystemExit(
                    f"the packed expert stack {stack} requires source_layout to be one of "
                    f"{(MOE_SOURCE_OUT_FIRST_CHUNKED, MOE_SOURCE_IN_FIRST_INTERLEAVED)}, "
                    f"got {source_layout!r}; dimensions do not state orientation or the "
                    "gate/up split")
            source_name = next(iter(packed_stacks[stack].values()))[0]
        else:
            if source_layout not in (None, MOE_SOURCE_UNPACKED):
                raise SystemExit(
                    f"the unpacked expert stack {stack} has one 2-D tensor per expert and "
                    f"requires source_layout={MOE_SOURCE_UNPACKED!r} when the field is "
                    f"present, got {source_layout!r}")
            source_layout = MOE_SOURCE_UNPACKED
            source_name = next(iter(stacks[stack].values()))["gate_proj"][0]
        layer = body_layer(source_name)
        if args.layers is not None and layer >= args.layers:
            raise SystemExit(
                f"the plan gives the expert stack {stack} a rung, but --layers {args.layers} "
                f"stops before its layer {layer}. One of the two is wrong and guessing which "
                "would either skip a stack the plan asked for or encode past the smoke bound.")
        if stack in packed_stacks:
            record = plan_packed_expert_stack(
                stack, packed_stacks[stack], grid, q256,
                source_layout=source_layout, config=src_config,
                research_selected=research_execution is not None)
        else:
            record = plan_expert_stack(
                stack, stacks[stack], grid, q256, source_layout=source_layout,
                config=src_config, research_selected=research_execution is not None)
        assign_expert_unit_rungs(record, plan_snapshot.entries[stack].get("unit_q256", {}))
        if plan_snapshot.entries[stack].get("unit_q256"):
            for unit in record["units"]:
                rung = expert_unit_q256(record, unit)
                check_recipe(grid, rung, where=unit["tensor"], structure=STRUCTURE_ROUTED_MOE,
                             allow_unserveable=args.allow_unserveable, overrides=gate_overrides,
                             research_selected=(research_execution.config
                                                if research_execution is not None else None),
                             research_records=research_gate_records)
                check_lanes(required_lanes, grid, rung, where=unit["tensor"],
                            structure=STRUCTURE_ROUTED_MOE)
        if "unit_q256" in record:
            cliff = (f"{stack}: per-unit routed schedules have no served qualification; "
                     "divergent expert schedules or gate/up strides require the compact adapter. "
                     "Mixed schedules are research-only until served GPU/performance "
                     "qualification; no cell, default or serving pin is promoted.")
            if required_lanes or (research_execution is None and not args.allow_unserveable):
                raise SystemExit(cliff + " Use explicit research export (--allow-unserveable).")
            gate_overrides.append({"target": stack, "structure": STRUCTURE_ROUTED_MOE,
                                   "refusal": cliff})
        stack_plan[stack] = record
        print(f"  routed_moe {stack}: {record['experts']} experts x "
              f"{len(EXPERT_PROJECTIONS)} projections at {grid.name} q256={q256} "
              f"({len(record['units'])} units, source_layout={source_layout})", flush=True)
    packed_plans = sorted(stack for stack in stack_plan
                          if stack_plan[stack]["source_layout"] != MOE_SOURCE_UNPACKED)
    if research_execution is not None:
        try:
            research_execution.config.require_targets({
                name: {"structure": "routed_moe", "family": record["family"],
                       "grid": record["grid"].name}
                for name, record in stack_plan.items()}, "resident")
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
    # Complete cached intake verifies each logical source slice and its exact H
    # against the original wire receipt below; it never calls the encoder.
    # Keep the packed-H encode path closed, including expert-only cache mode.
    if activation is not None and packed_plans and args.cached_units is None:
        raise SystemExit(
            f"--hessian was given with packed expert stack(s) {packed_plans}. Only complete "
            "--cached-units intake accepts logical per-expert Hessians with authenticated "
            "source slices and original-wire receipts. Packed-H encoding is not attested; "
            "refusing rather than silently encoding those experts weights-only.")
    if stack_plan and args.stock_twin is not None:
        raise SystemExit(
            f"--stock-twin was given and {len(stack_plan)} routed-MoE stack(s) are planned. The "
            "twin is the materialised compressed-tensors comparator, and this exporter writes no "
            "per-channel FP8 expert twin: the stacks' source tensors are consumed by the encode, "
            "so the twin would silently be a checkpoint with no experts in it. Export the stacks "
            "without a twin, or leave them out of the plan.")

    packed_passthrough = {name: shape for name, shape in expert_shapes.items()
                          if next(m for m in ignored_modules(name, shape, architecture, config=src_config)) not in stack_plan}
    if packed_passthrough:
        print(f"  {len(packed_passthrough)} unplanned packed expert tensors stay at source "
              f"precision and are named in ignore; e.g. {sorted(packed_passthrough)[0]}",
              flush=True)
    routed_passthrough = {n: shape for n, shape in routed_shapes.items()
                          if ROUTED_EXPERT_2D.match(n).group("moe") + ".experts" not in stack_plan}
    if routed_passthrough:
        layers = sorted({body_layer(n) for n in routed_passthrough})
        print(f"  {len(routed_passthrough)} routed expert tensors across layers {layers} stay "
              f"BF16 and are named in ignore (no plan entry names their stack); "
              f"e.g. {sorted(routed_passthrough)[0]}", flush=True)
    # An EXPLICIT quantized plan entry is an obligation (#211): the merge path
    # holds a partitioned export to it through validate_explicit_plan, and the
    # direct export is held to the same rule -- a target the plan names may be
    # refused here, before the first encode, but never silently demoted to
    # BF16 passthrough.  Implicit --grid/--q256 defaults keep their deliberate
    # passthrough fallbacks; explicit "PASSTHROUGH"/"BF16" stays a passthrough.
    explicit = {name for name, spec in overrides.items() if spec is not None}
    plan: dict[str, tuple] = {}          # tensor -> (grid, q256, rows, cols)
    passthrough: list[str] = []
    for name, (rows, cols) in shapes.items():
        layer = body_layer(name) if BODY_LAYER.match(name) else None
        if args.layers is not None and (args.layers == 0 or layer is not None and layer >= args.layers):
            if name in explicit:
                raise SystemExit(
                    f"the plan gives {name} a rung, but --layers {args.layers} stops before "
                    f"its layer {layer}. One of the two is wrong and guessing which would "
                    "either pass through a tensor the plan asked for or encode past the "
                    "smoke bound. Name it PASSTHROUGH, or raise --layers.")
            passthrough.append(name); continue
        if name in overrides and overrides[name] is None:
            passthrough.append(name); continue
        if MOE_ROUTER.match(name) and name not in explicit:
            passthrough.append(name); continue
        grid, q256 = overrides.get(name, (default_grid, args.q256))
        if rows % (grid.arity * 32) or cols % 16:
            if name in explicit:
                raise SystemExit(
                    f"the plan names {name} at {grid.name} q256={q256}, but its shape "
                    f"[{rows}, {cols}] cannot be cut on that grid: rows must be a whole "
                    f"number of tuples (grid.arity * 32 = {grid.arity * 32}) and columns a "
                    "multiple of 16. An explicit rung is an obligation, so this is refused "
                    "rather than silently demoted to BF16 passthrough; name the tensor "
                    "PASSTHROUGH to keep it at source precision deliberately.")
            passthrough.append(name); continue
        plan[name] = (grid, q256, rows, cols)
    # Group by vLLM module: every role quantizable, and every role on the same
    # ``module_scheme_key`` -- one family/grid/body/plane.  The RATE may differ
    # per role (#37); see ``module_scheme_key``.
    modules: dict[str, list[str]] = {}
    for name in list(plan):
        fused = fused_module(name, architecture, config=src_config, tensor_names=source_tensor_names)
        if fused is None:
            modules[module_of(name)] = [name]
            continue
        key, members = fused
        if key in modules:
            continue
        recipes = {module_scheme_key(plan[m][0], plan[m][1]) for m in members if m in plan}
        if all(m in plan for m in members) and len(recipes) == 1:
            modules[key] = list(members)
        else:
            why = "not every role is quantizable" if not all(m in plan for m in members) else f"roles disagree {sorted(recipes)}"
            named = sorted(m for m in members if m in explicit)
            if named:
                # The exporter's resolution for a disagreeing group is a whole-
                # group BF16 passthrough, and for implicitly planned members
                # that is the deliberate default.  For a member the plan NAMES
                # quantized it is a silent demotion of an explicit rung (#211).
                raise SystemExit(
                    f"fused module {key}: {why}, and the plan explicitly quantizes {named}. "
                    "vLLM builds one method per fused module, so the exporter would pass the "
                    "whole group through as BF16 -- a checkpoint that does not implement its "
                    "plan. Plan every member of the group onto one scheme (family, grid, "
                    "body, scale plane), or name them all PASSTHROUGH.")
            print(f"  passthrough {key}: {why}; vLLM builds one method per fused module", flush=True)
            for m in members:
                if m in plan:
                    del plan[m]
                    passthrough.append(m)
    owned = {m for members in modules.values() for m in members}
    assert owned == set(plan)
    if not plan and not stack_plan and args.layers != 0:
        # An export that quantized NOTHING used to report success and write a
        # checkpoint with an empty ``config_groups``, which the plugin refuses
        # at load ("a Tessera checkpoint declares its wires in
        # config_groups").  Same shape of fault as #86: silent here, expensive
        # there.  ``--layers 0`` is how a passthrough copy is asked for on
        # purpose, so it stays legal -- and ONLY it.  ``--layers N`` for N > 0
        # is a smoke bound, not a request for a passthrough copy: the caller
        # asked for a partial encode, and an encode that produced nothing is
        # the same fault under a smaller roster (#391).
        raise SystemExit(
            f"nothing was planned: all {len(shapes)} dense body weights were passed through. A "
            "Linear is planned only when its rows are a whole number of tuples (grid.arity * 32) "
            "and its columns a multiple of 16; a plan naming PASSTHROUGH, or a menu whose grid "
            "no tensor here fits, leaves nothing to encode. The checkpoint would carry an empty "
            "config_groups and the plugin refuses that at load. Pass --layers 0 to write a "
            "passthrough copy deliberately.")

    # THE CONSTRUCTION GATE, and it is placed here for the same reason
    # ``check_recipe`` is placed at argument time: before the first encode.  A
    # refusal that arrives after the encode is not a refusal; it is a bill.
    # It runs on the MODULE names, not the tensor names, because the module is
    # what the runtime builds and what ``config_groups`` will declare.
    unrouted, census = unrouted_modules(src_config, list(modules) + list(stack_plan))
    strict_unrouted = [module for module in unrouted
                       if module in modules and any(member in explicit for member in modules[module])
                       and (module.endswith((".indexer.wk_weights_proj", ".kv_b_proj"))
                            or any(MOE_ROUTER.match(member) for member in modules[module]))]
    if strict_unrouted:
        raise SystemExit("selected router or direct consumer has no declared runtime route: "
                         + str(strict_unrouted))
    unrouted_records = [
        {"module": module, "vllm_module_pattern": pattern, "verdict": verdict}
        for module, (verdict, pattern) in sorted(unrouted.items())]
    if unrouted:
        message = _unrouted_refusal(unrouted, list(src_config.get("architectures") or ()))
        if args.passthrough_unrouted:
            # The flag resolves modules the DEFAULT planned; a module the plan
            # explicitly quantizes is an obligation (#211), and shedding it
            # here would publish a checkpoint validate_explicit_plan refuses
            # at merge and nothing used to refuse in the direct path.
            named = sorted(
                module for module in unrouted
                if module in stack_plan
                or any(m in explicit for m in modules.get(module, ())))
            if named:
                raise SystemExit(
                    f"--passthrough-unrouted would pass through {named}, but the plan "
                    "explicitly gives them a rung. An explicit rung is an obligation "
                    "(serving_parts.validate_explicit_plan); passing these modules through "
                    "would publish a checkpoint that does not implement its plan. Remove "
                    "them from the plan (or name them PASSTHROUGH) to export the rest.")
            print(f"  --passthrough-unrouted: {message}", flush=True)
            for module in unrouted:
                if module in stack_plan:
                    # A stack is one module with no members in ``plan``: drop
                    # the whole stack and its experts pass through as BF16,
                    # named in ignore by the same rule as any other.
                    del stack_plan[module]
                    continue
                for member in modules.pop(module):
                    del plan[member]
                    passthrough.append(member)
            print(f"  {len(unrouted)} module(s) pass through at source precision; "
                  f"{len(modules)} module(s) remain in the plan", flush=True)
            if not plan and not stack_plan and args.layers != 0:
                # The same refusal as above, re-asked, because the check above
                # ran BEFORE this loop and this loop is another way ``plan``
                # empties.  Without it, --passthrough-unrouted on a model whose
                # every module is unrouted writes the empty ``config_groups``
                # the earlier guard exists to prevent -- and it is the likelier
                # path of the two, since a wholly unrouted architecture is
                # exactly when someone reaches for the flag.  ``--layers 0``
                # is exempt; a smoke bound is not (#391).
                raise SystemExit(
                    f"nothing is left to encode: --passthrough-unrouted passed "
                    f"through all {len(unrouted)} unrouted module(s) and no "
                    "module remains in the plan. The checkpoint would carry an "
                    "empty config_groups and the plugin refuses that at load. "
                    "This architecture has no module the pinned runtime routes "
                    "to a Tessera method: census it first, or pass --layers 0 "
                    "to write a passthrough copy deliberately.")
        elif args.allow_unrouted:
            print(f"  --allow-unrouted: {message}", flush=True)
        else:
            raise SystemExit(
                f"{message}\n\n"
                "This is a fact about the pinned runtime, read from "
                "runtime_contract.json's construction block (contract v"
                f"{load_serving_contract()['contract_version']}), which is generated from the "
                "census receipts under docs/measurements/construction/. Pass "
                "--passthrough-unrouted to export these at source precision (the safe fix), or "
                "--allow-unrouted to write the dead wire anyway as a research artifact -- the "
                "refusal is then stamped into the manifest's serving_gate block.")
    owned = {m for members in modules.values() for m in members}
    assert owned == set(plan)

    # THE GEOMETRY GATE (tessera#377), after the construction gate because it
    # reads the same census entry.  A module's roles are the runtime's output
    # partitions in the runtime's order -- ``sharding.plan_shard`` pairs the
    # two lists by position and refuses a length mismatch -- so the roles are
    # DERIVED from the attested ``output_sizes`` rather than from the tensor
    # names: LFM2's ``short_conv.in_proj`` is ONE checkpoint tensor that the
    # runtime builds as ``MergedColumnParallelLinear(output_sizes=[dim]*3)``,
    # and the one-role container the name rule produced was refused at load.
    # A census that predates the field attests nothing; the roles are then the
    # tensors, as before, and the manifest says the geometry was not checked.
    partitions: dict[str, tuple] = {}
    direct_consumer_costs = {}
    geometry_unattested: list[str] = []
    geometry_passthrough: list[str] = []
    for module, members in list(modules.items()):
        sizes = None if census is None else output_partitions(census, module)
        if sizes is None:
            geometry_unattested.append(module)
        try:
            parts = partition_members(module, members, {m: plan[m][2] for m in members}, sizes,
                                      padding_rows=source_padding_rows(module, members, src_config))
        except ValueError as exc:
            raise SystemExit(
                f"{exc}. The partition list is the pinned runtime's, read from the construction "
                "census (contract.output_partitions); a checkpoint declaring different roles "
                "is refused at load by sharding.plan_shard, so it is refused here instead.")
        unfit = [part for part in parts
                 if part.rows % (plan[part.tensor][0].arity * 32)]
        if unfit:
            # The same shape rule the per-tensor plan applied, re-asked on the
            # row slice the runtime actually builds; the same resolution too.
            named = sorted({part.tensor for part in unfit} & set(explicit))
            if named:
                raise SystemExit(
                    f"{module}: the plan names {named} at a grid whose tuples (grid.arity * 32) "
                    f"do not divide the runtime's output partitions {sizes}; an explicit rung is "
                    "an obligation, so this is refused rather than silently passed through.")
            print(f"  passthrough {module}: output partitions {sizes} are not whole tuples on "
                  "the planned grid", flush=True)
            geometry_passthrough.append(module)
            for m in modules.pop(module):
                del plan[m]
                passthrough.append(m)
            continue
        partitions[module] = parts
        if module.endswith((".indexer.wk_weights_proj", ".kv_b_proj")):
            try:
                from tessera.serving.projection_routes import direct_consumer_resident_bytes
            except ImportError as exc:
                raise SystemExit(f"{module}: the direct weight consumer needs its runtime adapter") from exc
            direct_consumer_costs[module] = direct_consumer_resident_bytes(
                module, family_for(plan[members[0]][0]), sum(part.rows for part in parts),
                plan[members[0]][3], [(part.role, part.rows) for part in parts])
    if args.stock_twin is not None and architecture == "Glm5NextForConditionalGeneration":
        unsupported_twins = [module for module, members in modules.items()
                             if (".self_attn." in module or ".visual." in module or MOE_ROUTER.match(members[0]))
                             and family_for(plan[members[0]][0]) != BF16]
        if unsupported_twins:
            raise SystemExit(f"the stock consumer has no quantized constructor for {unsupported_twins}; "
                             "export the Tessera artifact without a compressed stock twin")
    if not plan and not stack_plan and args.layers != 0:
        # The THIRD way ``plan`` empties, and the same refusal as the two
        # above.  The geometry gate runs after both of them, so a module that
        # passed the construction gate can still be demoted here -- for a row
        # slice the runtime builds, not for anything the per-tensor plan could
        # see -- and when it was the last one the export returned normally and
        # wrote the empty ``config_groups`` the plugin refuses at load
        # (``TesseraConfig.from_config``: "a Tessera checkpoint declares its
        # wires in config_groups").  The implicit default is where this bites:
        # a module the plan names explicitly is refused a few lines up,
        # because an explicit rung is an obligation.  ``--layers 0`` stays
        # legal, as it is in both siblings: it is how a passthrough copy is
        # asked for on purpose.  ``--layers N`` for N > 0 does NOT: it is a
        # smoke bound, and #391 reproduced this exact fault through it on the
        # branch that closed #387 -- the exemption was wider than its reason.
        raise SystemExit(
            "nothing is left to encode: the geometry gate passed through "
            f"{len(geometry_passthrough)} module(s) that were still planned, because the "
            "runtime's output partitions are not whole tuples (grid.arity * 32) on the "
            "planned grid, and no module remains in the plan. The "
            "partition list is the pinned runtime's, read from the construction census "
            "(contract.output_partitions), so this is a fact about how the runtime builds these "
            "Linears and not about the checkpoint. The checkpoint would carry an empty "
            "config_groups and the plugin refuses that at load. Plan a grid whose tuples divide "
            "these partitions, or pass --layers 0 to write a passthrough copy deliberately.")
    sliced_modules = sorted(module for module, parts in partitions.items()
                            if any(p.row_offset or p.source_rows != plan[p.tensor][2] for p in parts))
    if sliced_modules and args.stock_twin is not None:
        raise SystemExit(
            f"--stock-twin was given and {len(sliced_modules)} module(s) are merged Linears over "
            f"one source tensor ({sliced_modules[:4]}...): the twin writes one tensor per role "
            "and this exporter does not reassemble row slices. Export without a twin.")
    if geometry_unattested:
        print(f"  geometry unattested for {len(geometry_unattested)} module(s): the construction "
              "census predates output_sizes (tessera#377); roles declared per source tensor",
              flush=True)
    if sliced_modules:
        print(f"  {len(sliced_modules)} merged module(s) over one source tensor are declared as "
              "row-sliced roles per the attested output partitions", flush=True)

    cache_unit_names = {ActivationSource.unit_name(unit["tensor"])
                        for record in stack_plan.values() for unit in record["units"]}
    if args.cached_expert_units is not None and not cache_unit_names:
        raise SystemExit("--cached-expert-units requires a nonempty explicit expert stack plan")
    if args.cached_units is not None:
        padded = sorted(module for module, parts in partitions.items() if any(p.padding_rows for p in parts))
        if padded:
            raise SystemExit(f"--cached-units cannot adopt unpadded NoPE source wires: {padded}")
        if sliced_modules:
            raise SystemExit("--cached-units requires whole dense source tensors; "
                             f"row-sliced modules cannot reuse whole original wires: {sliced_modules}")
        cache_unit_names.update(ActivationSource.unit_name(part.tensor)
                                for parts in partitions.values() for part in parts)
    cache_path = args.cached_units or args.cached_expert_units
    cache_scope = "cached_units" if args.cached_units is not None else "cached_expert_units"
    if cache_path is not None and not cache_unit_names:
        raise SystemExit("cached export requires a nonempty planned unit roster")
    if cache_path is not None and args.out.exists():
        raise SystemExit("cached export requires a fresh output directory")
    partition_record = None
    source_digest_cache = None
    if args.source_digest_cache is not None:
        if not args.partition and cache_path is None:
            raise SystemExit("--source-digest-cache requires cached units or a partition source stamp")
        from tessera.source_digest_cache import SourceDigestCache
        try:
            source_digest_cache = SourceDigestCache(args.source_digest_cache, source=args.src)
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
    if args.partition:
        index, count = args.partition
        options = {key: value for key, value in vars(args).items()
                   if key not in {"src", "out", "partition", "partition_runtime_image",
                                  "device", "stock_twin", "plan_json", "hessian", "input_scales",
                                  "cached_expert_units", "cached_units", "priced_inputs", "priced_inputs_sha256",
                                  "research_selected_moe_json", "cached_producer_package",
                                  # How fast the intake ran and where H identity came
                                  # from change no accepted byte; they are receipt
                                  # fields (hessian_identity below), not identity.
                                  "cached_hessian_identity", "cached_intake_threads",
                                  "cached_intake_window_bytes",
                                  # Where shard digests may be reused from changes no
                                  # stamped digest; the receipt records how each was taken.
                                  "source_digest_cache",
                                  # A location, which differs per checkout; its
                                  # content digest is recorded below instead.
                                  "producer_authority"}}
        if research_execution is not None:
            options["research_selected_moe"] = research_execution.record()
        if priced_inputs is not None:
            options["priced_inputs_sha256"] = priced_inputs.sha256
        options["plan"] = plan_snapshot.published() if plan_snapshot is not None else None
        options["plan_sha256"] = plan_snapshot.sha256 if plan_snapshot is not None else None
        # The authority file's digest also binds the canonical capture it
        # defines: the file is self-contained and ``producer_authority.load``
        # executes those bytes, keyed by this same digest.  The input-scales
        # digest is the snapshot's instead: the same bytes the roles consume,
        # not a second read of a mutable path.
        for key in ("hessian", "producer_authority"):
            path = getattr(args, key)
            options[key + "_sha256"] = sha256_file(path) if path else None
        options["input_scales_sha256"] = input_scales_sha256
        if cache_path is not None:
            options[cache_scope + "_sha256"] = sha256_file(cache_path)
        # The manifest write at the end of the run serializes these; check
        # them now, before the source shards hash or one unit encodes.
        try:
            require_json(options, "export_partition.identity.options")
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
        owns = lambda name: partition_owner(name, count) == index
        selected = sorted(name for names in shards.values() for name in names if owns(name))
        if not selected:
            raise SystemExit(f"partition {index}/{count} owns no source tensors")
        # Stamp only the shards this part reads tensors from (tessera#495): the
        # merge proves each stamp against its one pass over the whole source.
        read_shards = sorted(shard for shard, names in shards.items() if any(map(owns, names)))
        from tessera.encoder_identity import encoder_fixture_id
        # Build the per-process encoder identity memo on a helper thread while
        # the shards hash (tessera#499). The call below takes the memo, or
        # waits on the build's lock; if the helper failed, the memo is empty
        # and that call rebuilds and raises the refusal itself.
        import threading
        threading.Thread(target=_warm_encoder_fixture_id, args=(encoder_fixture_id,),
                         name="encoder-fixture-id", daemon=True).start()
        # The identity hashes the CODE the exporter runs from -- the checkout
        # (its src/ and experiments/ trees, tessera#499) or the installed
        # holder (the package, #691 item 4). Living in src/tessera/, two
        # parents up is the checkout root only from a checkout; from an
        # installed wheel it is lib/python3.x, so the root is derived, not
        # counted.
        identity = export_identity(args.src, options, args.partition_runtime_image,
                                   exporter_code_root(), shards=read_shards,
                                   digest_cache=source_digest_cache)
        if producer_receipt is not None:
            # The receipt rides INSIDE the identity: the merge's exact
            # comparison then refuses joins across producers, and joins
            # across a part written before receipts existed.  No schema
            # bypass, no compatibility shim, no waiver.
            identity["producer"] = producer_receipt
        identity["encoder_fixture_id"] = encoder_fixture_id().hex()
        partition_record = {"schema": PART_SCHEMA, "index": index, "count": count,
                            "identity": identity, "source_tensors": selected}
        try:
            require_json(partition_record, "export_partition")
        except ValueError as exc:
            raise SystemExit(str(exc)) from exc
        shards = {shard: [name for name in names if owns(name)] for shard, names in shards.items()}
        shards = {shard: names for shard, names in shards.items() if names}
        # Planning and the construction gate above see the same complete plan
        # on every worker. Only execution is partitioned, at whole-layer ownership.
        plan = {name: value for name, value in plan.items() if owns(name)}
        modules = {name: members for name, members in modules.items() if owns(name)}
        stack_plan = {name: value for name, value in stack_plan.items() if owns(name)}
        shapes = {name: shape for name, shape in shapes.items() if owns(name)}
        expert_shapes = {name: shape for name, shape in expert_shapes.items() if owns(name)}
        routed_shapes = {name: shape for name, shape in routed_shapes.items() if owns(name)}
        passthrough = [name for name in passthrough if owns(name)]
        print(f"partition {index}/{count}: {len(selected)} source tensors, "
              f"{len(stack_plan)} routed stacks, {len(modules)} dense modules", flush=True)

    cached_units = None
    historical_producer = None
    cached_identity = None
    if cache_path is not None:
        from tessera.cached_unit import CachedUnitBundle, read_manifest
        from tessera.serving_parts import source_identity
        source = (partition_record["identity"]["source"] if partition_record is not None
                  else (source_identity(args.src, digest_cache=source_digest_cache)
                        if source_digest_cache is not None else source_identity(args.src)))
        cached_units = CachedUnitBundle(read_manifest(cache_path),
                                        cache_path.parent, cache_unit_names, source,
                                        encoder_source_proof_mode=args.cached_encoder_source_proof_mode,
                                        authority=producer_authority)
        if cached_units.producer_packages and args.cached_producer_package is not None:
            raise SystemExit("rooted cached units bind their exact producers; omit global cached-producer flags")
        if args.cached_producer_package is not None:
            from tessera.historical_producer import load_historical_producer
            historical_producer = load_historical_producer(
                args.cached_producer_package, args.cached_producer_source_sha256)
        # ONE deriver for every cached unit, dense or expert: the producer's
        # own identity factory, with the calibration H identity established
        # the way ``--cached-hessian-identity`` says and recorded below.
        cached_identity = CachedUnitIdentity(
            lambda weight, unit_name, unit, grid, q256, *, activation: cached_input_identity(
                historical_producer, weight, unit_name, unit, grid, q256, activation=activation),
            activation, mode=args.cached_hessian_identity)
        if cached_units.producer_packages:
            from tessera.cached_unit import ProducerCachedUnitIdentities
            from tessera.historical_producer import load_historical_producer
            # Hash and load each exact historical producer; never relabel a
            # receipt.  Loading a package by path lives here, with the
            # exporter's other dynamic load, and not in ``tessera.cached_unit``:
            # a src module that imports the path loader puts an unresolvable
            # read in ``tests/conftest.py``'s import closure, and
            # ``tools/impacted_tests.py`` then answers ``full`` for every edit
            # this tree can make.
            producers = {seal: load_historical_producer(Path(bound["path"]), bound["sha256"])
                         for seal, bound in cached_units.producer_packages.items()}
            cached_identity = ProducerCachedUnitIdentities(
                cached_units, producers, cached_input_identity,
                activation, mode=args.cached_hessian_identity)

    # ``input_scales`` was parsed from its one byte snapshot at the top of
    # main, before the identity sealed its digest; the checks below consume
    # those exact scalars.
    if cached_units is not None:
        cached_units.require_served_scales(input_scales)
    if priced_inputs is not None:
        priced_inputs.require(activation, input_scales)
    # Dense modules AND expert stacks: an NVFP4 stack needs one static A-side
    # scale per expert projection (``nvfp4_moe_route.INPUT_GLOBAL_SCALE_SUFFIX``),
    # written beside each wire below.
    needs_scales = ([m for m, members in modules.items() if family_for(plan[members[0]][0]) == NVFP4]
                    + [stack for stack, record in stack_plan.items() if record["family"] == NVFP4])
    if needs_scales and not input_scales:
        raise SystemExit(f"{len(needs_scales)} modules take the NVFP4 route (W4A4 needs a static input scale) "
                         "but no --input-scales was given")

    args.out.mkdir(parents=True, exist_ok=True)
    twin = args.stock_twin
    if twin is not None:
        twin.mkdir(parents=True, exist_ok=True)
    started = time.time()
    new_weight_map: dict[str, str] = {}
    twin_weight_map: dict[str, str] = {}
    config_groups: dict[str, dict] = {}
    units: dict[str, dict] = {}
    module_records: dict[str, dict] = {}
    module_replay_groups: dict[str, list[dict]] = {}
    if args.shared_candidate_pricing and args.partition:
        raise SystemExit("--shared-candidate-pricing requires a whole artifact, not a serving part")
    twin_modules: dict[str, list[str]] = {NVFP4: [], FP8: [], BF16: []}
    twin_records: dict[str, dict] = {}
    # No seed: every ignored module is named from the tensor that was passed
    # through (the loop below), under whatever layout the checkpoint has; a
    # hard-coded ``model.embed_tokens`` named a module a nested checkpoint does
    # not have and said nothing about the one it does (#139).
    ignore: list[str] = []
    passthrough_bytes = 0
    vocab_tensors: dict[str, tuple[int, int, int]] = {}
    weights_cache: dict[str, torch.Tensor] = {}
    done = 0
    total = sum(len(partitions[m]) for m in modules)      # roles, not tensors; this worker's share

    # THE EXPERT WORK LIST, keyed by the SOURCE tensor so the encode happens
    # where the tensor is read: one layer's experts span four shards on
    # GLM-5.3-Flash, and holding a stack's 864 source tensors until the last
    # one arrives is 13.8 GB of BF16 for no reason.  The wire tensor is written
    # into the same shard its source came from; the two GROUP strides are the
    # maxima over every blob and are therefore known only at the end, which is
    # exactly when ``config.json`` is written.
    expert_units: dict[str, list[dict]] = {}
    for stack, record in stack_plan.items():
        for unit in expert_work_units(stack, record):
            expert_units.setdefault(unit["source_tensor"], []).append(unit)
    # ``attested_by`` is the routed_moe cells that cover the stack's rung
    # (``contract.cell_covers_rung``: a census rung, or an allowable rung of
    # one of the cell's run tables) -- the gate above read them, and the record says which
    # (#135, principle 12).  Empty only under --allow-unserveable, where the
    # manifest's ``serving_gate`` block carries the refusal beside it.
    moe_records = {stack: {"family": record["family"], "grid": record["grid"].name,
                           "q256": record["q256"], "experts": record["experts"],
                           "attested_by": [
                               cell["id"] for cell in attested_cells(
                                   PAYLOAD_FAMILY_BY_ROUTE[record["family"]],
                                   STRUCTURE_ROUTED_MOE)
                               if cell_covers_rung(
                                   cell, int(record["q256"]),
                                   format_entry(PAYLOAD_FAMILY_BY_ROUTE[record["family"]]))],
                           "source_layout": record["source_layout"],
                           "hidden_size": record["hidden_size"],
                           "intermediate_size": record["intermediate_size"],
                           "roles": [], "container_bytes": 0, "wire_bytes": 0,
                           "resident_bytes_resident_mode": 0,
                           "group_blob_bytes": {g: [] for g in MOE_GROUPS},
                           # Each unit's verified wire layout (rates, window
                           # bits), kept for the per-rank fit block and popped
                           # before the record is written: it is not manifest
                           # content, and the rates alone would dwarf it.
                           "unit_layouts": [],
                           "rows": sum(g["rows"] for g in record["groups"].values()),
                           "cols": record["hidden_size"]}
                   for stack, record in stack_plan.items()}
    for stack, record in stack_plan.items():
        if "unit_q256" in record:
            moe_records[stack]["attested_by"] = []
    moe_total = sum(len(units) for units in expert_units.values())
    moe_done = 0

    # THE CACHED EXPERT INTAKE runs ahead of the shard loop on a pool (see
    # CachedExpertIntake); the loop below takes each unit back in its own
    # order.  Task order is the loop's: shards sorted, names in shard order,
    # units in plan order.
    intake = None
    if cached_units is not None and expert_units:
        from tessera.export import ExportedUnit

        def intake_unit(handle, shard, name, unit):
            stack_spec = stack_plan[unit["stack"]]
            unit_grid, unit_q256 = stack_spec["grid"], expert_unit_q256(stack_spec, unit)
            source_weight = packed_expert_weight(handle.get_tensor(name), unit)
            expected = cached_identity(source_weight, unit["tensor"], unit, unit_grid, unit_q256)
            cached_blob, cache_record = cached_units.read(expected["unit"])
            producer = (cached_identity.producer_for(expected["unit"])
                        if cached_units.producer_packages else historical_producer)
            if producer is not None:
                producer.verify(cached_blob, cache_record, expected)
            accepted, blob = pack_cached_expert_unit(cached_blob, cache_record, expected)
            exported = ExportedUnit(unit["tensor"], accepted.blob, unit["rows"], unit["cols"],
                                    unit_q256, accepted.wire_bytes)
            payload = torch.frombuffer(bytearray(blob), dtype=torch.uint8).clone()
            return (exported, blob, cache_record, payload,
                    float(accepted.manifest.scale_plane.global_scale), accepted.manifest)

        def intake_estimate(unit):
            record = cached_units.units[ActivationSource.unit_name(unit["tensor"])]
            return 3 * int(record["blob_bytes"]) + 2 * int(unit["rows"]) * int(unit["cols"])

        threads = (default_intake_threads() if args.cached_intake_threads is None
                   else args.cached_intake_threads)
        intake = CachedExpertIntake(
            args.src,
            [(shard, name, unit) for shard, names in sorted(shards.items())
             for name, unit in fresh_expert_units(names, plan, expert_units)],
            intake_unit, threads=threads, window_units=4 * threads,
            window_bytes=args.cached_intake_window_bytes, estimate=intake_estimate)
        print(f"cached expert intake: {len(intake.tasks)} units on {threads} thread(s), "
              f"window {intake.window_units} units / {intake.window_bytes >> 20} MiB, "
              f"Hessian identity {cached_identity.established}", flush=True)
        intake.prime()

    def encode_joined(members):
        """One join key's encodes through the lifted owner; main supplies the
        run's plan, activation, device and verify flag, and collects the
        effective widths the manifest records."""
        return fresh_joined_encode(
            members, stack_plan=stack_plan, activation=activation,
            device=args.device, no_verify=args.no_verify,
            batch_observed=encode_batch_observed)

    if args.encode_batch > 1:
        print(f"joined expert encode: {args.encode_batch} units per trellis call, "
              f"TESSERA_WINDOW_BEST_FORM={os.environ.get('TESSERA_WINDOW_BEST_FORM', '') or 'unset'}",
              flush=True)
    # THE EFFECTIVE WIDTHS, as evidence: the planner groups by join key
    # across source names within each shard, so the observed width of a call
    # is min(batch, that key's units in the shard).  The manifest records
    # what actually ran; a width-16 throughput claim cites these, never the
    # requested knob alone.
    encode_batch_observed: list[int] = []
    pending_modules = dict(modules)
    for shard, names in sorted(shards.items()):
        shard_payload: dict[str, torch.Tensor] = {}
        twin_payload: dict[str, torch.Tensor] = {}
        with safe_open(str(args.src / shard), framework="pt") as handle:
            joined = None
            if args.encode_batch > 1 and intake is None and cached_units is None:
                joined = JoinedExpertEncode(
                    handle, fresh_expert_units(names, plan, expert_units),
                    args.encode_batch, encode_joined)
            for name in names:
                # The intake reads its own source slices through its shared
                # handle; the loop does not stage a tensor it never touches.
                if intake is not None and name in expert_units:
                    tensor = None
                elif joined is not None:
                    tensor = joined.source(name)
                else:
                    tensor = handle.get_tensor(name)
                if name in plan:
                    weights_cache[name] = tensor
                elif name in expert_units:
                    for unit in expert_units[name]:
                        stack_spec = stack_plan[unit["stack"]]
                        unit_grid, unit_q256 = stack_spec["grid"], expert_unit_q256(stack_spec, unit)
                        unit_recipe = served_recipe(unit_grid, unit_q256,
                                                      STRUCTURE_ROUTED_MOE)
                        source_weight = None
                        if intake is not None:
                            (exported, blob, cache_record, payload, own_global,
                             unit_manifest) = intake.take(shard, name, unit)
                        elif joined is not None:
                            (exported, blob, payload, own_global,
                             unit_manifest) = joined.take(name, unit, tensor)
                        elif cached_units is None:
                            source_weight = packed_expert_weight(tensor, unit)
                            weight = source_weight.to(args.device, torch.float32).contiguous()
                            # Same call as the dense path: a missing Hessian key
                            # must refuse rather than fall through to RTN.
                            extra = ({} if activation is None else activation.for_unit(
                                unit["tensor"], weight.shape[1], args.device,
                                scale_plane=unit_recipe.scale_plane))
                            exported, unit_artifact_, _forests = encode_linear_planes(
                                weight, grid=unit_grid, q256=unit_q256,
                                body=unit_recipe.body, name=unit["tensor"], verify=not args.no_verify, **extra)
                            extra.clear()
                            # The manifest the runtime's compact lane reads
                            # (rates, window bits) comes off the bytes just
                            # written, not off the encoder: the resident
                            # pricing below is of the wire, as the lane is.
                            unit_manifest = parse_unit_artifact(exported.blob, device=args.device).manifest
                            blob = pack_fused([(unit["projection"], exported.rows, exported.blob)])
                            own_global = float(unit_artifact_.scale_global)
                            payload = torch.frombuffer(bytearray(blob), dtype=torch.uint8).clone()
                            del weight
                        # ONE container per expert PROJECTION -- the granularity of
                        # the runtime's shard ids and of
                        # ``scheme.expert_role_declarations``.  A packed physical
                        # tensor may supply several such logical projections.
                        shard_payload[unit["wire"]] = payload
                        stack_record = moe_records[unit["stack"]]
                        stack_record["group_blob_bytes"][unit["group"]].append(len(blob))
                        stack_record["container_bytes"] += len(blob)
                        stack_record["wire_bytes"] += exported.exact_bytes
                        expert_scale = {}
                        if stack_spec["family"] == NVFP4:
                            # THE A-SIDE SCALE, PER EXPERT PROJECTION (tessera#492).
                            # The plugin's NVFP4 expert route reads
                            # ``experts.{e}.{proj}.input_global_scale`` beside
                            # each wire -- the same capacity/amax quantity the
                            # dense route reads as ``trellis_input_global_scale``
                            # -- and refuses a stack missing any.  So the
                            # exporter refuses first, by key, at the unit.
                            scale_key = unit["wire"][: -len(".wire")] + ".input_global_scale"
                            if scale_key not in input_scales:
                                raise SystemExit(
                                    f"no {scale_key} in {args.input_scales}; W4A4 cannot serve "
                                    f"{unit['stack']} expert {unit['expert']} {unit['projection']} "
                                    "(one static input scale per expert projection)")
                            a_scale = float(input_scales[scale_key])
                            if not (math.isfinite(a_scale) and a_scale > 0.0):
                                raise SystemExit(f"{scale_key} = {a_scale!r} is not a finite positive scale")
                            shard_payload[scale_key] = torch.tensor([a_scale], dtype=torch.float32)
                            expert_scale = {"input_global_scale": a_scale}
                            # The stock NVFP4 tile: packed nibbles, group-16
                            # ue4m3 block scales, one fp32 global and one fp32
                            # input scale per expert projection.
                            stack_record["resident_bytes_resident_mode"] += (
                                exported.rows * exported.columns // 2
                                + exported.rows * exported.columns // 16 + 8)
                            stack_record["unit_layouts"].append({
                                "group": unit["group"], "projection": unit["projection"],
                                "rows": exported.rows, "cols": exported.columns})
                        else:
                            # THE COMPACT WINDOW LANE'S OWN TENSORS (tessera#624).
                            # ``serving.moe_route`` serves every FP8/BF16
                            # routed stack through ``compact_window_lane``,
                            # which never allocates a decoded tile: what a
                            # rank retains is the repacked planes, the
                            # per-expert tables and bookkeeping, priced from
                            # this unit's verified manifest by the same
                            # arithmetic as ``WindowUnitAxis._alloc``.  The
                            # per-part ``run_off`` and the fused lane's
                            # tables (#685, v45) are per stack, added once
                            # the stack's shape is known below.
                            from tessera.kernel_window_gemv import TILE_ROWS
                            layout = {
                                "group": unit["group"], "projection": unit["projection"],
                                "rows": int(unit_manifest.geometry.rows),
                                "cols": int(unit_manifest.geometry.columns),
                                "rates": tuple(int(r) for r in unit_manifest.rates),
                                "window_bits": int(unit_manifest.window_bits)}
                            if (layout["rows"], layout["cols"]) != (exported.rows, exported.columns):
                                raise SystemExit(
                                    f"{unit['tensor']}: the wire's manifest says "
                                    f"{layout['rows']}x{layout['cols']} for a unit exported as "
                                    f"{exported.rows}x{exported.columns}")
                            if "unit_q256" in stack_spec:
                                require_plannable_unit_layout(layout, unit_q256, unit["tensor"],
                                                             manifest=unit_manifest)
                            try:
                                stack_record["resident_bytes_resident_mode"] += (
                                    routed_window_unit_resident_bytes(
                                        stack_spec["family"], layout["rows"], layout["cols"],
                                        layout["rates"], window_bits=layout["window_bits"],
                                        tile_rows=TILE_ROWS))
                            except ValueError as exc:
                                raise SystemExit(
                                    f"{unit['tensor']}: cannot price the compact routed lane "
                                    f"from its wire ({exc}); a routed stack the compact lane "
                                    "cannot read has no resident-mode figure") from exc
                            stack_record["unit_layouts"].append(layout)
                        stack_record["roles"].append({
                            **expert_scale,
                            "tensor": unit["tensor"],
                            "source_tensor": unit["source_tensor"],
                            "source_layout": unit["source_layout"],
                            "source_slice": unit["source_slice"],
                            "role": unit["projection"], "expert": unit["expert"],
                            "group": unit["group"], "rows": exported.rows,
                            "cols": exported.columns, "grid": unit_grid.name,
                            "q256": unit_q256, "family": stack_spec["family"],
                            "wire_bytes": exported.exact_bytes,
                            "blob_bytes": len(blob), "wire_bpp": float(exported.bpp),
                            "own_global": own_global,
                            **({"cached_blob_sha256": cache_record["blob_sha256"]}
                               if cached_units is not None else {})})
                        del source_weight, payload
                        moe_done += 1
                        if moe_done % 50 == 0 or moe_done == moe_total:
                            print(f"  [moe {moe_done}/{moe_total}] {unit['tensor']}  "
                                  f"{time.time() - started:.0f}s", flush=True)
                else:
                    shard_payload[name] = tensor
                    twin_payload[name] = tensor
                    passthrough_bytes += tensor.numel() * tensor.element_size()
                    # The vocab-parallel tables an MTP draft duplicates per
                    # rank (tessera#645): the target's embedding and head,
                    # matched by suffix because the embedding's prefix is the
                    # architecture's (``model.`` or ``model.language_model.``).
                    if (name.endswith("embed_tokens.weight") or name == "lm_head.weight"
                            or name.endswith(".lm_head.weight")) and tensor.dim() == 2:
                        vocab_tensors[name] = (int(tensor.shape[0]), int(tensor.shape[1]),
                                               tensor.element_size())
                    # EVERY tensor written at source precision is named here,
                    # body or not.  ``ignore`` used to be assembled from three
                    # BODY_LAYER-gated sources, so a Linear outside the decoder
                    # body -- a vision tower, an MTP sidecar -- was passed
                    # through and never named, and the plugin refuses exactly
                    # that (#86).  Deriving the name from the tensor just
                    # written is what keeps the two facts one fact.
                    ignore.extend(ignored_modules(name, tensor.shape, architecture,
                                                  config=src_config, tensor_names=source_tensor_names))
        for module, members in list(pending_modules.items()):
            if not all(m in weights_cache for m in members):
                continue
            grid, _q0, _r, _c = plan[members[0]]
            family = family_for(grid)
            # The module-level facts, which the grouping key already proved every
            # member shares.  The RATE is read per member below.
            recipe = served_recipe(grid, plan[members[0]][1])
            rungs = [int(plan[m][1]) for m in members]
            roles = []
            role_records = []
            native_a4_roles = []
            stock_tensors: dict[str, dict] = {}
            # The distinct trellis-table sets the serving load pins for this
            # module (tessera#557): one memoised ``(forest, code)`` set per
            # trellis the module's roles prepare, keyed exactly as the load's
            # ``lru_cache`` keys them so the count below is the load's count.
            trellis_keys: set = set()
            for part in partitions[module]:
                member = part.tensor
                member_grid, q256, source_rows, _mc = plan[member]
                member_recipe = served_recipe(member_grid, q256)
                whole = part.row_offset == 0 and part.source_rows == source_rows
                unit_name = member if whole else f"{member}[{part.row_offset}:{part.row_offset + part.source_rows}]"
                weight = weights_cache[member][part.row_offset: part.row_offset + part.source_rows]
                if part.padding_rows:
                    weight = torch.nn.functional.pad(weight, (0, 0, 0, part.padding_rows))
                # A missing key renders RTN and raises nothing; ``for_unit``
                # refuses instead, and is the same call the library exporters make.
                # Keyed by the TENSOR: the input side is one width for every
                # row slice, so the slices share the source tensor's Hessian.
                cache_record = None
                if args.cached_units is None:
                    weight = weight.to(args.device, torch.float32).contiguous()
                    extra = ({} if activation is None else
                             activation.for_unit(member, weight.shape[1], args.device,
                                                 scale_plane=member_recipe.scale_plane))
                    exported, unit, forests = encode_linear_planes(
                        weight, grid=member_grid, q256=q256, name=unit_name,
                        body=member_recipe.body, verify=not args.no_verify, **extra)
                    extra.clear()
                    parsed = parse_unit_artifact(exported.blob, device=args.device)
                    stock_code = DEFAULT_CODE
                else:
                    from tessera.cached_unit import verify_cached_unit
                    from tessera.export import ExportedUnit
                    expected = cached_identity(weight, member, None, member_grid, q256)
                    cached_blob, cache_record = cached_units.read(expected["unit"])
                    producer = (cached_identity.producer_for(expected["unit"])
                                if cached_units.producer_packages else historical_producer)
                    if producer is not None:
                        producer.verify(cached_blob, cache_record, expected)
                    accepted = verify_cached_unit(cached_blob, cache_record, expected)
                    parsed = parse_unit_artifact(accepted.blob, device=args.device)
                    unit, forests, stock_code = parsed.unit, parsed.forests, parsed.code
                    exported = ExportedUnit(unit_name, accepted.blob, part.rows, weight.shape[1],
                                            q256, accepted.wire_bytes)
                role = part.role
                roles.append((role, exported.rows, exported.blob, unit, forests))
                if family == NVFP4:
                    native_a4_roles.append({"rows": exported.rows, "cols": exported.columns,
                                            "rates": unit.rates, "arity": parsed.grid.arity,
                                            "memory": parsed.code.memory, "half": unit.half,
                                            "lut_entries": int(unit.scale_lut.numel())})
                    # NVFP4 is the TCQ body, so the parsed unit carries the
                    # forests by rate and the convolutional code the load
                    # prepares select planes from; every rate's trellis it
                    # touches pins one table set (served span-2 units carry
                    # exactly one rate -- the load refuses more).
                    for rate in parsed.manifest.rates:
                        trellis_keys.add((parsed.forests[rate], parsed.code))
                stock_tensors[unit_name] = materialize_stock(unit, forests, stock_code)
                role_records.append({
                    "tensor": member, "role": role, "rows": exported.rows, "cols": exported.columns,
                    # Where in the source tensor this role's rows come from:
                    # the whole tensor for every role before tessera#377, a
                    # row window for a merged Linear over one source tensor.
                    "row_offset": part.row_offset, "source_rows": source_rows,
                    "padding_rows": part.padding_rows,
                    "grid": member_grid.name, "q256": q256, "family": family,
                    "wire_bytes": exported.exact_bytes, "blob_bytes": len(exported.blob),
                    "wire_bpp": float(exported.bpp), "own_global": float(unit.scale_global),
                    "resident_bytes_stock": stock_bytes(stock_tensors[unit_name]),
                    **({"cached_blob_sha256": cache_record["blob_sha256"]}
                       if cache_record is not None else {}),
                })
                done += 1
                if done % 20 == 0 or done == total:
                    print(f"  [{done}/{total}] {unit_name}  {time.time() - started:.0f}s", flush=True)
            for member in members:
                del weights_cache[member]
            blob = pack_fused([(r, rows, b) for r, rows, b, _u, _f in roles])
            rows_total = sum(r[1] for r in roles)
            cols = role_records[0]["cols"]
            # The module's rung is a scalar when its roles agree and the list of
            # theirs when they do not, the same spelling the scheme uses (#37).
            module_q256 = rungs[0] if len(set(rungs)) == 1 else list(rungs)
            record = {
                "family": family, "grid": grid.name, "q256": module_q256, "roles": role_records,
                "container_bytes": len(blob), "rows": rows_total, "cols": cols,
                "wire_bytes": sum(r["wire_bytes"] for r in role_records),
                # Whether the roles above are the runtime's attested output
                # partitions (tessera#377) or, on a census that predates the
                # field, the source tensors as declared before it.
                "geometry_attested": module not in geometry_unattested,
            }
            shard_payload[f"{module}.wire_bytes"] = torch.frombuffer(bytearray(blob), dtype=torch.uint8).clone()
            native_roles = None
            if family != NVFP4:
                from tessera.kernel_window_gemv import TILE_ROWS
                native_roles = [{"rows": role_rows, "cols": cols, "rates": unit.rates,
                                 "window_bits": unit.window_bits, "tile_rows": TILE_ROWS}
                                for _name, role_rows, _blob, unit, _forests in roles]
            if family == NVFP4:
                shared, _moved = shared_lut_global(
                    [u.scale_lut for _, _, _, u, _ in roles], [float(u.scale_global) for _, _, _, u, _ in roles],
                    [r for r, *_ in roles])
                # The A-side static scale is ONE value per fused module and it
                # is the MIN over members (``fused.shared_input_global_scale``,
                # the join's one home): the route hands the value unmodified to
                # vLLM's quantiser, which stores ``e4m3(block_amax/6 * scale)``
                # clamped at 448 -- capacity/amax, INVERSE in the activation
                # range -- so the min member scale is the largest calibrated
                # amax, the range the fused GEMM's one input tensor actually
                # spans.  The MAX this used to take (copied from vLLM's stock
                # scheme, where it only reduces an already-unified checkpoint)
                # picks the SMALLEST calibrated range and silently clips the
                # rest (RobTand/prismaquant#196).
                scale_keys = list(dict.fromkeys(f"{module_of(m)}.input_global_scale" for m in members))
                missing = [k for k in scale_keys if k not in input_scales]
                if missing:
                    raise SystemExit(f"no {missing} in {args.input_scales}; W4A4 cannot serve {module}")
                a_scale = shared_input_global_scale(
                    [input_scales[k] for k in scale_keys], scale_keys)
                shard_payload[f"{module}.trellis_input_global_scale"] = torch.tensor([a_scale], dtype=torch.float32)
                # The trellis tables are shared per process (see
                # ``decode.replay_table_bytes``): per-module pricing is exact
                # exactly when each trellis is prepared once in the serve.
                trellis_table_bytes = sum(replay_table_bytes(forest, code)
                                          for forest, code in trellis_keys)
                if args.shared_candidate_pricing:
                    from tessera.decode import replay_table_spec
                    module_replay_groups[module] = [replay_table_spec(forest, code)
                                                    for forest, code in trellis_keys]
                record.update({"shared_global": shared, "input_global_scale": a_scale,
                               "resident_bytes_resident_mode": dense_resident_bytes_resident_mode(
                                   family, rows_total, cols,
                                   trellis_table_bytes=trellis_table_bytes,
                                   native_roles=native_a4_roles)})
                if twin is not None:
                    moved, divisor = share_global({module_of(m): stock_tensors[m] for m in members})
                    for m in members:
                        for key, value in moved[module_of(m)].items():
                            twin_payload[f"{module_of(m)}.{key}"] = value.cpu()
                        # The joined value on EVERY member, not each member's
                        # own: vLLM reduces whatever the members carry into
                        # one scale per fused module (warning, not refusing,
                        # when they differ), and the twin exists to execute
                        # the same A side this export serves.
                        twin_payload[f"{module_of(m)}.input_global_scale"] = torch.tensor(
                            [a_scale], dtype=torch.float32)
                    record["twin_shared_divisor"] = divisor
            elif family == BF16:
                record["resident_bytes_resident_mode"] = dense_resident_bytes_resident_mode(
                    family, rows_total, cols, native_roles=native_roles)
                if twin is not None:
                    for m in members:
                        # One tensor, under the ORIGINAL name: the twin is an
                        # ordinary BF16 checkpoint, not a compressed one.
                        twin_payload[m] = stock_tensors[m]["weight"][:plan[m][2]].cpu().contiguous()
            else:
                record["resident_bytes_resident_mode"] = dense_resident_bytes_resident_mode(
                    family, rows_total, cols, native_roles=native_roles)
                if twin is not None:
                    for m in members:
                        for key, value in stock_tensors[m].items():
                            twin_payload[f"{module_of(m)}.{key}"] = value.cpu()
            if twin is not None:
                twin_modules[family].extend(module_of(m) for m in members)
                twin_records[module] = {"family": family, "members": [module_of(m) for m in members],
                                        "resident_bytes": sum(stock_bytes(stock_tensors[m]) for m in members)}
            if module in direct_consumer_costs:
                extra = direct_consumer_costs[module]
                record["direct_consumer_resident_bytes"] = extra
                record["resident_bytes_resident_mode"] += extra["resident_bytes_resident_mode"]
                record["resident_bytes_stock"] = (sum(r["resident_bytes_stock"] for r in role_records)
                                                 + extra["resident_bytes_stock"])
            scheme = {
                # ``structure`` names what kind of vLLM layer this is.  This
                # loop writes ``dense`` -- one blob per LinearBase.  The other
                # value the plugin serves, ``routed_moe``, is declared after
                # the shard loop, where the expert stacks' strides are known.
                "family": family, "structure": STRUCTURE_DENSE,
                "grid": grid.name, "body": recipe.body.name, "plane": recipe.scale_plane.name,
                # An int when every role took the same rung -- what every
                # checkpoint before #37 carries -- and one rung per role, in
                # ``roles`` order, when they did not.  ``validate_tessera_scheme``
                # reads both; a plugin older than contract v6 refuses the list.
                "q256": module_q256, "rows": rows_total, "columns": cols, "wire_bytes": len(blob),
                "roles": [[r, rows] for r, rows, *_ in roles],
            }
            config_groups[f"tessera_{module.replace('.', '_')}"] = {"format": "TESSERA", "targets": [module], "scheme": scheme}
            module_records[module] = record
            for r in role_records:
                source_count = r["rows"] - r.get("padding_rows", 0)
                whole = r["row_offset"] == 0 and source_count == r["source_rows"]
                key = r["tensor"] if whole else f"{r['tensor']}[{r['row_offset']}:{r['row_offset'] + source_count}]"
                units[key] = r
            del pending_modules[module]
        save_serving_shard(shard_payload, args.out / shard)
        for key in shard_payload:
            new_weight_map[key] = shard
        print(f"wrote {shard}: {len(shard_payload)} tensors", flush=True)
        if twin is not None:
            save_serving_shard(twin_payload, twin / shard)
            for key in twin_payload:
                twin_weight_map[key] = shard
            print(f"wrote twin {shard}: {len(twin_payload)} tensors", flush=True)
    if intake is not None:
        intake.close()
        if intake.taken != len(intake.tasks):
            raise SystemExit(f"cached intake took {intake.taken} of {len(intake.tasks)} planned expert units")
    if pending_modules:
        raise SystemExit(f"modules never completed: {sorted(pending_modules)}")

    # THE EXPERT STACKS' SCHEMES, written once every blob's length is known.
    # ``wire_stride`` is the MAXIMUM over the group's blobs and is derived here
    # rather than declared: the blob length follows the data (the manifest's
    # exact-ratio ``global_scale`` rides as a varint whose width follows its
    # value), so there is no number a caller could pass that the bytes would
    # not contradict -- and ``moe_layout.unpack_moe_wires`` refuses a stride
    # that is not what the loaded lengths imply, which is the same check from
    # the other side.
    routed_layouts: dict[str, list] = {}
    for stack, spec in stack_plan.items():
        stack_record = moe_records[stack]
        recipe = served_recipe(spec["grid"], spec["q256"], STRUCTURE_ROUTED_MOE)
        groups = {}
        for group in MOE_GROUPS:
            lengths = stack_record["group_blob_bytes"][group]
            want = spec["experts"] * len(MOE_GROUP_PROJECTIONS[group])
            if len(lengths) != want:
                raise SystemExit(
                    f"{stack} group {group}: {len(lengths)} container(s) written for {want} "
                    "(experts x projections). A group whose rows are not all there would be "
                    "served with zero rows for the rest.")
            groups[group] = {
                "q256": expert_group_q256(spec, group), "rows": spec["groups"][group]["rows"],
                "columns": spec["groups"][group]["columns"],
                "roles": spec["groups"][group]["roles"], "wire_stride": max(lengths)}
        scheme = {
            "family": spec["family"], "structure": STRUCTURE_ROUTED_MOE,
            "source_layout": spec["source_layout"],
            "grid": spec["grid"].name, "body": recipe.body.name,
            "plane": recipe.scale_plane.name, "experts": spec["experts"], "groups": groups,
        }
        # The reader is the gate, so the writer is held to it here rather than
        # at load: this is the exact function ``TesseraConfig`` calls, on the
        # exact dict about to be written.
        validate_tessera_moe_scheme(scheme, stack)
        config_groups[f"tessera_{stack.replace('.', '_')}"] = {
            "format": "TESSERA", "targets": [stack], "scheme": scheme}
        stack_record["structure"] = STRUCTURE_ROUTED_MOE
        stack_record["wire_stride"] = {g: groups[g]["wire_stride"] for g in MOE_GROUPS}
        stack_record.pop("group_blob_bytes")
        routed_layouts[stack] = stack_record.pop("unit_layouts")
        if spec["family"] != NVFP4:
            # The stack-level terms of the compact lane (tessera#624): one
            # ``run_off`` per part at ``finish`` and, where the whole stack's
            # wire shape admits the fused lane, its composed tables (#685),
            # run pairs and block descriptors (contract v45).
            stack_record["resident_bytes_resident_mode"] += routed_stack_resident_bytes(
                spec["family"], spec["experts"], routed_layouts[stack])[1]
        stack_record["roles"].sort(key=lambda r: (r["expert"], r["group"], r["role"]))
        module_records[stack] = stack_record
        for role in stack_record["roles"]:
            units[role["tensor"]] = role

    # The expert stacks and the routed leaves were named by the same rule as
    # they were written (``ignored_modules``), which is the point: one mechanism
    # decides what is passed through and what is declared BF16.  What is worth
    # asserting is that the two agree -- a plan-time passthrough the write loop
    # somehow did not name would be a load-time refusal, so it is a refusal
    # here instead.
    unnamed = sorted(n for n in passthrough
                     if not set(ignored_modules(n, shapes[n], architecture, config=src_config,
                                                tensor_names=source_tensor_names)) <= set(ignore))
    if unnamed:
        raise SystemExit(
            f"{len(unnamed)} tensor(s) were planned as passthrough but never named in ignore, "
            f"e.g. {unnamed[:3]}. The plugin refuses a Linear it is neither told to decode nor "
            "told to leave alone, so this checkpoint would fail at load.")
    ignore = sorted(set(ignore))
    # THE PLAN IS VALIDATED BEFORE PUBLICATION (#211), by the same gate the
    # whole-layer merge runs: every explicit quantized entry must be emitted
    # and declared at its planned grid and rung.  The refusals above make each
    # known demotion path explicit before the encode; this holds whatever is
    # actually about to be published to the plan, so no path -- present or
    # future -- can publish a config.json that does not implement it.  A
    # partitioned export carries the full plan but emits only its owned
    # layers; its validation belongs to merge_serving_parts, which already
    # runs this call on the assembled whole.
    if not args.partition:
        try:
            validate_explicit_plan(
                plan_snapshot.entries if plan_snapshot is not None else None,
                module_records, config_groups,
                source_tensors={name for names in shards.values() for name in names})
        except ValueError as exc:
            raise SystemExit(
                f"explicit plan verification failed before publication: {exc}. The emitted "
                "roles do not implement the plan this export was given; refusing to write "
                "config.json.") from exc
    moe_passthrough_modules = {m for source in (expert_shapes, routed_shapes)
                               for name, shape in source.items()
                               for m in ignored_modules(name, shape, architecture, config=src_config,
                                                        tensor_names=source_tensor_names)
                               if m not in stack_plan}
    config = src_config
    source_quantization_config = config.get("quantization_config")
    config["quantization_config"] = {
        # The field that selects Tessera's own vLLM plugin (entry point
        # ``tessera = tessera.serving:register``).  No serve flag enables it.
        # ``format`` is NOT derived here, unlike the stock twin below.  vLLM's
        # FP4-model predicate (``ModelConfig.is_nvfp4_quantized``) requires
        # ``quantization == "compressed-tensors"``, which this is not, and
        # ``tessera.serving.config`` reads ``config_groups`` and never this
        # field.  Naming a format here would change nothing and assert
        # something; the label stays generic and the record below says what the
        # predicate resolves to and why (#92).
        "quant_method": "tessera", "format": MIXED_PRECISION,
        # What these bytes admit at load, not what degree they were built for
        # -- this exporter never learns one.  ``schema_minor`` is the wire
        # these units are written at and ``tp_agnostic`` is derived from it by
        # ``tessera.layout.tp_agnostic_at_minor``, the one home of the rule;
        # ``tessera.serving.config.TesseraConfig._require_a_cutter`` reads them
        # back and refuses a world size above one against an artifact that
        # declares neither (tessera#328).  What the packaged
        # ``runtime_contract.json`` publishes about tensor parallelism is a
        # separate question with a separate answer (tessera#330: nothing about
        # the replication rule, deliberately); this is the artifact's own
        # statement about its own bytes.
        "schema_minor": SCHEMA_MINOR,
        "tp_agnostic": tp_agnostic_at_minor(SCHEMA_MINOR),
        "config_groups": config_groups, "ignore": ignore,
        **({"research_selected_moe": research_execution.config.as_checkpoint()}
           if research_execution is not None else {}),
    }
    if not args.partition and not config_groups:
        if source_quantization_config is None:
            config.pop("quantization_config", None)
        else:
            config["quantization_config"] = source_quantization_config
    tessera_fp4_predicate = vllm_fp4_predicate("tessera", MIXED_PRECISION)
    config_name = "tessera_part_config.json" if args.partition else "config.json"
    (args.out / config_name).write_text(json.dumps(config, indent=2))
    if len(shards) > 1 or args.partition:
        size = sum((args.out / s).stat().st_size for s in shards)
        (args.out / "model.safetensors.index.json").write_text(
            json.dumps({"metadata": {"total_size": size}, "weight_map": new_weight_map}, indent=2))
    aux_patterns = () if args.partition else ("*.json", "*.txt", "*.jinja", "*.model")
    for pattern in aux_patterns:
        for aux in args.src.glob(pattern):
            if aux.name in ("config.json", "model.safetensors.index.json"):
                continue
            shutil.copy2(aux, args.out / aux.name)
            if twin is not None:
                shutil.copy2(aux, twin / aux.name)

    totals = summarize_modules(module_records, passthrough_bytes,
                               sum((args.out / s).stat().st_size for s in shards))
    # THE PER-RANK FIT BLOCK (tessera#624, #645): what one rank retains of
    # the routed stacks at ``--fit-tp-size`` -- each unit's rank-local cut,
    # so the per-expert tables and bookkeeping a cut does not shrink are
    # counted per rank, not divided -- beside the MTP draft's own embed/head
    # copy as its own named line.  ``resident_bytes_resident_mode`` above
    # stays the whole-stack TP1 figure the manifest has always carried.
    fit_tp = int(args.fit_tp_size)
    if fit_tp < 1:
        raise SystemExit(f"--fit-tp-size {fit_tp} is not a tensor-parallel size")
    routed_by_rank = [
        sum(sum(routed_stack_resident_bytes(
            stack_plan[stack]["family"], stack_plan[stack]["experts"], layouts,
            tp_size=fit_tp, tp_rank=rank)) for stack, layouts in routed_layouts.items())
        for rank in range(fit_tp)]
    mtp_layers = int(src_config.get("text_config", src_config).get("num_nextn_predict_layers") or 0)
    totals["per_rank"] = per_rank_fit_items(
        tp_size=fit_tp, routed_bytes_by_rank=routed_by_rank,
        mtp_duplicate_bytes=(mtp_draft_embed_head_duplicate_bytes(vocab_tensors.values(), fit_tp)
                             if mtp_layers > 0 else 0),
        mtp_layers=mtp_layers)
    params = totals["quantized_params"]
    families = sorted({m["family"] for m in module_records.values()})
    manifest = {
        "source": str(args.src), "git": tessera_commit, "written": time.strftime("%Y-%m-%dT%H:%M:%S"),
        **({"research_selected_moe": research_execution.record()}
           if research_execution is not None else {}),
        **({cache_scope: {"manifest_sha256": cached_units.manifest_sha256,
                                    "manifest_encoding": "canonical_json.sorted_compact.v1",
                                    "planned_units": len(cache_unit_names),
                                    "encoder_source_proof_mode": cached_units.encoder_source_proof_mode,
                                    "warnings": cached_units.warnings,
                                    **({"historical_producer": {
                                        "package": str(args.cached_producer_package.resolve()),
                                        "source_sha256": historical_producer.source_sha256,
                                        "namespace": historical_producer.namespace}}
                                       if historical_producer is not None else {}),
                                    # How each unit's calibration H identity was
                                    # established -- from the reference document's
                                    # sealed commitment or by reading and digesting
                                    # H -- and how the intake ran.  Neither changes
                                    # an accepted byte; both are stated, never implied.
                                    "hessian_identity": cached_identity.record(),
                                    **({"source_digest_receipt": source_digest_cache.receipt()}
                                       if source_digest_cache is not None else {}),
                                    **({"producer_packages": cached_units.producer_packages,
                                        **({"cohorts": cached_units.child_manifests}
                                           if cached_units.child_manifests else {}),
                                        **({"reuse_authority": cached_units.reuse_authority,
                                            "served_activation_policy": cached_units.served_activation_policy}
                                           if not cached_units.child_manifests else {}),
                                        "served_activations": cached_units.served_activations}
                                       if cached_units.producer_packages else {}),
                                    "intake": None if intake is None else intake.record()}}
           if cached_units is not None else {}),
        "arm": f"tessera {default_grid.name} q256={args.q256}" + (f" + plan {args.plan_json}" if args.plan_json else "")
               + f" -> tessera.serving {'+'.join(families)}",
        "default": {"grid": default_grid.name, "q256": args.q256}, "plan_json": str(args.plan_json) if args.plan_json else None,
        # What the plan DECLARED, not what it was validated against (#691
        # item 5): the reserved schema key is optional, so an older plan
        # records nothing here and the manifest stays honest about that.
        "plan_schema": plan_snapshot.schema if plan_snapshot is not None else None,
        # The plan CONTENT, not only its pathname: the merged path seals
        # options.plan into export_identity, and a direct export used to
        # record a path that may not outlive the run, so a later sidecar
        # check without --plan-json could not recover the obligation (#211).
        # It is the SNAPSHOT that drove the encode, not whatever the path
        # holds now -- the file is not reread here (#301).
        "plan": plan_snapshot.published() if plan_snapshot is not None else None,
        "plan_sha256": plan_snapshot.sha256 if plan_snapshot is not None else None,
        "input_scales_from": str(args.input_scales) if args.input_scales else None,
        "activation_aware": None if activation is None else activation.config_block(),
        # What the SERVING gate decided, in the artifact rather than in a shell
        # history: which contract version bounded it, whether the run carried
        # the override, and the verbatim refusal for every wire written anyway.
        # A production cell is not implied by empty `unserveable_overrides`:
        # research-selected routed targets are recorded separately as
        # decoder-only, with device qualification still absent.
        "serving_gate": {
            "contract": "tessera/serving/runtime_contract.json",
            "contract_version": load_serving_contract()["contract_version"],
            "allow_unserveable": bool(args.allow_unserveable),
            "unserveable_overrides": gate_overrides,
            "research_selected_decoder_only": research_gate_records,
            # What the pinned runtime does with each planned module, from the
            # contract's construction block -- and which way this run resolved
            # a module it will not route.  ``unrouted`` non-empty together with
            # ``allow_unrouted`` true is an artifact whose declared wires the
            # runtime never executes.
            "construction_census": None if census is None else {
                "architecture": census["architecture"], "runtime": census["runtime"],
                "model": census["model"], "receipt": census.get("receipt")},
            "allow_unrouted": bool(args.allow_unrouted),
            "passthrough_unrouted": bool(args.passthrough_unrouted),
            "unrouted": unrouted_records,
            # The runtime's output partitions per dense module, from the same
            # census (tessera#377): which modules were declared against an
            # attested partition list, and which of those are one source
            # tensor cut into several roles.  A module in ``unattested`` has
            # its roles declared per source tensor, unchecked.
            "geometry": {
                "attested_modules": len(partitions) - len(geometry_unattested),
                "unattested_modules": sorted(geometry_unattested),
                "row_sliced_modules": sliced_modules,
            },
        },
        # WHAT THE ROUTED-MoE LAYERS GOT, as a value rather than stdout.
        # Unplanned stacks stay at source precision; planned stacks carry wires.
        # ``modules`` is exactly the set of ``ignore``
        # entries this block accounts for -- read off ``ignored_modules``, the
        # same rule that put them there, so this cannot drift from the list it
        # claims to summarise (#86).  Both counts are zero on a dense model,
        # which is the same statement in the other direction.
        "routed_moe": {
            # ``disposition``, NOT ``structure``.  ``structure`` is the scheme's
            # gate-read field, whose only legal values are ``scheme.STRUCTURES``
            # and whose reserved name for this case is the block's own key,
            # ``routed_moe``.  A producer-written free string under that field
            # name is the confusion principle 14 exists to prevent, even though
            # nothing in ``tessera.serving`` reads this file.  It is now a
            # THREE-valued fact, because a stack can be encoded: ``quantized``
            # when every routed stack got a wire, ``passed_through_bf16`` when
            # none did, ``mixed`` when the plan named some of them.
            "disposition": ("quantized" if stack_plan and not moe_passthrough_modules
                            else "mixed" if stack_plan else "passed_through_bf16"),
            "reason": ("stacks named in the plan carry routed_moe wires; the rest stay at "
                       "source precision and are named in ignore"),
            "packed_source_tensors": len(expert_shapes),
            "unpacked_source_tensors": len(routed_shapes),
            "quantized_stacks": sorted(stack_plan),
            "quantized_source_tensors": len(expert_units),
            "quantized_logical_units": sum(
                len(record["units"]) for record in stack_plan.values()),
            # The ignore entries this block accounts for -- read off
            # ``ignored_modules``, the same rule that put them there, so it
            # cannot drift from the list it summarises (#86).  A stack that was
            # ENCODED is not here: it is in ``config_groups``, and the plugin
            # refuses a target that is both declared and ignored.
            "modules": sorted(moe_passthrough_modules),
        },
        # WHICH LANE THIS ARTIFACT WAS BUILT TO EXERCISE, in the bytes.  The
        # census reads it and REFUSES a phase where the lane took zero modules,
        # so "this checkpoint is for the window GEMV" is a claim the artifact
        # carries and a gate can check rather than a sentence in a handover
        # (issue #104).  Empty means no lane was requested, which is the honest
        # state of every checkpoint written before this flag existed.
        "requires_lanes": required_lanes,
        "stock_twin": str(twin) if twin is not None else None,
        "vllm_fp4_predicate": tessera_fp4_predicate,
        "totals": totals, "modules": module_records,
    }
    if args.shared_candidate_pricing:
        from tessera.serving_parts import shared_candidate_pricing
        manifest["shared_candidate_resident_pricing"] = shared_candidate_pricing(
            module_records, module_replay_groups)
    if partition_record is not None:
        partition_record["output_sha256"] = {
            shard: sha256_file(args.out / shard) for shard in sorted(shards)}
        if cached_units is not None:
            # Beside ``identity``, not inside it: the merge compares identity,
            # and parts whose H identity was established two ways carry the
            # same accepted bytes.  The merged checkpoint keeps every part's
            # statement of how.
            partition_record["hessian_identity"] = cached_identity.record()
        if source_digest_cache is not None:
            # Beside ``identity`` for the same reason: which source digests were
            # reused from a recorded read changes no stamped digest.
            partition_record["source_digest_receipt"] = source_digest_cache.receipt()
        manifest["export_partition"] = partition_record
    if producer_receipt is not None:
        # Beside the partition stamp: a whole artifact written by a selected
        # producer states the same receipt its parts seal.
        manifest["producer"] = producer_receipt
    # The verified execution knob and its effective value, recorded whether
    # or not a producer was selected; the part identity's options carry it
    # too, so parts batched differently refuse to merge.  With a batch above
    # one, the OBSERVED widths are the evidence: a throughput claim cites
    # these, never the requested knob alone.
    manifest["encode_batch"] = args.encode_batch
    if args.encode_batch > 1:
        widths: dict = {}
        for width in encode_batch_observed:
            widths[width] = widths.get(width, 0) + 1
        manifest["encode_batch_observed"] = dict(sorted(widths.items()))
    write_serving_manifest(args.out / "tessera_serving_manifest.json", manifest)

    if twin is not None:
        twin_groups = {}
        if twin_modules[NVFP4]:
            twin_groups[f"group_{len(twin_groups)}"] = {
                "format": NVFP4_PACK_QUANTIZED, "weights": dict(NVFP4_WEIGHTS),
                "input_activations": dict(NVFP4_INPUTS), "targets": stock_targets(twin_modules[NVFP4])}
        if twin_modules[FP8]:
            twin_groups[f"group_{len(twin_groups)}"] = {
                "format": FLOAT_QUANTIZED, "weights": dict(FP8_WEIGHTS),
                "input_activations": dict(FP8_INPUTS), "targets": stock_targets(twin_modules[FP8])}
        twin_config = json.loads((args.src / "config.json").read_text())
        # A BF16 module is in no group: its twin tensor is the ordinary
        # ``<module>.weight``, so it is ignored by the quantization config
        # exactly as ``lm_head`` is.  And when every module decoded to a plain
        # bf16 tile there are no groups at all -- this IS a BF16 checkpoint, and
        # the helper returns nothing to declare rather than an empty config that
        # would tell a runtime to look for compressed tensors that do not exist.
        #
        # This is the comparator arm, so it is the artifact #92 was about: it
        # goes through the same derivation as ``export_stock_compressed``, and
        # the predicate it resolves to is recorded on the twin's own manifest.
        twin_quant_config, twin_fp4_predicate = stock_quantization_config(
            twin_groups, sorted(set(ignore) | set(twin_modules[BF16])))
        if twin_quant_config is not None:
            twin_config["quantization_config"] = twin_quant_config
        else:
            twin_config.pop("quantization_config", None)
        (twin / "config.json").write_text(json.dumps(twin_config, indent=2))
        if len(shards) > 1:
            size = sum((twin / s).stat().st_size for s in shards)
            (twin / "model.safetensors.index.json").write_text(
                json.dumps({"metadata": {"total_size": size}, "weight_map": twin_weight_map}, indent=2))
        twin_resident = sum(r["resident_bytes"] for r in twin_records.values())
        write_serving_manifest(twin / "tessera_stock_twin_manifest.json", {
            "source": str(args.src), "git": tessera_commit, "written": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "wire_checkpoint": str(args.out), "arm": manifest["arm"] + " (stock twin of the same wires)",
            "vllm_fp4_predicate": twin_fp4_predicate,
            # THE TWIN IS THE ARTIFACT THAT GETS SERVED, so it carries what
            # shaped its bytes rather than a path to something that does.  The
            # wire manifest has these three; the twin used to have only a
            # ``wire_checkpoint`` string pointing at it, which is provenance
            # only for as long as that directory outlives this one on this box
            # -- and a served KL is read off the twin, quoted long afterwards,
            # and compared against another twin.  Two arms of an A/B whose one
            # difference is an ``activation_aware`` field could not be told
            # apart from the artifacts that produced the numbers: ``arm``
            # reads "tessera E2M1x2 q256=896 -> ..." for both (tessera#60).
            # Nothing here changes a byte of the checkpoint.
            "default": manifest["default"],
            "input_scales_from": manifest["input_scales_from"],
            "activation_aware": manifest["activation_aware"],
            "totals": {"quantized_params": params, "modules": len(twin_records),
                       "resident_bytes": twin_resident,
                       "resident_bpp": float(Fraction(twin_resident * 8, params)) if params else None,
                       "checkpoint_bytes": sum((twin / s).stat().st_size for s in shards)},
            "modules": twin_records,
        })
    print(json.dumps(totals, indent=2))
    print(f"elapsed {time.time() - started:.0f}s -> {args.out}" + (f" (twin -> {twin})" if twin is not None else ""))


if __name__ == "__main__":
    main()
