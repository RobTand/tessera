"""The FP8 route's fused decoder: the 4-bpp window wire, read at wire width.

WHAT THIS IS FOR.  Tessera's E4M3 route (grid ``E4M3``, WINDOW body at
``window_bits`` 14, span 1, over the CHANNEL scale plane -- ``export.
E4M3_RECIPE``) stores ~4.07 bpp on disk and serves as a stock per-channel FP8
tensor.  Serving it *resident* decodes once at load and holds 8 bpp, which is
plain FP8's footprint: the wire's saving lands on disk and nowhere else.
Serving it *streamed* holds the packed wire and decodes per forward, and the
only decoder that existed for that was pure torch (``tessera.serving.
window.PreparedWindow.decode``): correct, traceable, and 20-40x off
the memory-bandwidth bound, so the streamed mode paid more in decode than it
saved in bytes.

This module is the fused lane for that wire.  Two entry points:

- ``decode_fp8_tile`` -- the whole tile, bit-identical to ``decode.
  materialize_fp8``, for the prefill/GEMM path.  The stock ``torch.
  _scaled_mm`` mainloop consumes it unchanged.
- ``window_gemv`` -- decode-phase ``x @ W.T`` at small M that never
  materialises the tile, so the per-token weight traffic is the wire's ~4 bpp
  instead of the resident tile's 8.

WHY IT IS KERNELABLE.  ``state_t = ((state_{t-1} << R) | bits_t) mod 2^L``
from ``state_{-1} = 0`` is a shift register, so a state is *literally* the
last ``L`` bits of its column's stream and every position decodes from a
local read: with ``pack_window_planes``' ``L``-bit pad, position ``t`` of
column ``c`` reads the ``L`` bits at ``offsets[c] + (t + 1) * R``.  No walk
down the column, no halo, no replay tables -- the same property
``kernel.py`` had to prove about ``ConvCode.step`` for the trellis lane, here
by construction.  Columns are independent; the trellis axis is the *output*
row axis, so a GEMV's reduction axis (the input columns) is the axis that
does not carry state.

WHAT IS SHARED WITH THE REST OF THE TREE.  The packing is the wire's own
(``lane_planes.pack_window_planes``, the same bytes ``tessera.serving.
window.prepare_window`` reads), the code table is the unit's own
ALPHABET plane, the byte map is the grid's ``native`` and the row scale is
``scale_channel.channel_scale_field``'s expression.  Nothing here re-derives
a table the reference decoder builds, so the two cannot drift.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl

from .kernel_bits import _plane_words, _span_of
from .alphabet import require_hardware_byte_grid
from .errors import GrammarError
from .lane_planes import pack_window_planes
from .manifest import BodyKind, RotationState, ScalePlaneKind

__all__ = [
    "GEMV_MAX_M",
    "WINDOW_SPAN_BITS",
    "PreparedWindowUnit",
    "prepare_window_unit",
    "prepare_from_parsed",
    "decode_fp8_tile",
    "decode_selected_windows",
    "decode_value_tile",
    "window_gemv",
    "window_value_linear",
    "prepare_window_values",
    "window_linear",
    "window_module_decode",
    "window_module_row_scale",
    "window_module_linear",
    "window_code_table",
    "window_value_table",
]

#: The largest M ``window_gemv`` takes.  This is a **register-pressure cap, not
#: a measured crossover**: the accumulator is ``[MBLK, LANES, VEC]`` fp32 in
#: registers, so M grows the block linearly -- 209 registers a thread and 14%
#: occupancy already at M=8 -- and past it the kernel spills rather than runs.
#: The M at which decode-then-GEMM actually wins has *not* been derived; the two
#: instruments that measured M=8 disagree.  See the receipt,
#: ``docs/measurements/tessera-window-kernel-2026-09-02.md`` section 4d.
GEMV_MAX_M = 8

#: Bits a lane reads in one span.  A lane covers ``VEC`` consecutive codes,
#: whose windows together occupy ``window_bits + (VEC - 1) * R + 7`` bits
#: counting the sub-byte offset of the first, and one int64 holds 64.
WINDOW_SPAN_BITS = 64


# --- tables -----------------------------------------------------------------


def window_code_table(window_codes: torch.Tensor, grid, device=None) -> torch.Tensor:
    """``state -> E4M3 byte``: the unit's ``2^L`` ALPHABET plane through the
    grid's ``native`` byte map, ``uint8 [2^L]``.

    The composition is what ``decode.materialize_fp8`` does in two steps
    (``decode_codes_mixed`` then ``native[codes]``); doing it once at
    preparation means the kernel's inner loop is one gather, and the two
    former-NaN slots and the negative zero land on the legal byte the
    reference decoder writes because it is the same map.
    """
    require_hardware_byte_grid(grid, purpose="the FP8 route")
    codes = window_codes.reshape(-1).to(torch.long)
    native = torch.tensor(grid.native, dtype=torch.long, device=codes.device)
    if codes.numel() and int(codes.max()) >= native.numel():
        raise GrammarError(
            f"the window table names code {int(codes.max())} outside the "
            f"{native.numel()}-code {grid.name} grid"
        )
    table = native[codes].to(torch.uint8).contiguous()
    return table if device is None else table.to(device)


def window_value_table(code_table: torch.Tensor, device=None) -> torch.Tensor:
    """``state -> the E4M3 byte's value``, ``float16 [2^L]``.

    fp16, and exactly: every finite E4M3 value is ``2**(e-7) * (1 + m/8)`` for
    ``e in 1..15`` or ``m * 2**-9``, i.e. three mantissa bits over
    ``2**-9 .. 448``, all inside fp16's normals.  The test asserts the
    round-trip on all 254 legal bytes rather than arguing it.  Half the bytes
    of an fp32 table halves the gather's footprint, and the gather is what
    this kernel spends its time on: 32 KB of table stays hot where 64 KB
    starts to evict.

    Derived from the *decoded byte*, never from ``grid.values`` directly, so
    the GEMV reconstructs exactly what a GEMM over ``decode_fp8_tile``'s tile
    would see.
    """
    byte = code_table.reshape(-1).to(torch.uint8)
    value = byte.view(torch.float8_e4m3fn).to(torch.float16).contiguous()
    return value if device is None else value.to(device)


# --- the prepared unit ------------------------------------------------------


class PreparedWindowUnit:
    """One E4M3 window unit, packed on a device, decoded by the kernels here.

    Holds the wire (``plane_words``, ``offsets``, ``rates``), the two derived
    tables and the per-row scale.  Everything is a contiguous device tensor
    fixed at preparation, which is what lets the ops below be traced at
    static shape inside a compiled forward.
    """

    __slots__ = (
        "plane_words", "wire_bytes", "offsets", "rates", "initial", "code_table",
        "value_table", "row_scale", "rows", "cols", "window_bits", "max_rate", "device",
    )

    def __init__(self, plane_words, wire_bytes, offsets, rates, initial, code_table,
                 value_table, row_scale, rows, cols, window_bits, max_rate):
        # ``code_table is None`` is the BF16 family: the table holds values,
        # not E4M3 codes, so there is no byte tile and no separate scale to
        # ship -- ``decode`` returns the tile the GEMM multiplies.
        self.plane_words = plane_words
        self.wire_bytes = int(wire_bytes)
        self.offsets = offsets
        self.rates = rates
        self.initial = initial
        self.code_table = code_table
        self.value_table = value_table
        self.row_scale = row_scale
        self.rows = int(rows)
        self.cols = int(cols)
        self.window_bits = int(window_bits)
        self.max_rate = int(max_rate)
        self.device = plane_words.device

    @property
    def steps(self) -> int:
        """Codes per column.  At arity 1 that is the unit's output rows -- the
        name the torch reader's prepared object uses, kept so a lane can swap
        one for the other without touching the caller."""
        return self.rows

    def resident_bytes(self) -> int:
        """Alias of ``wire_bytes_resident`` under the torch reader's name."""
        return self.wire_bytes_resident()

    def wire_bytes_resident(self) -> int:
        """Device bytes held: the packed stream plus the tables and the scale.

        The two tables are ``2^L`` entries deterministic in the recipe
        (``encode.window_table``), i.e. one pair for a whole checkpoint --
        every unit of the reach checkpoint carries byte-identical
        ``window_codes`` -- so a lane that shares them across modules pays
        them once, not per unit.  This counts them per unit, which is the
        pessimistic reading.
        """
        return sum(
            t.numel() * t.element_size()
            for t in (self.plane_words, self.offsets, self.rates, self.initial,
                      self.code_table, self.value_table, self.row_scale)
            if t is not None
        )

    @property
    def family(self) -> str:
        """``"fp8"`` (E4M3 code table, scale beside the tile) or ``"value"``
        (float table, scale folded into the tile)."""
        return "fp8" if self.code_table is not None else "value"

    def decode(self) -> torch.Tensor:
        """The unit's tile -- a fresh tensor, every call.

        ``uint8 [rows, cols]`` of E4M3 bytes for the FP8 family, whose row
        scale is ``row_scale`` beside it; ``[rows, cols]`` in the value
        table's dtype with the scale already applied for the BF16 family.
        """
        if self.code_table is None:
            return decode_value_tile(
                self.plane_words, self.offsets, self.rates, self.initial,
                self.value_table, self.row_scale, self.rows, self.cols,
                self.window_bits, self.max_rate,
            )
        return decode_fp8_tile(
            self.plane_words, self.offsets, self.rates, self.initial, self.code_table,
            self.rows, self.cols, self.window_bits, self.max_rate,
        )

    def gemv(self, x: torch.Tensor) -> torch.Tensor:
        """``x @ W.T`` for ``x [M, cols]``, ``[M, rows]`` fp32.

        One kernel for both families: the value table's dtype is whatever the
        family packed (fp16 E4M3 values, or the BF16 family's bf16 values) and
        the gather widens to fp32 either way, so the accumulation is the same
        arithmetic over a different alphabet.
        """
        return window_gemv(
            x, self.plane_words, self.offsets, self.rates, self.initial,
            self.value_table, self.row_scale, self.rows, self.cols, self.window_bits,
            self.max_rate,
        )

    def linear(self, x: torch.Tensor, gemv_max: int = None) -> torch.Tensor:
        """``x @ W.T`` at any M, routed by family and batch."""
        cap = GEMV_MAX_M if gemv_max is None else int(gemv_max)
        if self.code_table is None:
            return window_value_linear(
                x, self.plane_words, self.offsets, self.rates, self.initial,
                self.value_table, self.row_scale, self.rows, self.cols,
                self.window_bits, self.max_rate, cap,
            )
        return window_linear(
            x, self.plane_words, self.offsets, self.rates, self.initial,
            self.code_table, self.value_table, self.row_scale, self.rows, self.cols,
            self.window_bits, self.max_rate, cap,
        )


def _initial_windows(initial, cols: int, window_bits: int, device) -> torch.Tensor:
    """The per-column start state: zeros for a whole unit, the parent's last
    ``window_bits`` bits for a tensor-parallel shard."""
    if initial is None:
        return torch.zeros(cols, dtype=torch.int64, device=device)
    start = initial.to(device, torch.int64).reshape(-1)
    if start.numel() != cols:
        raise GrammarError(f"{start.numel()} initial windows for {cols} columns")
    if start.numel() and (int(start.min()) < 0 or int(start.max()) >= 1 << window_bits):
        raise GrammarError(
            f"an initial window is {window_bits} bits; the plane names "
            f"{int(start.max())}"
        )
    return start


def prepare_window_unit(
    body_bits: torch.Tensor,
    rates,
    window_bits: int,
    window_codes: torch.Tensor,
    grid,
    row_scale: torch.Tensor,
    initial: "torch.Tensor | None" = None,
    device=None,
) -> PreparedWindowUnit:
    """Pack one window unit's wire and build its tables.

    ``body_bits`` is the reader's ``[rows, cols]`` uint8 (the R-bit value per
    position), ``rates`` the per-column schedule, ``window_codes`` the unit's
    ALPHABET plane and ``row_scale`` the CHANNEL plane's fp32 ``[rows]``
    (``scale_rows * scale_global``).  The packing is ``pack_window_planes``:
    the same bytes the torch reader reads, so a disagreement between the two
    decoders is a decoder bug and never a layout difference.
    """
    device = torch.device("cuda" if device is None else device)
    body_bits = body_bits.to(device)
    rows, cols = body_bits.shape
    rates = tuple(int(r) for r in rates)
    if len(rates) != cols:
        raise GrammarError(f"{len(rates)} rates for {cols} columns")
    window_bits = int(window_bits)
    max_rate = max(rates)
    _check_reach(window_bits, max_rate, _VEC)
    plane, offsets, rate_t = pack_window_planes(body_bits, rates, window_bits)
    code_table = window_code_table(window_codes.to(device), grid, device)
    if code_table.numel() != 1 << window_bits:
        raise GrammarError(
            f"the window table holds {code_table.numel()} entries, window_bits "
            f"{window_bits} needs {1 << window_bits}"
        )
    scale = row_scale.to(device, torch.float32).reshape(-1)
    if scale.numel() != rows:
        raise GrammarError(f"{scale.numel()} row scales for {rows} rows")
    start = _initial_windows(initial, cols, window_bits, device)
    return PreparedWindowUnit(
        _plane_words(plane.contiguous()), plane.numel(), offsets.contiguous(),
        rate_t.contiguous(), start.contiguous(), code_table,
        window_value_table(code_table, device), scale.contiguous(),
        rows, cols, window_bits, max_rate,
    )


def prepare_from_parsed(parsed, device=None) -> PreparedWindowUnit:
    """A ``unit_artifact.ParsedUnit`` of the FP8 route -> a prepared unit.

    Refuses exactly what the reference FP8 materialisation and the trellis
    lane's packer refuse, and for the same reasons: a released position is a
    second plane that overwrites a decoded code, diagonals are a rank-1
    factor outside the product, and a rotation is a basis change.  None of
    the three is applied here, so serving a unit that carries one would serve
    weights the reference decoder does not produce.
    """
    unit, grid = parsed.unit, parsed.grid
    if getattr(unit, "body", BodyKind.TCQ) is not BodyKind.WINDOW:
        raise GrammarError(
            f"this lane decodes the window body; the unit carries {parsed.body.name}"
        )
    if getattr(unit, "scale_plane", None) is not ScalePlaneKind.CHANNEL:
        raise GrammarError(
            "a per-channel FP8 tile takes the CHANNEL plane; the unit carries "
            f"{getattr(getattr(unit, 'scale_plane', None), 'name', None)}"
        )
    if unit.scale_rows is None:
        raise GrammarError("a CHANNEL scale plane needs the unit's row words")
    if unit.release_index.numel():
        raise GrammarError(
            "this unit has released positions, which overwrite decoded codes "
            "from the RELEASE plane; this lane reads no such plane"
        )
    if unit.diagonals is not None:
        raise GrammarError(
            "this unit carries diagonals; undoing them is a rank-1 factor "
            "outside the product, which this lane does not apply"
        )
    if unit.rotation is not RotationState.NONE:
        raise GrammarError(
            f"this unit is rotated ({unit.rotation.name}); undoing the rotation "
            "is a basis change this lane does not apply"
        )
    rows, _cols = unit.body_bits.shape
    row_scale = unit.scale_rows.to(torch.float32) * float(unit.scale_global)
    # ``initial_state`` is absent on a whole unit (the pinned zero start) and
    # present on a tensor-parallel shard, whose columns continue a parent's
    # stream.  Read whichever the artifact carries; never assume the zero.
    #
    # The name is the one ``layout.SlicedUnit`` uses, and it is the field the
    # INITIAL_STATE plane parses into.  This read said ``initial_window``
    # until the 2026-09-02 math audit: a getattr for an attribute nothing
    # defines, so it was always ``None`` and every shard was prepared against
    # the pinned zero start -- decoding its first ``ceil(L/R)`` rows to
    # plausible wrong weights with nothing raised.  The whole-unit path was
    # unaffected, which is why no test saw it.
    return prepare_window_unit(
        unit.body_bits, unit.rates, unit.window_bits, unit.window_codes, grid,
        row_scale.reshape(rows), initial=getattr(unit, "initial_state", None),
        device=device,
    )


# --- the decode kernel ------------------------------------------------------

#: Codes a lane covers out of one 64-bit span.  Eight is what makes the read
#: one int64 for four bytes of wire at R=4 (a 2x L1 overlap with the
#: neighbouring lane, whose span starts four bytes on, and 1x from L2).
_VEC = 8


def _check_reach(window_bits: int, max_rate: int, vec: int) -> None:
    """Refuse a schedule whose ``vec`` windows do not fit one 64-bit span.

    The shifts are silently wrong past the bound and a wrong weight is not an
    error, so this is checked at preparation rather than assumed.
    """
    if not 1 <= max_rate <= window_bits:
        raise GrammarError(f"rate {max_rate} does not fit a {window_bits}-bit window")
    reach = window_bits + (vec - 1) * max_rate + 7
    if reach > WINDOW_SPAN_BITS:
        raise GrammarError(
            f"a {window_bits}-bit window at rate {max_rate} reaches {reach} bits "
            f"across {vec} codes, past the {WINDOW_SPAN_BITS} the kernel reads in "
            "one span"
        )


@triton.jit
def _state_of(span, sub, code, v, rate, init, window: tl.constexpr):
    """The ``window``-bit state of ``VEC`` consecutive codes out of one span.

    ``span`` is the eight wire bytes at the lane's anchor, ``sub`` the anchor's
    sub-byte bit offset, ``code`` the absolute code index, ``v`` its offset
    inside the lane and ``rate`` the column's R.  The arithmetic right shift copies the sign into positions at
    or above the field width, which the mask removes.

    ``init`` is the column's **initial window** -- the ``window`` bits that
    precede its first stored position.  ``pack_window_planes`` pads every
    column with ``window`` zero bits, which *is* ``state_{-1} = 0``, so a
    whole unit reads correctly with ``init = 0``.  A tensor-parallel shard is
    not a whole unit: its first row continues a column whose earlier rows
    live on another rank, and the state it must continue from is that
    parent's last ``window`` bits.  Position ``t`` sits ``d = (t + 1) * R``
    bits into the stream, so the pad still contributes its low ``window - d``
    bits while ``d < window``, in the field's top ``window - d`` places;
    past that the shift register has forgotten it and the term is zero.  The
    ``d & 63`` keeps the dead branch's shift legal.
    """
    MASK: tl.constexpr = (1 << window) - 1
    state = (span >> (64 - sub - v * rate - window)) & MASK
    d = (code + 1) * rate
    return state | tl.where(d < window, (init << (d & 63)) & MASK, 0)


@triton.jit
def _decode_selected_kernel(
    plane_ptr, gather_ptr, shift_ptr, which_ptr, table_ptr, ids_ptr, out_ptr,
    STEPS: tl.constexpr, COLS: tl.constexpr, GROUP_COLS: tl.constexpr,
    PLANE_BYTES: tl.constexpr, EXPERTS: tl.constexpr, ID_STRIDE: tl.constexpr,
    SELECT_START, WINDOW: tl.constexpr,
    BLOCK_T: tl.constexpr, BLOCK_C: tl.constexpr,
):
    """Read the serving owner's four-byte windows; write final selected rows.

    As in ``_decode_kernel``, stream positions are contiguous while reading,
    then a register/shared transpose makes output columns contiguous. The
    prepared pad already contains each expert's row-sliced initial state.
    """
    selected = SELECT_START + tl.program_id(2)
    expert = tl.load(ids_ptr + selected * ID_STRIDE)
    valid_expert = (expert >= 0) & (expert < EXPERTS)
    # Keep addressing legal even if the asynchronous bounds assertion fails.
    safe_expert = tl.where(valid_expert, expert, 0).to(tl.int64)
    t = tl.program_id(0) * BLOCK_T + tl.arange(0, BLOCK_T)
    c = tl.program_id(1) * BLOCK_C + tl.arange(0, BLOCK_C)
    active = (c[:, None] < GROUP_COLS) & (t[None, :] < STEPS) & valid_expert
    row = (safe_expert * GROUP_COLS + c.to(tl.int64)) * PLANE_BYTES
    word = tl.full((BLOCK_C, BLOCK_T), 0, tl.uint32)
    for byte in tl.static_range(4):
        offset = tl.load(gather_ptr + t * 4 + byte, t < STEPS, other=0)
        value = tl.load(plane_ptr + row[:, None] + offset[None, :], active, other=0)
        word = (word << 8) | value.to(tl.uint32)
    shift = tl.load(shift_ptr + t, t < STEPS, other=0)
    state = (word >> shift[None, :]) & ((1 << WINDOW) - 1)
    value = tl.load(table_ptr + safe_expert * (1 << WINDOW) + state,
                    active, other=0)
    col = tl.load(which_ptr + c, c < GROUP_COLS, other=0)
    out = (selected.to(tl.int64) * STEPS + t[:, None]) * COLS + col[None, :]
    tl.store(out_ptr + out, tl.trans(value),
             (t[:, None] < STEPS) & (c[None, :] < GROUP_COLS))


def decode_selected_windows(groups, table, expert_ids, steps, cols, window_bits,
                            max_experts_per_chunk):
    """Eager research decode over ``PreparedWindowBatch``'s existing tensors.

    No repacking, alternate table or retained decoded pool. Only the final
    output and O(selected) ID validation exist outside the kernel; chunks
    bound launches and write disjoint slices of that one output allocation.
    Caller owns metadata/fingerprint checks. Invalid IDs trigger a device
    assertion, and every plane/table read is independently bounded in-kernel.
    """
    torch._assert_async(torch.all((expert_ids >= 0) & (expert_ids < table.shape[0])),
                        "selected window expert IDs out of range")
    out = table.new_empty((expert_ids.numel(), steps, cols))
    if not expert_ids.numel() or not steps or not cols:
        return out
    for start in range(0, expert_ids.numel(), max_experts_per_chunk):
        count = min(max_experts_per_chunk, expert_ids.numel() - start)
        for group in groups:
            _decode_selected_kernel[(triton.cdiv(steps, 32),
                                     triton.cdiv(group.plane.shape[1], 32), count)](
                group.plane, group.gather, group.shift, group.which, table,
                expert_ids, out, steps, cols, group.plane.shape[1],
                group.plane.shape[2], table.shape[0], expert_ids.stride(0),
                start, window_bits, 32, 32, num_warps=4)
    return out


@triton.jit
def _decode_kernel(
    words_ptr, offset_ptr, rate_ptr, init_ptr, table_ptr, scale_ptr, out_ptr,
    rows, cols,
    window: tl.constexpr, LANES: tl.constexpr, VEC: tl.constexpr,
    BLOCK_C: tl.constexpr, SCALED: tl.constexpr,
):
    """A ``[LANES * VEC, BLOCK_C]`` tile of table entries, straight from the wire.

    The table's element type is the tile's: ``uint8`` E4M3 codes for the FP8
    route, whose row scale travels beside the tile as ``weight_scale`` and is
    NOT applied here (``SCALED = False``); ``bfloat16`` values for the BF16
    route, whose tile is what the GEMM multiplies, so the row scale is folded
    in on the way out (``SCALED = True``).  Both are the same decode: the
    state walk and the gather do not know what the table holds.

    The block is ``[BLOCK_C, LANES, VEC]`` while it reads and ``[LANES * VEC,
    BLOCK_C]`` when it writes, and both orders are forced:

    - **Reading, the lane axis is fastest.**  Lane ``l`` of a column anchors
      at bit ``(base + l * VEC + 1) * R``, so at R=4 consecutive lanes' spans
      start four bytes apart and the ``LANES`` span loads cover one
      contiguous ``4 * LANES + 8`` byte run of that column.  With the column
      axis fastest instead, each load is a ``col_bytes``-strided gather.
    - **Writing, the column axis is fastest.**  The tile is row-major
      ``[rows, cols]`` -- the layout ``torch._scaled_mm`` takes -- so a
      contiguous store walks columns.  ``tl.trans`` between the two is a
      register/shared transpose, which is the cheap end of the trade.
    """
    pid_p = tl.program_id(0)
    pid_c = tl.program_id(1)
    lane = tl.arange(0, LANES)
    v = tl.arange(0, VEC)
    c = pid_c * BLOCK_C + tl.arange(0, BLOCK_C)
    live_c = c < cols

    offset = tl.load(offset_ptr + c, mask=live_c, other=0)                 # [BLOCK_C]
    rate = tl.load(rate_ptr + c, mask=live_c, other=1).to(tl.int64)        # [BLOCK_C]
    init = tl.load(init_ptr + c, mask=live_c, other=0).to(tl.int64)        # [BLOCK_C]

    base = pid_p * (LANES * VEC) + lane * VEC                              # [LANES]
    # [BLOCK_C, LANES]: the lane axis last, so the span loads coalesce.
    anchor = offset[:, None] + (base[None, :].to(tl.int64) + 1) * rate[:, None]
    live = live_c[:, None] & (base[None, :] < rows)
    span = _span_of(words_ptr, anchor // 8, live)                          # [BLOCK_C, LANES]

    # The initial-window term is provably zero above the first row block, and
    # hoisting it behind `if pid_p == 0` -- a program-uniform branch, so it
    # looked free -- cost 10.6x: 1024x3072 went 23.9 -> 253.1 us, 1024x1024
    # 11.4 -> 25.5, 4096x2560 261.5 -> 740.3 (hoist_ab.py, idle GB10, min of 9
    # rounds).  A branch whose result is a [BLOCK_C, LANES, VEC] tensor makes
    # Triton carry that tensor across an `scf.if`, and it leaves the register
    # file to do it.  The arithmetic the branch saves is three integer ops per
    # code; the spill it buys costs an order of magnitude more.  Compute it
    # unconditionally.
    code = base[None, :, None].to(tl.int64) + v[None, None, :].to(tl.int64)
    state = _state_of(
        span[:, :, None], (anchor % 8)[:, :, None], code,
        v[None, None, :].to(tl.int64), rate[:, None, None], init[:, None, None],
        window,
    )                                                                      # [BLOCK_C, LANES, VEC]
    entry = tl.load(table_ptr + state, mask=live[:, :, None], other=0)

    out = tl.trans(tl.reshape(entry, (BLOCK_C, LANES * VEC)), 1, 0)        # [LANES*VEC, BLOCK_C]
    p = pid_p * (LANES * VEC) + tl.arange(0, LANES * VEC)
    keep = (p[:, None] < rows) & live_c[None, :]
    if SCALED:
        scale = tl.load(scale_ptr + p, mask=p < rows, other=0.0)
        out = (out.to(tl.float32) * scale[:, None]).to(out_ptr.dtype.element_ty)
    tl.store(out_ptr + p[:, None].to(tl.int64) * cols + c[None, :], out, mask=keep)


#: Columns a decode program covers.  **Measured, not guessed.**  The block is
#: ``[BLOCK_C, LANES, VEC]`` live registers, so this is what sets the decoder's
#: occupancy, and 64 -- the first cut -- spilled.  ncu on the FP8 code path,
#: one warmed launch each, sparklina 2026-09-02 (duration / registers /
#: local-spill requests / achieved occupancy / L2 throughput):
#:
#:   1024x3072   64: 55.94 us  255 reg  64,512 sp  16.2%  21.7%
#:               32: 41.09     199       0         16.2%  17.4%
#:               16: 32.77      96       0         38.0%  50.7%   <- default
#:                8: 43.78      54       0         64.4%  68.9%
#:   2560x9728   64: 301.66   255 reg  510,720 sp  16.4%  33.2%
#:               16: 198.53      96       0        39.9%  67.4%
#:                8: 289.44      54       0        68.1%  83.0%
#:   4096x2560   64: 136.26   255 reg  215,040 sp  16.3%  29.6%
#:               16:  99.17      96       0        39.1%  54.5%
#:                8: 125.98      54       0        67.2%  78.9%
#:
#: (registers measured on 1024x3072 and constant in the shape; the spill counts
#: are 336 a block at 64 and zero below it.)
#:
#: 16 is 1.37-1.71x over 64 on all three shapes and 8 gives the occupancy back
#: without the time -- past 16 each program's per-column reads stop amortising
#: and L2 traffic rises for the same useful bytes.  The value family prefers 16
#: too (47.94 us vs 56.67 at 64, 93.82 at 4).  Changing this changes no bytes:
#: it is a tiling constant and the tests hold it byte-identical.
_DECODE_BLOCK_C = 16


def _decode_impl(plane_words, offsets, rates, initial, table, rows, cols,
                 window_bits, max_rate, row_scale=None, lanes: int = 32,
                 block_c: int = _DECODE_BLOCK_C):
    """One tile in the table's dtype; ``row_scale`` given means fold it in."""
    out = torch.empty((rows, cols), dtype=table.dtype, device=plane_words.device)
    _decode_kernel[(triton.cdiv(rows, lanes * _VEC), triton.cdiv(cols, block_c))](
        plane_words, offsets, rates, initial, table,
        table if row_scale is None else row_scale, out, rows, cols,
        window=window_bits, LANES=lanes, VEC=_VEC, BLOCK_C=block_c,
        SCALED=row_scale is not None, num_warps=4,
    )
    return out


# --- the GEMV kernel --------------------------------------------------------

#: Columns a program reads per loop iteration.  The offsets, rates, initial
#: windows and activations are then vector loads instead of one dependent
#: scalar load apiece per column, which is what the first cut spent its time
#: on: at ``KB = 1`` the same kernel ran 96.7 us where this runs 19.6.
_KB = 8

#: Warps a GEMV program runs on.  Measured, not guessed; see ``_gemv_impl``.
_WARPS = 2


@triton.jit
def _gemv_kernel(
    x_ptr, words_ptr, offset_ptr, rate_ptr, init_ptr, value_ptr, scale_ptr, out_ptr,
    rows, cols, m,
    window: tl.constexpr, LANES: tl.constexpr, VEC: tl.constexpr,
    MBLK: tl.constexpr, KB: tl.constexpr, SPLIT: tl.constexpr,
):
    """``out[m, n] += scale[n] * sum_k value(n, k) * x[m, k]`` off the wire.

    A program owns ``LANES * VEC`` consecutive output rows and a **contiguous**
    slice of the input columns -- contiguous, not strided by ``SPLIT``, so the
    bytes a program touches are one run of each column's stream rather than
    ``cols / SPLIT`` scattered ones.  The row scale is folded into each
    partial before the atomic, so there is no epilogue launch over the output.

    The reduction axis is the *column* axis, the one the trellis does not run
    down, so the split changes only the fp32 summation order and nothing
    about what is decoded.

    Per code the work is one gather out of the ``2^L`` fp16 value table
    (32 KB) and one FMA; per ``VEC`` codes it is one two-word span load.
    """
    pid_n = tl.program_id(0)
    pid_k = tl.program_id(1)
    lane = tl.arange(0, LANES)
    v = tl.arange(0, VEC)
    mi = tl.arange(0, MBLK)
    j = tl.arange(0, KB)
    live_m = mi < m

    base = pid_n * (LANES * VEC) + lane * VEC                       # [LANES]
    n = base[:, None] + v[None, :]                                  # [LANES, VEC]
    live = n < rows
    scale = tl.load(scale_ptr + n, mask=live, other=0.0)

    acc = tl.zeros((MBLK, LANES, VEC), dtype=tl.float32)
    chunk = tl.cdiv(cols, SPLIT * KB) * KB
    start = pid_k * chunk
    stop = tl.minimum(start + chunk, cols)
    for k0 in range(start, stop, KB):
        kk = k0 + j                                                 # [KB]
        lk = kk < cols
        offset = tl.load(offset_ptr + kk, mask=lk, other=0)
        rate = tl.load(rate_ptr + kk, mask=lk, other=1).to(tl.int64)
        init = tl.load(init_ptr + kk, mask=lk, other=0).to(tl.int64)
        anchor = offset[:, None] + (base[None, :].to(tl.int64) + 1) * rate[:, None]
        ok = lk[:, None] & (base[None, :] < rows)                   # [KB, LANES]
        span = _span_of(words_ptr, anchor // 8, ok)
        code = base[None, :, None].to(tl.int64) + v[None, None, :].to(tl.int64)
        state = _state_of(
            span[:, :, None], (anchor % 8)[:, :, None], code,
            v[None, None, :].to(tl.int64), rate[:, None, None], init[:, None, None],
            window,
        )                                                           # [KB, LANES, VEC]
        value = tl.load(value_ptr + state, mask=ok[:, :, None], other=0.0).to(tl.float32)
        xv = tl.load(x_ptr + mi[:, None] * cols + kk[None, :],
                     mask=live_m[:, None] & lk[None, :], other=0.0).to(tl.float32)
        acc += tl.sum(xv[:, :, None, None] * value[None, :, :, :], axis=1)

    tl.atomic_add(
        out_ptr + mi[:, None, None] * rows + n[None, :, :], acc * scale[None, :, :],
        mask=live_m[:, None, None] & live[None, :, :],
    )


def _gemv_split(rows: int, lanes: int) -> int:
    """Column splits: enough programs to fill the box, as few as fill it.

    ``rows / (LANES * VEC)`` programs come from the output axis alone -- four
    for a 1024-row unit -- so the split is what puts work on the other 44 SMs.
    Rounded to a power of two so the launch shape is stable across the five
    shapes of a checkpoint rather than jittering with ``rows``.
    """
    blocks = max(1, -(-rows // (lanes * _VEC)))
    want = max(8, min(128, 256 // blocks))
    return 1 << (want.bit_length() - 1)


def _gemv_impl(x, plane_words, offsets, rates, initial, value_table, row_scale, rows,
               cols, window_bits, max_rate, lanes: int = 32, split: "int | None" = None,
               kb: "int | None" = None, warps: "int | None" = None):
    m = x.shape[0]
    mblk = 1 if m <= 1 else 1 << (m - 1).bit_length()
    # Two warps a program, at every M.  The inner temporary is
    # [MBLK, KB, LANES, VEC] fp32 and the decoded state is [KB, LANES, VEC]
    # int64, so a program is register-hungry however many warps carry it, and
    # widening the launch to cover a larger MBLK -- num_warps = min(8, 2*mblk),
    # which is what this line used to say -- made it worse at every point of a
    # 3-shape x 3-M x 36-config sweep on an idle box: 1024x3072 at M=8 took
    # 96.1 us at eight warps against 29.1 at two.  More warps means more live
    # registers per SM for the same tile, not more parallelism; the parallelism
    # is in the grid (rows/(LANES*VEC) x SPLIT).  Fewer than two lost on the
    # large shapes.  The sweep is `experiments/bench_kernel_window.py --arm
    # gemv` plus /home/rob/tmp/kernel-window/msweep2.py.
    kb = _KB if kb is None else kb
    split = _gemv_split(rows, lanes) if split is None else split
    out = torch.zeros((m, rows), dtype=torch.float32, device=x.device)
    _gemv_kernel[(triton.cdiv(rows, lanes * _VEC), split)](
        x, plane_words, offsets, rates, initial, value_table, row_scale, out,
        rows, cols, m,
        window=window_bits, LANES=lanes, VEC=_VEC, MBLK=mblk, KB=kb, SPLIT=split,
        num_warps=(_WARPS if warps is None else warps),
    )
    return out


# --- the ops ----------------------------------------------------------------
#
# ``torch.library.custom_op`` with ``mutates_args=()``: every op allocates and
# returns its own output, touches no buffer it did not make, reads no data
# pointer and branches on no traced value.  That is the shape a compiled vLLM
# forward can functionalise -- each of those four has broken a serving lane
# here before (``vllm-compiled-forward-breaks-lane-hot-paths``).


@torch.library.custom_op("tessera_window::decode_fp8_tile", mutates_args=())
def decode_fp8_tile(
    plane_words: torch.Tensor,
    offsets: torch.Tensor,
    rates: torch.Tensor,
    initial: torch.Tensor,
    code_table: torch.Tensor,
    rows: int,
    cols: int,
    window_bits: int,
    max_rate: int,
) -> torch.Tensor:
    """The unit's E4M3 tile, ``uint8 [rows, cols]``, decoded from the wire.

    Byte-identical to ``decode.materialize_fp8``'s first return and to a
    stock ``float-quantized`` checkpoint's ``weight`` at ``strategy:
    channel``; the row scale is the prepared unit's ``row_scale``, which is
    the same fp32 expression the reference decoder returns.
    """
    _check_reach(int(window_bits), int(max_rate), _VEC)
    if code_table.dtype != torch.uint8:
        raise GrammarError(
            f"the FP8 route's table holds E4M3 bytes; this one is {code_table.dtype}"
            " (a value table goes through decode_value_tile)"
        )
    return _decode_impl(plane_words, offsets, rates, initial, code_table,
                        int(rows), int(cols), int(window_bits), int(max_rate))


@decode_fp8_tile.register_fake
def _(plane_words, offsets, rates, initial, code_table, rows, cols, window_bits,
      max_rate):
    return plane_words.new_empty((rows, cols), dtype=torch.uint8)


@torch.library.custom_op("tessera_window::decode_value_tile", mutates_args=())
def decode_value_tile(
    plane_words: torch.Tensor,
    offsets: torch.Tensor,
    rates: torch.Tensor,
    initial: torch.Tensor,
    value_table: torch.Tensor,
    row_scale: torch.Tensor,
    rows: int,
    cols: int,
    window_bits: int,
    max_rate: int,
) -> torch.Tensor:
    """The unit's tile in the table's own dtype, row scale applied.

    The BF16 family's decode target: the same WINDOW body, the same CHANNEL
    plane and the same ``2^L`` table as the FP8 route, but the table holds
    bf16 VALUES rather than E4M3 codes, so the tile that comes out is what a
    stock BF16 GEMM multiplies -- there is no separate ``weight_scale`` for
    the runtime to carry, because the scale is already in the numbers.

    The dtype is the table's, not a parameter: a bf16 table decodes a bf16
    tile, an fp16 table an fp16 tile.  ``decode_fp8_tile`` is the same kernel
    with a uint8 table and the scale left outside.
    """
    _check_reach(int(window_bits), int(max_rate), _VEC)
    if value_table.dtype not in (torch.bfloat16, torch.float16, torch.float32):
        raise GrammarError(
            "a value table holds floating-point values; this one is "
            f"{value_table.dtype} (E4M3 codes go through decode_fp8_tile)"
        )
    if row_scale.numel() != rows:
        raise GrammarError(f"{row_scale.numel()} row scales for {rows} rows")
    return _decode_impl(plane_words, offsets, rates, initial, value_table,
                        int(rows), int(cols), int(window_bits), int(max_rate),
                        row_scale=row_scale)


@decode_value_tile.register_fake
def _(plane_words, offsets, rates, initial, value_table, row_scale, rows, cols,
      window_bits, max_rate):
    return value_table.new_empty((rows, cols))


@torch.library.custom_op("tessera_window::window_gemv", mutates_args=())
def window_gemv(
    x: torch.Tensor,
    plane_words: torch.Tensor,
    offsets: torch.Tensor,
    rates: torch.Tensor,
    initial: torch.Tensor,
    value_table: torch.Tensor,
    row_scale: torch.Tensor,
    rows: int,
    cols: int,
    window_bits: int,
    max_rate: int,
) -> torch.Tensor:
    """``x @ W.T`` for ``x [M, cols]``, decoding the wire in the kernel.

    Returns ``[M, rows]`` fp32.  The tile is never materialised, so the
    weight traffic per token is the wire's, not the resident tile's.  Split-K
    reduces by fp32 atomic add, so the sum order is not fixed run to run --
    a one-hot probe still returns a column exactly, because nothing is
    summed.
    """
    _check_reach(int(window_bits), int(max_rate), _VEC)
    if x.ndim != 2 or x.shape[1] != cols:
        raise GrammarError(f"x is {tuple(x.shape)}, the unit takes [M, {cols}]")
    if not 1 <= x.shape[0] <= GEMV_MAX_M:
        raise GrammarError(
            f"window_gemv is the small-M path: M={x.shape[0]} past {GEMV_MAX_M} grows "
            "the register accumulator past what the launch holds; decode the tile and "
            "run the GEMM (window_linear does this on its own)"
        )
    return _gemv_impl(x.contiguous(), plane_words, offsets, rates, initial, value_table,
                      row_scale, int(rows), int(cols), int(window_bits), int(max_rate))


@window_gemv.register_fake
def _(x, plane_words, offsets, rates, initial, value_table, row_scale, rows, cols,
      window_bits, max_rate):
    return x.new_empty((x.shape[0], rows), dtype=torch.float32)


def _fp8_per_token(x: torch.Tensor):
    """Per-token dynamic E4M3 quantisation for ``window_linear`` (the
    research GEMV op, off the serving path).  The served FP8 route quantises
    with vLLM's own op (``serving.native_ops.native_fp8_quant``), whose
    arithmetic differs from this one at the scale floor and in the division
    rounding (``tests/test_native_fp8_quant.py``)."""
    amax = x.abs().amax(dim=1, keepdim=True).to(torch.float32).clamp_min(1e-12)
    scale = amax / 448.0
    return (x.to(torch.float32) / scale).clamp(-448.0, 448.0).to(torch.float8_e4m3fn), scale


@torch.library.custom_op("tessera_window::window_linear", mutates_args=())
def window_linear(
    x: torch.Tensor,
    plane_words: torch.Tensor,
    offsets: torch.Tensor,
    rates: torch.Tensor,
    initial: torch.Tensor,
    code_table: torch.Tensor,
    value_table: torch.Tensor,
    row_scale: torch.Tensor,
    rows: int,
    cols: int,
    window_bits: int,
    max_rate: int,
    gemv_max: int = GEMV_MAX_M,
) -> torch.Tensor:
    """One Linear over the window wire: ``x @ W.T``, ``[..., cols] -> [..., rows]``.

    The M dispatch lives **inside** the op, where ``x.shape[0]`` is a
    concrete integer, and the fake impl reports the output shape without
    reading it.  A dispatch written in the traced forward instead would be a
    guard on the token dimension, which is the exact break the lane hit
    before (``vllm-compiled-forward-breaks-lane-hot-paths``).

    ``gemv_max`` is the largest M the fused GEMV takes; above it the tile is
    decoded and the stock W8A8 ``_scaled_mm`` mainloop runs.  **The two
    branches execute different activation contracts** -- the GEMV multiplies
    the bf16 activation directly (W8A16-class), the GEMM quantises it per
    token to E4M3 (W8A8) -- so a lane that turns the GEMV on must say so in
    its route record (principle 14).  ``gemv_max=0`` disables the GEMV and
    leaves one contract on the path.
    """
    orig = x.shape
    x2 = x.reshape(-1, int(cols))
    if x2.dtype != torch.bfloat16:
        x2 = x2.to(torch.bfloat16)
    if 0 < x2.shape[0] <= min(int(gemv_max), GEMV_MAX_M):
        y = window_gemv(x2, plane_words, offsets, rates, initial, value_table,
                        row_scale, rows, cols, window_bits, max_rate).to(torch.bfloat16)
    else:
        tile = decode_fp8_tile(plane_words, offsets, rates, initial, code_table,
                               rows, cols, window_bits, max_rate)
        a_q, a_scale = _fp8_per_token(x2.contiguous())
        y = torch._scaled_mm(
            a_q, tile.view(torch.float8_e4m3fn).t(),
            scale_a=a_scale, scale_b=row_scale.view(1, int(rows)),
            out_dtype=torch.bfloat16,
        )
    return y.reshape(*orig[:-1], int(rows))


@window_linear.register_fake
def _(x, plane_words, offsets, rates, initial, code_table, value_table, row_scale,
      rows, cols, window_bits, max_rate, gemv_max=GEMV_MAX_M):
    return x.new_empty((*x.shape[:-1], rows), dtype=torch.bfloat16)


@torch.library.custom_op("tessera_window::window_value_linear", mutates_args=())
def window_value_linear(
    x: torch.Tensor,
    plane_words: torch.Tensor,
    offsets: torch.Tensor,
    rates: torch.Tensor,
    initial: torch.Tensor,
    value_table: torch.Tensor,
    row_scale: torch.Tensor,
    rows: int,
    cols: int,
    window_bits: int,
    max_rate: int,
    gemv_max: int = GEMV_MAX_M,
) -> torch.Tensor:
    """One Linear of the BF16 family: ``x @ W.T`` over a float value table.

    Same dispatch shape as ``window_linear`` and for the same reason -- M is
    read inside the op, where it is a concrete integer, never in the traced
    forward.  The difference is the activation contract on the wide side:
    this family decodes a bf16 tile and runs the stock BF16 GEMM (W16A16),
    where the FP8 family quantises the activation per token to E4M3 (W8A8).
    On the narrow side both accumulate in fp32 off the table, so the small-M
    contract is W16A16 for both -- which the FP8 route's record has to say,
    and which is native here.
    """
    orig = tuple(x.shape)
    x2 = x.reshape(-1, int(cols))
    if x2.shape[0] <= int(gemv_max):
        y = window_gemv(x2.contiguous(), plane_words, offsets, rates, initial,
                        value_table, row_scale, rows, cols, window_bits, max_rate)
        y = y.to(value_table.dtype)
    else:
        tile = decode_value_tile(plane_words, offsets, rates, initial, value_table,
                                 row_scale, rows, cols, window_bits, max_rate)
        y = torch.matmul(x2.to(value_table.dtype), tile.t())
    return y.reshape(*orig[:-1], int(rows))


@window_value_linear.register_fake
def _(x, plane_words, offsets, rates, initial, value_table, row_scale, rows, cols,
      window_bits, max_rate, gemv_max=GEMV_MAX_M):
    return x.new_empty((*x.shape[:-1], rows), dtype=value_table.dtype)


def prepare_window_values(
    body_bits: torch.Tensor,
    rates,
    window_bits: int,
    value_table: torch.Tensor,
    row_scale: torch.Tensor,
    initial: "torch.Tensor | None" = None,
    device=None,
) -> PreparedWindowUnit:
    """Pack a BF16-family unit: the same wire, a float table instead of codes.

    ``value_table`` is the family's ``2^L`` bf16 values -- not codes into a
    hardware grid, so nothing is composed through ``grid.native`` and there is
    no byte tile.  Everything else (the packing, the per-column rates, the
    initial windows a TP shard starts from, the CHANNEL row scale) is what
    ``prepare_window_unit`` does, because it is the same body.
    """
    device = torch.device("cuda" if device is None else device)
    body_bits = body_bits.to(device)
    rows, cols = body_bits.shape
    rates = tuple(int(r) for r in rates)
    if len(rates) != cols:
        raise GrammarError(f"{len(rates)} rates for {cols} columns")
    window_bits = int(window_bits)
    max_rate = max(rates)
    _check_reach(window_bits, max_rate, _VEC)
    table = value_table.reshape(-1).to(device).contiguous()
    if table.dtype not in (torch.bfloat16, torch.float16, torch.float32):
        raise GrammarError(
            f"a value table holds floating-point values; this one is {table.dtype}"
        )
    if table.numel() != 1 << window_bits:
        raise GrammarError(
            f"the window table holds {table.numel()} entries, window_bits "
            f"{window_bits} needs {1 << window_bits}"
        )
    plane, offsets, rate_t = pack_window_planes(body_bits, rates, window_bits)
    scale = row_scale.to(device, torch.float32).reshape(-1)
    if scale.numel() != rows:
        raise GrammarError(f"{scale.numel()} row scales for {rows} rows")
    start = _initial_windows(initial, cols, window_bits, device)
    return PreparedWindowUnit(
        _plane_words(plane.contiguous()), plane.numel(), offsets.contiguous(),
        rate_t.contiguous(), start.contiguous(), None, table, scale.contiguous(),
        rows, cols, window_bits, max_rate,
    )


# --- the seam a serving lane calls ------------------------------------------
#
# A vLLM Linear is one *module* of one or more Tessera *units* -- q/k/v are
# three units behind one `qkv_proj`, gate/up two behind one `gate_up_proj` --
# stacked along the output-row axis in role order.  The FP8 route's prepared
# module (`serving/fp8_route.py::prepare_tessera_fp8_module`) holds one
# packed window per role and concatenates their decoded tiles; these three
# take the same list of prepared units and do the same thing through the
# kernels here, so a lane swaps one for the other without changing its own
# shape logic.


def window_module_decode(units) -> torch.Tensor:
    """The module's whole E4M3 tile, ``uint8 [sum(rows), cols]``, role order.

    Byte-identical to ``torch.cat([materialize_fp8(u)[0] for u in units], 0)``,
    which is what the route's ``PreparedTesseraFp8Module.decode`` returns.
    """
    units = list(units)
    if not units:
        raise GrammarError("a module needs at least one unit")
    if len({u.cols for u in units}) != 1:
        raise GrammarError(
            "the units of one module share their input columns; these carry "
            f"{sorted({u.cols for u in units})}"
        )
    if len(units) == 1:
        return units[0].decode()
    return torch.cat([u.decode() for u in units], 0)


def window_module_row_scale(units) -> torch.Tensor:
    """The module's per-row fp32 scale, ``[sum(rows)]``, role order.

    FP8 family only.  On the value family the row scale is already inside the
    decoded tile, so handing it back to a caller that will apply it again is a
    silent factor of ``scale`` -- exactly the mistake this seam exists to stop
    a lane from making.  Refuse instead.
    """
    units = list(units)
    if any(u.family != "fp8" for u in units):
        raise GrammarError(
            "the value family's row scale is already applied inside the "
            "decoded tile; there is no separate scale to hand out"
        )
    if len(units) == 1:
        return units[0].row_scale
    return torch.cat([u.row_scale for u in units]).contiguous()


def window_module_linear(x: torch.Tensor, units, gemv_max: int = GEMV_MAX_M):
    """``x @ W.T`` for a whole module: ``[..., cols] -> [..., sum(rows)]``.

    Each unit runs its own ``window_linear``, and the results concatenate on
    the output axis -- which is what the stacked tile would have produced,
    because the roles do not interact.  One launch per unit, so a three-role
    ``qkv_proj`` issues three; a single stacked launch is possible (the units
    would have to share one packed plane) and is not built.

    The activation-contract caveat on ``window_linear`` applies here: on the
    FP8 family, below ``gemv_max`` this multiplies bf16 activations directly
    and above it quantises them per token to E4M3.  A lane that enables the
    GEMV branch is changing what its ``emit_route`` record must say.  The
    BF16 family is W16A16 on both sides, and each unit routes by its own
    family, so a module never mixes the two silently.
    """
    units = list(units)
    if not units:
        raise GrammarError("a module needs at least one unit")
    if len({u.family for u in units}) != 1:
        raise GrammarError(
            "the units of one module are one family; these are "
            f"{sorted({u.family for u in units})}"
        )
    parts = [u.linear(x, gemv_max) for u in units]
    return parts[0] if len(parts) == 1 else torch.cat(parts, dim=-1)
