"""The native window MoE adapter: two grouped window GEMMs around the
activation, for the FP8 and BF16 routed-expert families.

WHAT IT IS.  ``PreparedGroupedWindowGemm`` (``window_gemm_grouped``) computes
one projection under a token->expert routing.  A routed MoE layer is two of
them -- gate/up, then down -- with the activation between, and that is what
this module owns:

* ``gate/up`` runs in ``preserve=True`` mode: per-route outputs
  ``[T, top_k, 2I]`` (or two ``[T, top_k, I]`` stacks if gate and up are
  separate).  The routing weight multiplies this projection's fp32
  accumulator iff ``apply_router_weight_on_input``, which is the legacy
  ``fused_moe.py`` placement.  The MODULAR path that serves instead applies the
  weight in ``prepare`` -- to the hidden states, BEFORE the activation
  quantization (``prepare_finalize/no_dp_ep.py``) -- and that is what this
  adapter now reproduces, so both are named here rather than conflated.
* the activation is applied per route.  ``silu`` is served, with the model's
  SwiGLU clamp (``swiglu_limit`` / vLLM's ``gemm1_clamp_limit``) reproduced by
  clamping both branches in fp32 before the activation -- the gate saturates at
  ``+limit`` and the up branch at ``+-limit``, the arithmetic vLLM's own
  ``silu_and_mul``/``apply_moe_activation`` performs.  ``swiglu_alpha``,
  ``swiglu_beta`` and another activation **fail closed** until an
  implementation reproduces vLLM's exact arithmetic -- no silent
  substitution.
* ``down`` runs with ``route_input=True``: it consumes the per-route
  activations, and weights each route's fp32 accumulator iff the input did
  not already carry the weights (vLLM's gemm2 / ``topk_weight_and_reduce``
  placement), summing over ``top_k``.

ARITHMETIC.  The weight-side contract is the grouped bundle's and is explicit
at preparation: ``"epilogue"`` (dense BF16 row scale on the fp32 accumulator,
or the FP8 ``acc * a_scale * w_scale`` contract) or ``"folded"`` (the
BF16 expert contract, one bf16 rounding of ``value * row_scale`` in
registers before ``tl.dot``).  The adapter inherits it from the bundles; the
FP8 family has no folded form.

WHAT REMAINS THE OWNER'S.  Routing (top-k ids and weights), shared experts,
the TP all-reduce and the final scale/dtype presentation are the serving
layer's; this adapter returns the routed-expert result ``[T, rows]`` bf16.
"""
from __future__ import annotations

import dataclasses
import logging
import math
from typing import Sequence

import torch

from .errors import GrammarError
from .kernel_window_gemv import WindowGemvUnit
from .window_gemm_grouped import PreparedGroupedWindowGemm, prepare_grouped_window_gemm

__all__ = ["NativeWindowMoE", "prepare_native_window_moe", "PackedWindowUnits",
           "SUPPORTED_ACTIVATIONS", "checked_swiglu_limit"]

#: The activations this adapter reproduces exactly.  Everything else refuses.
SUPPORTED_ACTIVATIONS = ("silu",)
_log = logging.getLogger(__name__)


@dataclasses.dataclass(frozen=True)
class PackedWindowUnits:
    """Rank-local per-expert units in GLOBAL expert order, one entry per
    expert: what a loader hands the adapter without a second weight walk."""

    gate: tuple
    up: tuple
    down: tuple
    family: str

    @property
    def experts(self) -> int:
        return len(self.down)

    def resident_bytes(self) -> int:
        total = 0
        for unit in (*self.gate, *self.up, *self.down):
            rep = unit.rep
            total += rep.words.numel() * rep.words.element_size()
            for t in (unit.table, unit.scale, unit.initial_state, unit.codes_of_state, unit.native):
                if t is not None:
                    total += t.numel() * t.element_size()
        return total

    def prepare(self, *, block_m: int = 64, block_n: int = 64, block_k: int = 64,
                arithmetic: "str | None" = None, activation: str = "silu",
                quantizer: "str | None" = "native") -> "NativeWindowMoE":
        """Build the adapter.  The default arithmetic is each family's
        published contract: folded for the research BF16 wire, epilogue for
        the FP8 wire.  An explicit value must match the family's served
        contract; nothing here silently swaps them."""
        if arithmetic is None:
            arithmetic = "folded" if self.family == "value" else "epilogue"
        up = list(self.up) if self.up else None
        return prepare_native_window_moe(
            list(self.gate), list(self.down), up=up,
            block_m=block_m, block_n=block_n, block_k=block_k,
            quantizer=quantizer, arithmetic=arithmetic, activation=activation)


@dataclasses.dataclass(frozen=True)
class NativeWindowMoE:
    """Two grouped projections around the activation.  ``gate_up`` is the
    fused ``[2I]`` stack; ``gate``/``up`` are the separate-stack spelling."""

    gate_up: "PreparedGroupedWindowGemm | None"
    gate: "PreparedGroupedWindowGemm | None"
    up: "PreparedGroupedWindowGemm | None"
    down: PreparedGroupedWindowGemm
    activation: str = "silu"

    @property
    def launch_pair(self) -> "tuple[str, str]":
        """``(symbol, decoder)`` this adapter's forward is recorded under.

        The compact lane's symbol with the family's arithmetic-naming decoder
        (``scheme.ROUTE_LAUNCHES``); the route reads it off the adapter so a
        different adapter behind the same attribute (``tessera.routed_fused``)
        is recorded as itself, never under this name.
        """
        from .serving.scheme import WINDOW_MOE_COMPACT_SYMBOL
        from .serving.telemetry import (DECODER_NATIVE_WINDOW_MOE_COMPACT,
                                        DECODER_NATIVE_WINDOW_MOE_COMPACT_FOLDED)

        decoder = (DECODER_NATIVE_WINDOW_MOE_COMPACT_FOLDED if self.down.family == "value"
                   else DECODER_NATIVE_WINDOW_MOE_COMPACT)
        return WINDOW_MOE_COMPACT_SYMBOL, decoder

    def __call__(self, x: torch.Tensor,
                 expert_ids: torch.Tensor,
                 routing_weights: torch.Tensor,
                 *,
                 apply_router_weight_on_input: bool = False,
                 swiglu_limit: "float | None" = None) -> torch.Tensor:
        limit = checked_swiglu_limit(swiglu_limit)
        if self.activation not in SUPPORTED_ACTIVATIONS:
            raise GrammarError(
                f"the native window MoE serves {SUPPORTED_ACTIVATIONS}; "
                f"activation {self.activation!r} has no exact implementation here "
                "and refusing beats approximating vLLM's arithmetic"
            )
        # ``apply_router_weight_on_input`` is the MODULAR kernel's prepare-time
        # placement, and that is a different operation from the legacy
        # monolithic one.  ``prepare_finalize/no_dp_ep.py`` multiplies the
        # HIDDEN STATES by ``topk_weights`` and only THEN calls
        # ``_quantize_input``: the route weight is applied to x BEFORE the
        # per-token FP8 activation quantization, so the activation scale is
        # computed from the SCALED magnitudes.  A lane that quantizes the
        # unscaled x and scales the gemm1 accumulator afterwards is quantizing
        # different numbers, which is a different function, not a rounding
        # difference.  Legacy ``fused_moe.py`` scales the accumulator; the
        # modular path is what serves, and this lane follows the modular one.
        #
        # vLLM's prepare asserts the placement is only implemented for topk=1;
        # refuse rather than silently serving something else.
        inter = self.down.cols
        if apply_router_weight_on_input:
            if int(expert_ids.shape[1]) != 1:
                raise GrammarError(
                    f"apply_router_weight_on_input is only implemented for topk=1 "
                    f"(vLLM's own prepare asserts this); got topk="
                    f"{int(expert_ids.shape[1])}"
                )
            # BEFORE the activation quantization, as the modular prepare does:
            # ``no_dp_ep.py`` computes ``a1 = a1 * topk_weights.to(a1.dtype)``
            # and only then quantizes.  The weight is narrowed to the ACTIVATION
            # dtype first (not left fp32 to promote the product) and the product
            # keeps that dtype, so the per-token scale is computed from exactly
            # the magnitudes the stock prepare feeds its quantizer.
            weights_in = routing_weights.reshape(-1, 1).to(x.dtype)
            x = x * weights_in
        # gemm1 consumes the ALREADY-SCALED activations: the weight is in x,
        # so neither gemm1 nor gemm2 may apply it again.
        if self.gate_up is not None:
            route = self.gate_up(x, expert_ids, routing_weights, preserve=True,
                                 apply_router_weight_on_input=False)
            if route.shape[-1] != 2 * inter:
                raise GrammarError(
                    f"the fused gate/up stack produces {route.shape[-1]} rows, "
                    f"the down stack consumes {inter} per half"
                )
            gate, up = route[..., :inter], route[..., inter:]
        else:
            gate = self.gate(x, expert_ids, routing_weights, preserve=True,
                             apply_router_weight_on_input=False)
            up = self.up(x, expert_ids, routing_weights, preserve=True,
                         apply_router_weight_on_input=False)
        act = _silu_and_mul(gate, up, clamp_limit=limit)
        t_tokens, top_k, _ = act.shape
        # The down stage's weight application is decided by
        # ``MUL_WEIGHT=(apply_router_weight_on_input == preserve)``
        # (``window_gemm_grouped.py``) with ``preserve=False`` here, so the flag
        # must be FORWARDED unchanged: True suppresses the second
        # multiplication once x already carries the routes, False lets the down
        # stage weight them when nothing upstream did.  Passing False
        # unconditionally would multiply by the routes a second time.
        return self.down(act.reshape(t_tokens * top_k, inter), expert_ids, routing_weights,
                         route_input=True,
                         apply_router_weight_on_input=apply_router_weight_on_input,
                         round_routes=True)


def checked_swiglu_limit(limit: "float | None", *, where: str = "") -> "float | None":
    """Validate a model's SwiGLU clamp limit, or ``None`` when absent.

    vLLM carries this as ``gemm1_clamp_limit`` and refuses, in its own words,
    to let a backend "silently select one and drop the clamp"; a value that is
    not a finite positive number is a model fact we cannot reproduce, so it
    fails closed here instead of arming a clamp that does nothing.
    """
    if limit is None:
        return None
    try:
        value = float(limit)
    except (TypeError, ValueError) as exc:
        raise GrammarError(
            f"{where}swiglu_limit {limit!r} is not a number; refusing") from exc
    if not math.isfinite(value) or value <= 0.0:
        raise GrammarError(
            f"{where}swiglu_limit {value!r} is not finite and positive; refusing")
    return value


def _silu_and_mul(gate: torch.Tensor, up: torch.Tensor, *,
                  clamp_limit: "float | None" = None) -> torch.Tensor:
    """``silu(gate) * up`` with one bf16 rounding, the same arithmetic vLLM's
    ``SiluAndMul`` performs on the gemm output (fp32 activation, cast once).

    ``clamp_limit`` is vLLM's SwiGLU clamp: the gate saturates at ``+limit``
    (no lower clamp), the up branch at ``+-limit``.

    DTYPE.  In the production adapter these branches are the ``preserve=True``
    grouped outputs, which ``window_gemm_grouped`` allocates as **bfloat16**
    (``result = torch.empty(..., dtype=torch.bfloat16)``), so the clamp
    saturates a bf16 tile -- NOT an fp32 accumulator.  The saturation points are
    identical in fp32 (that is the stock op's arithmetic) and the cast below
    keeps the product in fp32, so the result is the single bf16 rounding of
    ``silu(clamp(gate)) * clamp(up)`` either way; what must not be claimed is
    that the clamp sees fp32 accumulators on this path.

    The stock stage this lane replaces:
    ``vllm/model_executor/layers/fused_moe/activation.py``
    ``silu_and_mul_with_clamp`` (SILU + a clamp resolves to
    ``torch.ops._C.silu_and_mul_with_clamp``), whose XPU branch spells the
    directions out as ``clamp(gate, max=limit)`` / ``clamp(up, -limit, limit)``.
    The quantised-activation Triton kernel
    ``.../layers/quantization/utils/fp8_utils.py`` saturates identically before
    narrowing.  This adapter widens the bf16 gemm output to fp32 for the
    clamp and activation, then rounds the product once to bf16; it does not
    clamp an unrounded GEMM accumulator."""
    if gate.shape != up.shape:
        raise GrammarError(f"gate {tuple(gate.shape)} and up {tuple(up.shape)} must match")
    limit = checked_swiglu_limit(clamp_limit)
    if limit is not None:
        gate = torch.clamp(gate.float(), max=limit)
        up = torch.clamp(up.float(), min=-limit, max=limit)
    act = torch.nn.functional.silu(gate.float()) * up.float()
    return act.to(torch.bfloat16)


class WindowUnitAxis:
    """One group's preallocated per-expert SoA, filled callback by callback.

    The first ``put`` for a projection allocates every stacked tensor ONCE
    from that unit's layout and fills slot 0; later experts verify the layout
    and fill their own slot; the temporary ``WindowGemvUnit`` is dropped as
    soon as its slot is written, so finalization copies nothing and the
    model's packed weights are never held twice (the intake's memory rule).
    Layouts that differ between experts are refused by name rather than
    silently re-strided.

    Three families.  ``value`` (BF16) and ``e4m3`` take a
    ``kernel_window_gemv.WindowGemvUnit``: one fp32 scale per row and the
    family's state table.  ``e2m1`` takes a ``compact_prep.WindowLutUnit``
    (the E2M1x2 window body over the LUT16 plane): its ``2^L`` table holds
    tuple CODE bytes, and its scale is the unit's group-16 nibble plane,
    16-entry UE4M3 table and fp32 global, per expert, in place of the row
    scale.  The body words are the same tile-word layout over tuples, so
    ``words``/``runs``/``perm``/``init`` mean what they mean for the other
    two families and the fused lane's column map reads them unchanged.
    """

    FAMILIES = ("value", "e4m3", "e2m1")

    def __init__(self, experts: int, parts: Sequence[str], *, family: str,
                 word_runs: "dict | None" = None):
        if family not in self.FAMILIES:
            raise GrammarError(f"window unit axis families are {self.FAMILIES}, got {family!r}")
        self.experts = int(experts)
        self.parts = tuple(str(p) for p in parts)
        self.family = family
        self._slots: dict = {}
        self._layout: dict = {}
        self._filled: dict = {}
        self._meta: dict = {}
        self._word_layout: dict = {}
        # Predeclared per-unit (word, run) sizes (#967), when the caller
        # derives them from the schema: they let a MIXED per-unit stack
        # allocate its exact flat storage once, at its first put, so no
        # per-unit weight outlives its callback and nothing is padded to a
        # common size or retained until finish.  A part whose sizes are all
        # equal takes the uniform path verbatim.
        self._sizes: dict = {}
        self._flat: dict = {}
        self._offsets: dict = {}
        for part, entries in (word_runs or {}).items():
            part = str(part)
            if part not in self.parts:
                raise GrammarError(f"word_runs names {part!r}; the axis holds {self.parts}")
            if len(entries) != self.experts:
                raise GrammarError(
                    f"{part!r}: word_runs carries {len(entries)} size(s) for "
                    f"{self.experts} experts")
            sizes = []
            for words, runs in entries:
                if int(words) <= 0 or int(runs) <= 0:
                    raise GrammarError(
                        f"{part!r}: predeclared word/run sizes must be positive, got "
                        f"({words}, {runs})")
                sizes.append((int(words), int(runs)))
            self._sizes[part] = sizes

    def _signature(self, part: str, unit) -> tuple:
        """What one grouped stack needs every expert of a part to share.

        Without predeclared sizes the per-unit extents (word count, run count,
        rate table, tile stride) are part of the shared layout, exactly as
        before #967.  With them, those extents are each expert's own data --
        checked against its declared size at ``put`` -- and the shared layout
        is everything the grouped stack indexes uniformly.
        """
        rep = unit.rep
        if self.family == "e2m1":
            state = (int(unit.codes.numel()), int(unit.scale_plane.numel()),
                     int(unit.arity), int(unit.half))
        else:
            state = (int(unit.table.numel()), int(unit.scale.numel()))
        shared = (self.family, int(unit.rows), int(unit.cols), int(unit.window_bits),
                  *state, int(rep.n_tiles), str(getattr(rep, "word_layout", "legacy")))
        if self._sizes.get(str(part)):
            return shared
        return shared + (int(rep.words.numel()), int(rep.runs.shape[0]),
                         tuple(int(r) for r in rep.rates), int(rep.tile_words))

    def _alloc(self, part: str, unit) -> dict:
        e = self.experts
        rep = unit.rep
        words = rep.words
        runs = rep.runs
        rows, cols, L = int(unit.rows), int(unit.cols), int(unit.window_bits)
        device = words.device
        e2m1 = self.family == "e2m1"
        sizes = self._sizes.get(part)
        if sizes and len(set(sizes)) != 1:
            # Exact flat storage for a mixed part (#967): one word stream and
            # one run table for the whole part, each expert's slice bounded by
            # the offsets ``finish`` publishes.  The buffers are the SUM of the
            # declared per-unit sizes -- nothing padded to a common shape, so
            # the resident bytes are the units' own priced words and runs,
            # unit for unit.
            word_off, run_off = [0], [0]
            for w, r in sizes:
                word_off.append(word_off[-1] + w)
                run_off.append(run_off[-1] + r)
            self._offsets[part] = (word_off, run_off)
            self._flat[part] = True
            slot = {
                "words": torch.empty(word_off[-1], dtype=torch.int32, device=device),
                "runs": torch.empty((run_off[-1], 4), dtype=torch.int32, device=device),
                "scale": (torch.zeros(0, dtype=torch.float32, device=device) if e2m1
                          else torch.empty((e, rows), dtype=torch.float32, device=device)),
                "perm": torch.empty((e, cols), dtype=torch.int32, device=device),
                "init": torch.empty((e, cols), dtype=torch.int32, device=device),
            }
        else:
            self._flat[part] = False
            slot = {
                "words": torch.empty((e, words.numel()), dtype=torch.int32, device=device),
                "runs": torch.empty((e, int(runs.shape[0]), 4), dtype=torch.int32, device=device),
                "scale": (torch.zeros(0, dtype=torch.float32, device=device) if e2m1
                          else torch.empty((e, rows), dtype=torch.float32, device=device)),
                "perm": torch.empty((e, cols), dtype=torch.int32, device=device),
                "init": torch.empty((e, cols), dtype=torch.int32, device=device),
            }
        empty_u8 = torch.zeros(0, dtype=torch.uint8, device=device)
        if self.family == "value":
            slot["table"] = torch.empty((e, unit.table.numel()), dtype=torch.bfloat16, device=device)
            slot["codes"] = empty_u8
            slot["native"] = empty_u8
        elif self.family == "e4m3":
            slot["table"] = torch.zeros(0, dtype=torch.bfloat16, device=device)
            slot["codes"] = torch.empty((e, unit.codes_of_state.numel()), dtype=torch.uint8,
                                        device=device)
            slot["native"] = torch.empty((e, unit.native.numel()), dtype=torch.uint8,
                                         device=device)
        else:
            slot["table"] = torch.zeros(0, dtype=torch.bfloat16, device=device)
            slot["codes"] = torch.empty((e, unit.codes.numel()), dtype=torch.uint8, device=device)
            slot["native"] = empty_u8
            slot["scale_plane"] = torch.empty((e, unit.scale_plane.numel()), dtype=torch.uint8,
                                              device=device)
            slot["scale_lut"] = torch.empty((e, 16), dtype=torch.uint8, device=device)
            slot["global_scale"] = torch.empty(e, dtype=torch.float32, device=device)
        slot["tile_words"] = torch.empty(e, dtype=torch.int32, device=device)
        slot["total_words"] = torch.empty(e, dtype=torch.int32, device=device)
        slot["has_init"] = torch.empty(e, dtype=torch.int32, device=device)
        self._slots[part] = slot
        self._layout[part] = self._signature(part, unit)
        self._filled[part] = set()
        self._meta[part] = (rows, cols, L)
        self._word_layout[part] = str(getattr(rep, "word_layout", "legacy"))
        return slot

    def put(self, part: str, expert: int, unit) -> None:
        """Place ``unit`` (a ``WindowGemvUnit``, or a ``WindowLutUnit`` on the
        ``e2m1`` family) in ``expert``'s slot of ``part``."""
        part = str(part)
        expert = int(expert)
        if not 0 <= expert < self.experts:
            raise GrammarError(f"expert {expert} outside the axis of {self.experts}")
        if part in self._slots and expert in self._filled[part]:
            raise GrammarError(f"expert {expert} of {part!r} already placed; a second put "
                               "would overwrite packed weights")
        lut_unit = hasattr(unit, "scale_plane")
        if lut_unit != (self.family == "e2m1"):
            raise GrammarError(
                f"{part!r} expert {expert}: the {self.family} axis takes "
                f"{'a LUT-plane window unit' if self.family == 'e2m1' else 'a window GEMV unit'}, "
                f"got {type(unit).__name__}")
        slot = self._slots.get(part) or self._alloc(part, unit)
        rep = unit.rep
        if self._signature(part, unit) != self._layout[part]:
            if self._sizes.get(part):
                raise GrammarError(
                    f"{part!r} expert {expert}: packed layout differs from the first expert's; "
                    "one grouped stack needs one layout per projection")
            raise GrammarError(
                f"{part!r} expert {expert}: the unit's packed layout (word count, run table, "
                "rates) differs from the first expert's, and this part carries no predeclared "
                "per-unit word/run sizes (word_runs) to allocate exact flat storage from. A "
                "mixed per-unit stack declares its sizes (moe_route._mixed_axis_word_runs); "
                "this axis refuses rather than pad to a common size or retain per-unit "
                "weights until finish.")
        sizes = self._sizes.get(part)
        if sizes:
            want = sizes[expert]
            got = (int(rep.words.numel()), int(rep.runs.shape[0]))
            if got != want:
                raise GrammarError(
                    f"{part!r} expert {expert}: the unit packs {got[0]} word(s) in {got[1]} "
                    f"run(s), its declared size is {want[0]} word(s) in {want[1]} run(s) -- "
                    "refusing rather than writing a unit off its predeclared place")
        if self._flat.get(part):
            word_off, run_off = self._offsets[part]
            w0, r0 = word_off[expert], run_off[expert]
            slot["words"][w0:w0 + int(rep.words.numel())] = rep.words.reshape(-1)
            slot["runs"][r0:r0 + int(rep.runs.shape[0])] = rep.runs
        else:
            slot["words"][expert] = rep.words
            slot["runs"][expert] = rep.runs
        if self.family == "e2m1":
            slot["scale_plane"][expert] = unit.scale_plane.reshape(-1)
            slot["scale_lut"][expert] = unit.scale_lut.reshape(-1).view(torch.uint8)
            slot["global_scale"][expert] = float(unit.global_scale)
        else:
            slot["scale"][expert] = unit.scale
        slot["perm"][expert] = rep.perm
        # Both kernels read the start state at the REPACKED column (the fused
        # lane's ``init[p]``, the grouped GEMM's ``init_all[e, kglob]``), as
        # ``prepare_window_gemm``'s ``init_perm`` holds it; the unit keeps it in
        # original order.  On a mixed-rate stack the repack permutes columns,
        # so storing the original order hands every TP row cut's first rows
        # another column's state (tessera#729).
        init = unit.permuted_start_state()
        if init is None:
            slot["init"][expert] = 0
            slot["has_init"][expert] = 0
        else:
            slot["init"][expert] = init.to(torch.int32)
            slot["has_init"][expert] = 1
        if self.family == "value":
            slot["table"][expert] = unit.table.to(torch.bfloat16)
        elif self.family == "e4m3":
            slot["codes"][expert] = unit.codes_of_state
            slot["native"][expert] = unit.native
        else:
            slot["codes"][expert] = unit.codes
        slot["tile_words"][expert] = int(rep.tile_words)
        slot["total_words"][expert] = int(rep.words.numel())
        self._filled[part].add(expert)

    def finish(self) -> dict:
        """The finished SoA per part; no copying, and incomplete slots refuse."""
        out = {}
        for part, slot in self._slots.items():
            missing = [e for e in range(self.experts) if e not in self._filled[part]]
            if missing:
                raise GrammarError(f"{part!r} is missing experts {missing} at finish")
            meta = {
                "rows": self._meta[part][0],
                "cols": self._meta[part][1],
                "window_bits": self._meta[part][2],
                "word_layout": self._word_layout.get(part, "legacy"),
            }
            if self._flat.get(part):
                # The mixed part's offsets are its own declared places: int32
                # word starts (the priced per-unit scalar) and the int64 run
                # bounds the grouped kernel reads per expert.
                word_off, run_off = self._offsets[part]
                out[part] = {
                    **slot, **meta,
                    "word_off": torch.tensor(word_off[:-1], dtype=torch.int32,
                                             device=slot["words"].device),
                    "run_off": torch.tensor(run_off, dtype=torch.int64,
                                            device=slot["runs"].device),
                }
                continue
            word_width = slot["words"].shape[1]
            out[part] = {
                **slot, **meta,
                "word_off": (torch.arange(self.experts, dtype=torch.int32, device=slot["words"].device)
                             * word_width),
                "run_off": torch.cat([
                    torch.zeros(1, dtype=torch.int32, device=slot["runs"].device),
                    torch.cumsum(torch.full((self.experts,), int(slot["runs"].shape[1]),
                                            dtype=torch.int32, device=slot["runs"].device), 0)]),
            }
        self._slots = {}
        self._filled = {}
        return out

    def filled(self) -> int:
        """How many (part, expert) slots have been placed."""
        return sum(len(s) for s in self._filled.values())

    def resident_bytes(self) -> int:
        """Bytes the allocated slots hold (packed constants only)."""
        return sum(t.numel() * t.element_size()
                   for slot in self._slots.values() for t in slot.values()
                   if isinstance(t, torch.Tensor))


@dataclasses.dataclass(frozen=True)
class PackedWindowMoeBundles:
    """A loader-filled grouped stack: gate/up/down SoA bundles plus the
    adapter they build.  ``resident_bytes`` counts the packed constants."""

    gate: PreparedGroupedWindowGemm
    up: PreparedGroupedWindowGemm
    down: PreparedGroupedWindowGemm
    family: str

    @property
    def experts(self) -> int:
        return self.down.experts

    @property
    def device(self) -> torch.device:
        return self.down.device

    @property
    def word_layout(self) -> str:
        """The resident word order every bundle shares (see WORD_LAYOUT_*).

        The three bundles must AGREE; a mixed stack refuses here rather than
        letting ``gate`` speak for ``up``/``down``.
        """
        tags = {role: str(getattr(getattr(self, role), "word_layout", "legacy"))
                for role in ("gate", "up", "down")}
        distinct = set(tags.values())
        if len(distinct) != 1:
            raise GrammarError(
                f"the gate/up/down bundles disagree on their resident word layout: {tags}")
        return distinct.pop()

    def resident_bytes(self) -> int:
        from .serving.residency import resident_storage_bytes

        return resident_storage_bytes(self.named_tensors())

    def named_tensors(self):
        """The exact retained grouped kernel tensors, for ownership observers.

        Includes the selected lane's composed lookup tables, run pairs,
        descriptors and counters once :meth:`adapter` has built it. Aliased
        table views are declared by reference; :meth:`resident_bytes` charges
        their backing allocation once.
        """
        for role in ("gate", "up", "down"):
            bundle = getattr(self, role)
            for field in dataclasses.fields(bundle):
                value = getattr(bundle, field.name)
                if isinstance(value, torch.Tensor):
                    yield f"{role}.{field.name}", value
        fused = self.__dict__.get("_fused_adapter")
        if fused is not None:
            yield from fused.named_tables()

    def native_owner(self):
        """The retained owner after selection; caller-held compact inputs stay intact.

        Construction/refusal is still owned by ``adapter``. A compact fallback
        returns this original owner, while a successful fused selection keeps
        its projection views plus the already-prepared native tables.
        """
        selected = self.adapter()
        fused = self.__dict__.get("_fused_adapter")
        if fused is None or selected is not fused:
            return self
        if self.gate is fused.gate and self.up is fused.up and self.down is fused.down:
            return self
        owner = dataclasses.replace(self, gate=fused.gate, up=fused.up, down=fused.down)
        object.__setattr__(owner, "_adapter", selected)
        object.__setattr__(owner, "_fused_adapter", fused)
        return owner

    def adapter(self):
        """The routed-expert compute over these bundles, built once.

        The fused warp-specialised lane (``tessera.routed_fused``, #640) where
        :func:`~tessera.routed_fused.fused_routed_window_supported` admits the
        stack and ``TESSERA_ROUTED_FUSED`` is not ``0``; the compact Triton
        adapter otherwise.  Each answers ``launch_pair`` with its own
        ``(symbol, decoder)`` so the route records what actually ran.  The
        refusal reason is logged at INFO so a serve's log says why a stack
        kept the compact adapter.
        """
        cached = self.__dict__.get("_adapter")
        if cached is not None:
            return cached
        from .routed_fused import FusedRoutedWindowMoE, fused_routed_window_supported

        reason = fused_routed_window_supported(self.gate, self.up, self.down)
        built = None
        if reason is None:
            try:
                built = FusedRoutedWindowMoE.from_bundles(
                    self.gate, self.up, self.down, activation="silu")
            except GrammarError:
                raise
            except Exception as exc:  # noqa: BLE001 -- the native build is what may fail here
                # The predicate admitted the stack, so what failed is the
                # extension build or load (toolchain, architecture, ninja).
                # ``native_extensions[].when_unavailable`` publishes the
                # compact adapter as the substitute in both residencies; this
                # is that substitution, and the reason goes where a serve's
                # log shows it.
                reason = f"native build unavailable ({type(exc).__name__}: {exc})"
                _log.warning("fused routed window lane unavailable for a %s stack of %d "
                             "experts; the compact adapter serves it: %s",
                             self.family, self.experts, reason)
            else:
                object.__setattr__(self, "_fused_adapter", built)
        if built is None:
            # The compact Triton adapter reads the legacy ``[column][chunk]``
            # order only.  A re-laid stack cannot be re-strided by a reader that
            # does not know the order, so an unavailable fused lane is a
            # refusal, not a substitution (tessera#793/#739).
            if self.word_layout != "legacy":
                raise GrammarError(
                    f"the {self.word_layout!r} resident word layout is served only by the fused "
                    f"routed window lane; it is unavailable ({reason}), and the compact adapter "
                    "reads the legacy order only. Refusing rather than mis-reading the stack.")
            _log.info("compact window MoE adapter kept for a %s stack of %d experts: %s",
                      self.family, self.experts, reason)
            built = native_window_moe_from_bundles(
                self.down, gate=self.gate, up=self.up, activation="silu")
        object.__setattr__(self, "_adapter", built)
        return built


def native_window_moe_from_bundles(
    down: PreparedGroupedWindowGemm,
    *,
    gate_up: "PreparedGroupedWindowGemm | None" = None,
    gate: "PreparedGroupedWindowGemm | None" = None,
    up: "PreparedGroupedWindowGemm | None" = None,
    activation: str = "silu",
) -> NativeWindowMoE:
    """The adapter from already-prepared grouped stacks (the loader path).

    ``gate_up`` is the fused ``[2I]`` stack; ``gate``/``up`` are the separate
    spelling.  Families, weight arithmetic and expert counts must agree.
    """
    if activation not in SUPPORTED_ACTIVATIONS:
        raise GrammarError(f"activation {activation!r} is not served")
    if gate_up is not None and (gate is not None or up is not None):
        raise GrammarError("the fused gate_up stack cannot be combined with gate/up stacks")
    if gate_up is None and (gate is None or up is None):
        raise GrammarError("the adapter needs either one fused gate/up stack or both gate and up")
    for name, bundle in (("gate_up", gate_up), ("gate", gate), ("up", up), ("down", down)):
        if bundle is None:
            continue
        if bundle.family != down.family:
            raise GrammarError(f"{name} family {bundle.family!r} differs from down's {down.family!r}")
        if bundle.arithmetic != down.arithmetic:
            raise GrammarError(f"{name} arithmetic {bundle.arithmetic!r} differs from down's")
        if bundle.experts != down.experts:
            raise GrammarError(f"{name} has {bundle.experts} experts, down has {down.experts}")
    if gate_up is not None and gate_up.rows != 2 * down.cols:
        raise GrammarError(
            f"the fused gate/up stack has {gate_up.rows} rows for {down.cols} intermediate columns")
    return NativeWindowMoE(gate_up=gate_up, gate=gate, up=up, down=down, activation=activation)


def prepare_native_window_moe(
    gate: Sequence[WindowGemvUnit],
    down: Sequence[WindowGemvUnit],
    *,
    up: "Sequence[WindowGemvUnit] | None" = None,
    initial_state: "torch.Tensor | None" = None,
    block_m: int = 64,
    block_n: int = 64,
    block_k: int = 64,
    quantizer: "str | None" = "native",
    arithmetic: str = "epilogue",
    activation: str = "silu",
) -> NativeWindowMoE:
    """Prepare both stages once.

    ``gate`` is the fused gate/up stack (``rows == 2 * down.cols``) unless
    ``up`` is given, in which case ``gate`` and ``up`` are separate stacks of
    ``down.cols`` rows each.  ``arithmetic`` is the grouped bundles' explicit
    weight-side contract (``"epilogue"`` default, ``"folded"`` for the
    BF16 expert contract); the down stack must agree with the gate/up
    stacks.  ``activation`` must be in :data:`SUPPORTED_ACTIVATIONS`.
    """
    if activation not in SUPPORTED_ACTIVATIONS:
        raise GrammarError(
            f"activation {activation!r} is not served; supported: {SUPPORTED_ACTIVATIONS}"
        )
    if up is None:
        gate_up = prepare_grouped_window_gemm(
            gate, initial_state=initial_state, block_m=block_m, block_n=block_n,
            block_k=block_k, quantizer=quantizer, arithmetic=arithmetic)
        gate_bundle = up_bundle = None
    else:
        gate_up = None
        gate_bundle = prepare_grouped_window_gemm(
            gate, initial_state=initial_state, block_m=block_m, block_n=block_n,
            block_k=block_k, quantizer=quantizer, arithmetic=arithmetic)
        up_bundle = prepare_grouped_window_gemm(
            up, initial_state=initial_state, block_m=block_m, block_n=block_n,
            block_k=block_k, quantizer=quantizer, arithmetic=arithmetic)
    down_bundle = prepare_grouped_window_gemm(
        down, initial_state=initial_state, block_m=block_m, block_n=block_n,
        block_k=block_k, quantizer=quantizer, arithmetic=arithmetic)
    first = gate_up or gate_bundle
    if first.family != down_bundle.family:
        raise GrammarError(
            f"gate/up family {first.family!r} and down family {down_bundle.family!r} "
            "must agree; a mixed-family MoE has no single arithmetic contract"
        )
    if first.arithmetic != down_bundle.arithmetic:
        raise GrammarError(
            "the gate/up and down stacks must share one weight arithmetic "
            f"({first.arithmetic!r} vs {down_bundle.arithmetic!r})"
        )
    if first.experts != down_bundle.experts:
        raise GrammarError(
            f"gate/up has {first.experts} experts, down has {down_bundle.experts}"
        )
    for bundle in (gate_bundle, up_bundle):
        if bundle is not None and bundle.experts != down_bundle.experts:
            raise GrammarError(
                f"a gate/up stack has {bundle.experts} experts, down has "
                f"{down_bundle.experts}"
            )
    return NativeWindowMoE(gate_up=gate_up, gate=gate_bundle, up=up_bundle,
                           down=down_bundle, activation=activation)
