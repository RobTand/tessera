"""The runtime contract this plugin packages, and what it is allowed to say.

Runtime attestation: a claim about what a serving runtime DOES is derived from a
machine-readable table the runtime publishes, never asserted in prose a gate
cannot read.  This package IS that runtime for Tessera bytes, so it publishes
its own ``runtime_contract.json`` and a producer (PrismaQuant) reads it through
``importlib.resources`` rather than hard-coding a route claim.

WHAT A CELL MEANS.  A ``lane_eligibility`` cell says: on this platform, for
this payload family, at these rungs, in this regime, at this residency, on
this exact runtime image and measured execution mode, the
plugin executes these LAUNCHES under this activation contract on a route with
this status.  A cell exists only where a container receipt covers it; absence
resolves ``unattested``, which is the honest status and not a refusal. The table
preserves the measured dense cells and adds routed-MoE E4M3/q1024 resident eager
on its own exact EUGR image. TP>1, expert parallelism and unmeasured runtime,
residency or rung combinations are not attested.

THE LAUNCH IS A VALUE, AND THE RESIDENCY IS A CONDITION (schema v4, #111).
``executes`` is a list of ``{symbol, decoder}`` and it is DERIVED here from
``scheme.ROUTE_LAUNCHES`` -- the table the routes' own ``census_expected`` is
built from -- narrowed by the cell's regime, by the residency its
``TESSERA_SERVE_MODE`` flag names, and by the lanes each of its rungs reaches
under ``native_extensions[].lane.requires``.  The REGIME there is this
module's (``CENSUS_PHASE_REGIMES`` below: ``decode`` is the one-row forward
and ``batch`` is every M > 1), never the kernel's word for M <= its GEMV max
-- reading the second into a cell is how the batch cell first published the
prefill launch alone and left out the GEMV the same regime runs at two rows.  Before v4 the launch appeared
only in the cell's ``id``, so an E4M3 decode published the materialised FP8
pair in every case; that was accidentally true while the window-GEMV lane was
unreachable and false the moment a rate-constrained artifact was served, with
the lane's own op on 112 of 112 modules.  The residency carries the condition
because both window routes set ``layer.tessera_gemv = None`` in ``resident``
-- the lane exists in ``streamed`` alone -- so two cells of one ``(platform,
family, structure, regime, runtime image, execution mode)`` must cover DISJOINT
residencies. A cell ``id`` names its scope and never a launch; v5 permits a
runtime-derived suffix for disjoint variants while retaining existing IDs.

WHAT THE BYTES WERE.  A cell says a receipt covered a rung; it cannot say
*which bytes* at that rung, and two encoders can write two byte strings at
one rung -- the window table the decoder reads lives on the ALPHABET plane,
so anything that moves the table moves the bytes while the rung, the route
and the decoder stand still.  Beside ``attested_rungs_q256``, then, each
``formats[]`` row carries ``attested_wire``: one ``wire.recipes`` entry per
attested rung -- the checkpoint's own vocabulary, in the spelling a
checkpoint's config already records per rung -- saying which bytes the
receipt was cut on.  A producer preflight compares its checkpoint's entry at
that rung against the stamp and tells "attested on these bytes" from
"attested on this rung".  Coverage (one entry per attested rung, no other)
and the body/span/plane (the route's own ``scheme.ROUTES`` row) are refused
here; that the stamp is still what the exporter writes is pinned in
``tests/test_serving_attested_wire.py``, so a bytes-moving encode change
trips there instead of letting the attestation silently describe bytes no
fresh export writes.

TWO CLAIMS ABOUT TENSOR PARALLELISM, AND THEY ARE NOT THE SAME.
``tensor_parallel.units[].max_world_size`` is an ATTESTATION: the largest world
size a served receipt covers.  A unit at 1 names nothing; a unit above 1 names
its ``world_size_receipt``, an entry of ``tensor_parallel.world_size_receipts``
that carries the two-rank serve record, one route trace per rank, the unit
among the families those traces executed, and the KL against a single-rank arm
-- and a unit above 1 without one is refused by name
(``_validate_tensor_parallel``).  Since v29 the three families are at 2 on the
GLM-5.3-Flash stub serves (tessera#506, tessera#514), graded ``route_only``.
Read the receipt's ``excess_over_control`` as a DIVERGENCE, not as added error:
on a quantized checkpoint a TP2-vs-TP1 comparison re-draws quantization noise
that the reference KL does not see move (tessera#514's resolution,
``experiments/results/glm53_a4_stub_tp2_reference_kl_514.json``).
Beside it, ``loader_axes`` says what this build's
LOADER does with a shard on each axis, which is a different question with a
different answer -- the E4M3 family cuts both axes, the E2M1x2 family cuts
columns only.  ``_validate_loader_axes`` checks that block against
``sharding.ROUTE_TP_AXES``, the dict the routes themselves gate on, so the
published table and the executed behaviour are one artifact rather than two
documents that can disagree about one runtime.

WHAT ``requires_plugin`` MEANS.  Every Tessera route is reachable only in a
process where this plugin is installed and registered (entry point
``vllm.general_plugins``).  Stock vLLM has no reader for these bytes, so the
route is not merely flag-gated: it is plugin-gated.  That is a machine-readable
cell field, not prose, because a producer's export gate has to be able to
refuse an artifact whose serve command would not install the plugin.

WHAT IT EXECUTES AND WHAT IT LOADS ARE TWO CLAIMS.  ``formats`` and
``lane_eligibility`` say what a serve runs; ``native_extensions`` says which
libraries it can map into the serving process, and it is here because a
consumer needs the second one: PrismaQuant's serve fingerprint holds two KLs
comparable only across serves whose native-extension residency matches, so a
lane whose ``.so`` it cannot name reads as a stock serve.  With no table to
read it mirrored the basename in its own repository, which is this principle
failing one repository over.  The block is published as a prefix and a glob
rather than a basename because ``ext`` JIT-builds the module under a
build-identity hash, and it answers "what ran instead" per RESIDENCY rather
than with an ``optional`` flag -- see ``_validate_native_extensions``.

READING IT.  ``load_serving_contract()`` returns the parsed JSON;
``contract_path()`` the packaged file, for a consumer that wants to hash or
copy it verbatim.  Neither imports torch or vLLM: a producer reads this table
on a machine with no GPU.
"""
from __future__ import annotations

import hashlib
import json
import re
from functools import lru_cache
from types import MappingProxyType
from typing import Any, Mapping

from .activation_attestation import validate_activation_quantizers

__all__ = [
    "CENSUS_PHASE_REGIMES",
    "CELL_PREDICATE_FACTS",
    "CELL_PREDICATE_OPS",
    "EVIDENCE_CONTROL_OUTCOMES",
    "EVIDENCE_CONTROL_REFERENCES",
    "EVIDENCE_GRADES",
    "EVIDENCE_KL_KINDS",
    "EVIDENCE_RECEIPT_ROOT",
    "EVIDENCE_SMOKE_ATTRIBUTIONS",
    "EVIDENCE_SMOKE_FORMS",
    "EVIDENCE_SMOKE_INTERFACES",
    "EVIDENCE_SMOKE_RECORD_KEYS",
    "EVIDENCE_SMOKE_ROW_KEYS",
    "EVIDENCE_SMOKE_STATUSES",
    "EXECUTION_MODES",
    "PLUGIN_ENTRY_POINT",
    "RUNTIME_CODE_KEYS",
    "RUNTIME_SCOPE_KEYS",
    "RUNTIME_VERSION_KEYS",
    "VERSIONS_KEYS",
    "validate_activation_quantizers",
    "cell_evidence",
    "cell_runtime_code",
    "cell_runtime_versions",
    "derive_evidence_grade",
    "derive_smoke_attribution",
    "derive_smoke_status",
    "smoke_status_is_derived",
    "CONSTRUCTION_SCHEMA",
    "CONSTRUCTION_CENSUS_SCHEMA",
    "classify_construction",
    "construction_entry",
    "construction_entry_from_receipt",
    "output_partitions",
    "normalise_module",
    "vllm_module_name",
    "CONTRACT_FILENAME",
    "CONTRACT_SCHEMA",
    "PAYLOAD_FAMILY_BY_ROUTE",
    "LANE_ELIGIBILITY_SCHEMA",
    "EVIDENCE_PAYLOAD_RELATIONS",
    "EVIDENCE_WEIGHT_ERROR_RELATIONS",
    "FORMAT_KIND",
    "REQUIRES_PLUGIN",
    "contract_path",
    "cell_executes",
    "derive_cell_executes",
    "cell_predicates",
    "refuse_unevaluated_predicates",
    "cell_residency_modes",
    "cell_runtime_scope",
    "cell_runtime_id_suffix",
    "require_runtime_image",
    "extension_lane",
    "lane_decoder",
    "lane_requirements",
    "load_serving_contract",
    "stock_kernel_override_refusal",
    "route_wire_spelling",
    "validate_serving_contract",
    "ALLOWABLE_RULES",
    "cell_covers_rung",
    "derived_cell_run_tables",
    "format_entry",
    "rung_allowable",
    "rung_rates",
    "PRODUCER_INTERFACE_SCHEMA",
    "validate_producer_interface",
]

CONTRACT_FILENAME = "runtime_contract.json"
CONTRACT_SCHEMA = "tessera.runtime-contract.v1"
LANE_ELIGIBILITY_SCHEMA = "tessera.lane-eligibility.v11"
#: Execution is a separate axis from token-count regime and residency. These
#: are the two modes selected by a serving invocation's enforce_eager flag.
EXECUTION_MODES = ("eager", "compiled")
#: The ``formats[]`` discriminator for a family addressed by a RATE (body bits
#: per 256 weights), not by a codebook size.  Every Tessera family is one.
FORMAT_KIND = "tessera_wire"
#: The value every Tessera cell publishes in ``requires_plugin``.
REQUIRES_PLUGIN = "tessera"

#: The serve-side observation's phase names, and the ``lane_eligibility``
#: regime each phase exercises.  ONE table, read by both sides.
#:
#: ``tools/tessera_route_census.py`` stands up two forwards and calls them by
#: the shape it drove -- a many-row ``prefill`` and a one-row ``decode`` -- and
#: it keys its receipt (``histogram``, ``records``) by those names, which
#: several served receipts already quote.  This contract calls the same two
#: things ``decode`` and ``batch``, because a regime is a *problem shape* and
#: the batch cell covers every M > 1 forward, not only a first prefill.  Both
#: vocabularies are load-bearing, so the pair is mapped here rather than
#: written twice: the census reads this to stamp the contract's word beside its
#: own phase, and :func:`validate_serving_contract` refuses a contract whose
#: declared regimes are not exactly this table's values -- so a third regime,
#: or a rename on either side, fails at contract load instead of at a
#: per-module ``KeyError`` after two full model loads.
CENSUS_PHASE_REGIMES: Mapping[str, str] = MappingProxyType(
    {"prefill": "batch", "decode": "decode"})

#: The ``route_status`` values a cell may carry when a DEVICE ran the route.
#: ``unbacked`` is this document's word for "no serve exists here", so it is
#: deliberately not one of them: v10 (#456) lets a ``compile_only`` cell carry
#: it and refuses it beside either of these.
BACKED_ROUTE_STATUSES = frozenset({"backed", "backed_with_serve_flag"})
_ROUTE_STATUSES = BACKED_ROUTE_STATUSES | {"unbacked"}
#: The qualification a cell carries when a DEVICE ran the route, as against
#: ``compile_only``, which says a toolchain accepted the code.
DEVICE_QUALIFICATION = "device_qualified"
_QUALIFICATIONS = frozenset({DEVICE_QUALIFICATION, "compile_only"})

#: The closed grammar of a cell's ``predicates`` (#134).  A predicate narrows
#: the cell to units for which ``fact op value`` holds, and it is a
#: ``{fact, op, value}`` object over the STRUCTURAL facts a producer's unit
#: carries before it is encoded -- never a wire predicate (that is
#: ``native_extensions[].lane.requires``, decidable from a plan, and a
#: different table).  The set is closed on both axes because a consumer that
#: could not resolve a predicate must refuse the cell, not skip the rule: an
#: unknown predicate that no-ops would let a narrower cell read as
#: unconditionally eligible.  The vocabulary is the one
#: ``docs/measurements/tessera-lane-eligibility-executes-2026-09-04.md``
#: records and PrismaQuant's ``lane_eligibility._PREDICABLE_FACTS`` /
#: ``_PREDICATE_OPS`` resolve; it is owned here so the publisher refuses what
#: the reader could not read.  Every cell published today carries ``[]``.
CELL_PREDICATE_FACTS = ("payload_family", "k", "n_sub", "rate_q256", "role_split",
                        "in_features", "out_features")
CELL_PREDICATE_OPS = ("equals", "in", "multiple_of", "at_least", "at_most")

#: A cell's ``runtime`` (schema v6, #131).  The SCOPE half -- the exact image
#: and the execution modes a receipt covers -- arrived with v5 and is the
#: census's join key.  The TOOLCHAIN half is the vLLM and torch build the
#: cell's own receipt records, verbatim; until v6 the only versions in the
#: document were a global ``versions.attested_on`` block, which named vLLM
#: 0.28.0 for two cells measured on ``0.28.1rc1.dev397``.  One home for both
#: key sets: :func:`cell_runtime_scope` reads the first and tolerates the
#: second (an observation-side fixture carries only a scope);
#: :func:`cell_runtime_versions` requires the whole closed object.
RUNTIME_SCOPE_KEYS = frozenset({"image", "execution_modes"})
RUNTIME_VERSION_KEYS = frozenset({"vllm", "torch"})

#: The CODE half of a cell's ``runtime`` (contract v41, optional): which
#: Tessera tree the cell's evidence was taken on.  ``tessera_commit`` is the
#: 40-hex commit, for a person to find the tree.  ``serving_source_sha256`` is
#: :func:`tessera.serving.source_identity.serving_source_sha256` of that tree
#: (every source file in the package), for a program to compare against the code a serve actually runs, because an
#: editable install records no commit.  A cell stamps both or neither, and only
#: when its evidence is taken: a digest is never re-stamped onto old evidence,
#: so a stale digest is an honest scope, not a defect.  No cell carries them in
#: v41; the first census that records them stamps them.
RUNTIME_CODE_KEYS = frozenset({"tessera_commit", "serving_source_sha256"})
_COMMIT = re.compile(r"[0-9a-f]{40}")
_SHA256 = re.compile(r"[0-9a-f]{64}")

#: ``versions`` (schema v6, #131) says one thing per field and nothing about
#: a measured runtime: ``tessera`` is the distribution version,
#: ``plugin_entry_point`` the entry point the wheel declares, and
#: ``default_serve_image`` the ONE serve-image pin every harness reads
#: (``runtime_image.PIN_CONTRACT_FIELD``) -- which must be an image some cell
#: attests, because a default nobody measured is not a pin.
VERSIONS_KEYS = frozenset({"tessera", "plugin_entry_point", "default_serve_image"})
PLUGIN_ENTRY_POINT = "tessera = tessera.serving:register"

#: A cell's ``evidence`` (schema v6, #133): what GRADE of evidence the cell
#: rests on, in a field a gate can read.  Every served KL this repository
#: holds -- dense and MoE -- is a ``kl_tool`` top-K teacher/student-
#: intersection LOWER BOUND; what separates the cells is which regime it was
#: scored in, under which execution modes, and whether a greedy smoke is on
#: record.  So a ``kl`` entry is ``{kind, top_k, regime, execution_modes,
#: receipt}`` (no number: the receipt holds it with its bounds), ``smoke`` is
#: ``{status, receipt, attribution, control}`` in the receipt's own words
#: (``attribution`` and ``control`` are schema v7's, below), and ``grade`` is DERIVED
#: from the entries in the cell's own regime the way ``executes`` is derived
#: from the route table -- stored so a reader needs no derivation, checked so
#: it cannot drift.  ``receipt`` is a repository path under
#: :data:`EVIDENCE_RECEIPT_ROOT`; the validator checks its grammar and a tree
#: test checks the file (a wheel does not ship docs).
EVIDENCE_KL_KINDS = ("topk_intersection_lower_bound", "full_vocab")
EVIDENCE_SMOKE_STATUSES = ("recorded", "repetitive", "not_recorded")
EVIDENCE_GRADES = ("route_only", "kl_lower_bound", "kl_full_vocab")
EVIDENCE_RECEIPT_ROOT = "docs/measurements/"

#: Schema v8 (#198) scopes historical evidence to the encoder that wrote it.
#: These comparisons describe one named unit in weight space, never served KL.
EVIDENCE_PAYLOAD_RELATIONS = ("identical", "different")
EVIDENCE_WEIGHT_ERROR_RELATIONS = ("lower", "equal", "higher")

#: A smoke's CONTROL (schema v7, #195): the reference the same prompt was run
#: against, so a consumer can tell "this route degenerates" from "this prompt
#: degenerates on this model".  ``status`` says what came back and is accurate;
#: it is not the field that decides admission, because a degenerate completion
#: the unquantised source produces character for character is a property of the
#: model and the prompt.  That distinction was measured
#: (``docs/measurements/moe-evidence-debt-2026-09-04.md`` section 7) and lived
#: in prose while a producer-side gate refused the whole routed-MoE lane on
#: ``status``: the machine-readable field was true about the observation and
#: misleading about its meaning, which is principle 14 one level up.
#:
#: ``control`` is ``{reference, outcome, receipt}`` or ``null``, and
#: ``attribution`` is DERIVED from it and checked, the way ``grade`` is derived
#: from ``kl``.  What ``outcome`` establishes, exactly: ``identical_completion``
#: means the reference returned the SAME completion for the same prompt under
#: the smoke's own runtime and execution mode; ``different_completion`` means
#: the completions differ -- NOT that the reference was healthy, which no string
#: comparison can decide.  There is no ``scope`` field: a smoke record carries no
#: scope of its own, a control cannot be better scoped than the thing it
#: controls, and that the arms match is what the receipt attests, exactly as for
#: every other receipt-backed field here.  One control, not a list: one is what
#: has been run, and a second reference is a bump rather than a surprise.
EVIDENCE_CONTROL_REFERENCES = ("bf16_source",)
EVIDENCE_CONTROL_OUTCOMES = ("identical_completion", "different_completion")
EVIDENCE_SMOKE_ATTRIBUTIONS = ("unattributed", "shared_with_reference",
                               "not_shared_with_reference")
EVIDENCE_CONTROL_KEYS = frozenset({"reference", "outcome", "receipt"})

#: A smoke's RECORD (schema v9, #327): the machine-readable scoring that
#: ``status`` and ``attribution`` are DERIVED from, the way ``grade`` is derived
#: from ``kl``.  Until v9 the step from a set of completions to the cell's one
#: published word was undeclared, underived and untested: the per-completion
#: rule was stated and pinned, but the AGGREGATION -- which set of completions
#: makes a cell read ``recorded`` -- was stated once, in a dated measurement
#: file, in the existential form "at least one prompt reads ``recorded`` on both
#: arms", with nothing in the repository saying why "some" rather than "all",
#: nothing deriving it, and nothing that would notice if the smoke were re-run
#: with a different result.  A rule that decides a field a serving gate reads
#: does not live in append-only history (AGENTS.md rules 2, 4 and 10).
#:
#: THE AGGREGATION, in one place, and it is :func:`derive_smoke_status`:
#:
#: * ``repetitive`` when some row cycles on this cell's arm and the reference
#:   does not.  A degeneration the reference does not share is the route's, and
#:   that is the whole content of the word.
#: * else ``recorded`` when some row reads ``recorded`` on this arm AND on the
#:   reference (or on this arm alone when no reference was run): a positive
#:   record, which is what principle 5's "generates correctly" leg asks for.
#: * else ``repetitive`` when any row cycles at all -- every cycle is shared
#:   with the reference, but nothing positive was recorded, so there is no
#:   record to publish.
#: * else ``not_recorded``: nothing came back.
#:
#: The threshold is not "some prompt" and not "all prompts"; it is derived from
#: what the word is a claim ABOUT.  ``status`` is a claim about this route, so
#: an observation the unquantised reference reproduces is not this route's --
#: which is the same principle schema v7's ``control`` was added for, applied
#: per (prompt, form) instead of once per cell.  What that leaves behind is
#: carried by ``attribution``, still derived and still checked, now off the
#: record: a residual cycle every reference row shares reads
#: ``shared_with_reference``, so a consumer at the pin can tell a cell whose
#: smoke cycled on an interface from one whose smoke never cycled at all.
#:
#: A row is one (prompt, form) pair: ``{prompt, form, interface, status,
#: reference_status}``, each verdict from :data:`EVIDENCE_SMOKE_STATUSES` under
#: the instrument's per-completion rule, which the record quotes verbatim.
#: ``interface`` is the model interface the prompt exercised, and it is the axis
#: the 2026-09-05 routed-MoE measurement actually turns on: through the
#: checkpoint's own chat template both arms answer, under raw continuation both
#: arms -- student and BF16 source alike -- end in a cycle.  No number lives in
#: a cell here either: the token count, the period and the periodic suffix are
#: the receipt's, and the record carries the verdicts read off them.
#:
#: AN ASSERTED STATUS.  ``record`` is nullable, and a cell whose record is
#: ``null`` publishes an **asserted status** -- a word a person read off a
#: receipt, which no validator can check and which :func:`smoke_status_is_derived`
#: reports ``False`` for.  Two dense BF16 cells are in that state today: their
#: receipt (``tessera-bf16-route-served-2026-09-02.md`` :83) predates this
#: instrument and records one greedy continuation from four census arms of the
#: same route -- one prompt, no per-completion scoring and no reference arm --
#: so there is no per-(prompt, form) table to transcribe and nothing here
#: invents one.  What would give them a derived status is a measurement, not an
#: edit: ``experiments/moe_greedy_smoke.py`` run against a serve of that
#: artifact with its own tokenizer, and a BF16 reference arm beside it.  The six
#: ``not_recorded`` cells never ran a smoke and have nothing to record.
EVIDENCE_SMOKE_INTERFACES = ("raw_completion", "chat_template")
EVIDENCE_SMOKE_FORMS = ("campaign", "pure_greedy")
EVIDENCE_SMOKE_RECORD_KEYS = frozenset({"instrument", "rule", "reference", "rows"})
EVIDENCE_SMOKE_ROW_KEYS = frozenset(
    {"prompt", "form", "interface", "status", "reference_status"})


#: The backends a platform entry may declare.  ``cuda`` and ``hip`` are the
#: two torch builds this plugin has been read on; the device TYPE cannot tell
#: them apart, because ROCm's torch reports ``"cuda"`` for an AMD device.
PLATFORM_BACKENDS = frozenset({"cuda", "hip"})

#: The key that names the hardware, one per backend.  Exactly one is present:
#: a CUDA platform is a compute capability and a HIP platform is a gcnArchName,
#: and an entry carrying both would be two devices under one key.
PLATFORM_ARCH_KEYS = {"cuda": "compute_capability", "hip": "gcn_arch"}

#: Keys a platform entry may carry beyond the required ones.  They describe
#: the machine rather than what it executes, and nothing in this module reads
#: them; the launch planner does (#454).
_PLATFORM_OPTIONAL_KEYS = frozenset({"wavefront", "lds_bytes"})


def _validate_platform_entries(block: Mapping[str, Any],
                               contracts_by_family: Mapping[str, str]) -> None:
    """Every ``lane_eligibility.platforms`` entry, as v10 requires it.

    ``serve_image`` is checked against the cells in the second pass below --
    it is a statement about receipts and cannot be judged before they are
    read.
    """
    platforms = block["platforms"]
    if not isinstance(platforms, Mapping) or not platforms:
        raise ValueError(
            "runtime_contract.lane_eligibility.platforms must be a non-empty object "
            f"keyed by platform, got {platforms!r}")
    for key, entry in platforms.items():
        where = f"runtime_contract.lane_eligibility.platforms[{key!r}]"
        if not isinstance(entry, Mapping):
            raise ValueError(
                f"{where} must be a JSON object. Before schema v10 a platform was a bare "
                "KEY, and a reader that goes on treating it as one cannot see that a "
                "family is published unbacked here -- which is the whole point of the "
                "axis, and why v10 is not additive.")
        backend = entry.get("backend")
        if backend not in PLATFORM_BACKENDS:
            raise ValueError(
                f"{where}.backend must be one of {sorted(PLATFORM_BACKENDS)}, got "
                f"{backend!r}. The device type cannot answer this: a ROCm torch reports "
                'device.type "cuda" for an AMD device.')
        arch_key = PLATFORM_ARCH_KEYS[backend]
        other = {v for v in PLATFORM_ARCH_KEYS.values()} - {arch_key}
        if arch_key not in entry:
            raise ValueError(f"{where} declares backend {backend!r} and must carry {arch_key!r}")
        present = sorted(other & set(entry))
        if present:
            raise ValueError(
                f"{where} declares backend {backend!r} and also carries {present}; a "
                "platform key names one device, and two architecture spellings under one "
                "key is two devices sharing an identity")
        _require_keys(entry, where,
                      required={"backend", arch_key, "serve_image", "executes"},
                      optional=_PLATFORM_OPTIONAL_KEYS)
        if backend == "cuda":
            capability = entry[arch_key]
            if (not isinstance(capability, list) or len(capability) != 2
                    or any(not isinstance(v, int) for v in capability)):
                raise ValueError(f"{where}.compute_capability must be [major, minor], "
                                 f"got {capability!r}")
        else:
            arch = entry[arch_key]
            if not isinstance(arch, str) or not arch or ":" in arch:
                raise ValueError(
                    f"{where}.gcn_arch must be a bare architecture name, got {arch!r}. "
                    "The feature suffixes torch reports (gfx1201:xnack-) are a build "
                    "target's decoration, not a second platform.")
        for optional in sorted(_PLATFORM_OPTIONAL_KEYS & set(entry)):
            value = entry[optional]
            if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
                raise ValueError(f"{where}.{optional} must be a positive integer, got {value!r}")
        executes = entry["executes"]
        if not isinstance(executes, Mapping) or set(executes) != set(contracts_by_family):
            raise ValueError(
                f"{where}.executes must name every family in formats[] "
                f"({sorted(contracts_by_family)}), got "
                f"{sorted(executes) if isinstance(executes, Mapping) else executes!r}. A family "
                "left out is not 'unbacked' -- it is a question this document declined to "
                "answer about a platform it declares, and a consumer cannot tell the two "
                "apart. null is the way to say unbacked.")
        for family, value in executes.items():
            if value is None:
                continue
            expected = contracts_by_family[family]
            if value != expected:
                raise ValueError(
                    f"{where}.executes[{family!r}] is {value!r}, but the route this family "
                    f"is served by executes {expected!r} (scheme.ROUTES). A platform entry "
                    "does not get to name a contract the dispatch does not run: the value "
                    "is DERIVED from the route or it is a claim about a runtime nobody "
                    "read. Publish null to say the route is unbacked here.")


def contract_path():
    """The packaged contract file as a ``Traversable``.

    ``importlib.resources`` so a wheel install, an editable install and an
    in-repo checkout all resolve identically; never repo-root arithmetic.
    """
    from importlib import resources

    return resources.files(__package__).joinpath(CONTRACT_FILENAME)


def load_serving_contract() -> dict[str, Any]:
    """The packaged contract, parsed and validated."""
    raw = contract_path().read_text(encoding="utf-8")
    contract = json.loads(raw)
    validate_serving_contract(contract)
    return contract


@lru_cache(maxsize=1)
def cached_serving_contract() -> Mapping[str, Any]:
    """:func:`load_serving_contract`, parsed and validated ONCE per process.

    The packaged document is a build artifact: within one process it cannot
    change, and re-validating two thousand lines of it per Linear is a cost
    with no reading behind it.  Callers on a model-load path (``native_ops``
    asks this per quantized Linear) take this one; anything that may be handed
    a DIFFERENT document keeps taking ``load_serving_contract`` or its own
    parse.  Returned read-only so a caller cannot edit the copy every other
    caller will be handed.
    """
    return MappingProxyType(load_serving_contract())


def _require_keys(payload: Mapping[str, Any], where: str, required: set[str],
                  optional: set[str] = frozenset()) -> None:
    if not isinstance(payload, Mapping):
        raise ValueError(f"{where} must be a JSON object")
    missing = sorted(required - set(payload))
    if missing:
        raise ValueError(f"{where} is missing {missing}")
    unknown = sorted(set(payload) - required - set(optional))
    if unknown:
        raise ValueError(f"{where} carries unknown field(s) {unknown}")


def require_runtime_image(value: Any, where: str = "runtime.image") -> str:
    """An exact manifest reference, using the serving image parser's grammar."""
    from .runtime_image import parse_reference

    if isinstance(value, str):
        repository, tag, digest = parse_reference(value)
        if digest is not None and tag is None and value == f"{repository}@{digest}":
            return value
    raise ValueError(
        f"{where} must be an exact digest reference (repository@sha256:<64 lowercase hex>), "
        f"got {value!r}; a floating tag or local image id does not identify an attested runtime")


def cell_runtime_scope(cell: Mapping[str, Any],
                       where: str = "lane_eligibility cell") -> tuple[str, tuple[str, ...]]:
    """The explicit runtime scope a cell attests; no global image fallback."""
    runtime = cell.get("runtime")
    at = f"{where}.runtime"
    _require_keys(runtime, at, required=set(RUNTIME_SCOPE_KEYS),
                  optional=RUNTIME_VERSION_KEYS | RUNTIME_CODE_KEYS)
    image = require_runtime_image(runtime["image"], f"{at}.image")
    modes = runtime["execution_modes"]
    if (not isinstance(modes, list) or not modes
            or any(not isinstance(mode, str) or mode not in EXECUTION_MODES for mode in modes)
            or len(set(modes)) != len(modes)):
        raise ValueError(
            f"{at}.execution_modes must be a non-empty list of distinct modes from "
            f"{list(EXECUTION_MODES)}, got {modes!r}")
    return image, tuple(mode for mode in EXECUTION_MODES if mode in modes)


def cell_runtime_versions(cell: Mapping[str, Any],
                          where: str = "lane_eligibility cell") -> tuple[str, str]:
    """The ``(vllm, torch)`` a cell's own receipt records, or raise (#131).

    Requires the WHOLE closed ``runtime`` object -- scope and toolchain -- so
    the validator, which calls this, refuses a cell that still relies on a
    global version block; :func:`cell_runtime_scope` is the lenient reader
    for the census join.
    """
    runtime = cell.get("runtime")
    at = f"{where}.runtime"
    _require_keys(runtime, at, required=set(RUNTIME_SCOPE_KEYS | RUNTIME_VERSION_KEYS),
                  optional=RUNTIME_CODE_KEYS)
    out = []
    for field in ("vllm", "torch"):
        value = runtime[field]
        if not isinstance(value, str) or not value:
            raise ValueError(
                f"{at}.{field} must be a non-empty string: the build the cell's receipt "
                f"records, verbatim. Got {value!r}.")
        out.append(value)
    return out[0], out[1]


def cell_runtime_code(cell: Mapping[str, Any],
                      where: str = "lane_eligibility cell") -> tuple[str, str] | None:
    """The ``(tessera_commit, serving_source_sha256)`` a cell names, or ``None``.

    Both or neither: a commit with no digest gives a reader nothing to compare,
    and a digest with no commit gives a person no tree to find.
    """
    runtime = cell.get("runtime")
    at = f"{where}.runtime"
    present = sorted(RUNTIME_CODE_KEYS & set(runtime or ()))
    if not present:
        return None
    if len(present) != len(RUNTIME_CODE_KEYS):
        raise ValueError(
            f"{at} names {present} without {sorted(RUNTIME_CODE_KEYS - set(present))}; "
            "a cell names the Tessera code it was measured on with both fields or neither")
    commit, digest = runtime["tessera_commit"], runtime["serving_source_sha256"]
    if not isinstance(commit, str) or not _COMMIT.fullmatch(commit):
        raise ValueError(f"{at}.tessera_commit must be a 40-hex lowercase commit, got {commit!r}")
    if not isinstance(digest, str) or not _SHA256.fullmatch(digest):
        raise ValueError(
            f"{at}.serving_source_sha256 must be 64 lowercase hex digits, got {digest!r}")
    return commit, digest


def cell_runtime_id_suffix(cell: Mapping[str, Any]) -> str:
    """An optional scope-derived suffix when multiple runtimes need distinct ids.

    Derived from the SCOPE alone: a toolchain is a property of the image, so
    it must not fork the id (two ids for one scope would be the table-order
    defect the suffix exists to close).
    """
    image, modes = cell_runtime_scope(cell)
    encoded = json.dumps({"image": image, "execution_modes": list(modes)},
                         sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "_runtime_" + hashlib.sha256(encoded).hexdigest()


#: Where a world-size receipt's committed data lives: route traces and the
#: single-rank KL table.  A repository path, never a box path, for the reason
#: ``EVIDENCE_RECEIPT_ROOT`` is one (tests/test_contract_is_portable.py).
WORLD_SIZE_DATA_ROOT = "experiments/results/"

#: The one grade a world-size receipt carries.  Its KL compares a checkpoint
#: with ITSELF at another world size, never with its reference, so it attests
#: that the routes execute there and publishes the divergence it measured; a
#: quality grade is a ``lane_eligibility`` cell's evidence, not this block's.
WORLD_SIZE_RECEIPT_GRADE = "route_only"

#: The arms a single-rank KL is read from (tessera#514): the Tessera checkpoint
#: at the raised world against one rank, the same model with no Tessera module
#: at the same two worlds (vLLM's own tensor-parallel numerics), and two
#: single-rank serves of the Tessera checkpoint (the serve-to-serve floor).
SINGLE_RANK_KL_ARMS = ("quantized", "control", "floor")

#: The metrics each arm publishes.  Shared-id |d logprob| and the renormalized
#: shared-support KL are the columns to read on a near-flat model; the lumped
#: top-K lower bound is published beside its coverage so a reader can see why.
SINGLE_RANK_KL_METRICS = (
    "abs_dlogprob_p50", "abs_dlogprob_p99", "abs_dlogprob_max",
    "renormalized_kl_mean", "renormalized_kl_p99", "renormalized_kl_max",
    "top1_agree_pct", "top8_exact_pct",
    "topk_kl_lower_bound_mean", "topk_coverage_mean")

#: The metric families a receipt may tell a reader to read.
SINGLE_RANK_KL_READINGS = ("abs_dlogprob", "renormalized_kl", "topk_kl_lower_bound")

#: The quantized arm's excess over the control, as ratios the validator
#: DERIVES from the two arms' metrics at two decimals.  A typed ratio that
#: disagrees with the numbers beside it is refused.  It is a divergence
#: between two worlds of one checkpoint: on the A4 stub the 4.26x median
#: excess is quantization noise re-drawn by the TP2 partial-sum rounding, and
#: the checkpoint's KL against its BF16 reference is the same at both worlds
#: (tessera#514, experiments/results/glm53_a4_stub_tp2_reference_kl_514.json).
SINGLE_RANK_KL_EXCESS = ("abs_dlogprob_p50", "abs_dlogprob_p99")


def _require_data_path(value: Any, where: str) -> str:
    """A repository path under :data:`WORLD_SIZE_DATA_ROOT`, or raise.

    The grammar only, as :func:`_require_receipt_path`: the wheel ships no
    ``experiments/``, so the file's existence and content are a tree test's
    business (``tests/test_serving_contract.py``).
    """
    if (not isinstance(value, str) or not value.startswith(WORLD_SIZE_DATA_ROOT)
            or len(value) == len(WORLD_SIZE_DATA_ROOT)
            or any(part in ("", ".", "..") for part in value.split("/"))):
        raise ValueError(
            f"{where} must be a repository path under {WORLD_SIZE_DATA_ROOT!r}, got {value!r}")
    return value


def _require_distinct_strings(value: Any, where: str) -> list:
    if (not isinstance(value, list) or not value
            or not all(isinstance(item, str) and item for item in value)
            or len(set(value)) != len(value)):
        raise ValueError(f"{where} must be a non-empty list of distinct strings, got {value!r}")
    return value


def _require_count(value: Any, where: str, minimum: int) -> int:
    if type(value) is not int or value < minimum:
        raise ValueError(f"{where} must be an integer of at least {minimum}, got {value!r}")
    return value


def _validate_single_rank_kl(block: Any, where: str) -> None:
    """The KL against the single-rank arm, as numbers a reader can check.

    Three arms (:data:`SINGLE_RANK_KL_ARMS`), each with every metric in
    :data:`SINGLE_RANK_KL_METRICS`, and the quantized arm's excess over the
    control DERIVED from them.  What the numbers mean -- whether the excess is
    acceptable -- is not a value here: the grade stays
    :data:`WORLD_SIZE_RECEIPT_GRADE` whatever they say.
    """
    import math

    _require_keys(block, where,
                  required={"issue", "table", "instrument", "read", "arms",
                            "excess_over_control"})
    if not isinstance(block["issue"], str) or not re.fullmatch(r"[\w.-]+#\d+", block["issue"]):
        raise ValueError(f"{where}.issue must name the tracking issue as repo#N, "
                         f"got {block['issue']!r}")
    _require_data_path(block["table"], f"{where}.table")
    if not isinstance(block["instrument"], str) or not block["instrument"]:
        raise ValueError(f"{where}.instrument must say which instrument measured the arms")
    read = _require_distinct_strings(block["read"], f"{where}.read")
    unknown = sorted(set(read) - set(SINGLE_RANK_KL_READINGS))
    if unknown:
        raise ValueError(f"{where}.read names {unknown}; the readings are "
                         f"{list(SINGLE_RANK_KL_READINGS)}")
    arms = block["arms"]
    _require_keys(arms, f"{where}.arms", required=set(SINGLE_RANK_KL_ARMS))
    for name in SINGLE_RANK_KL_ARMS:
        at = f"{where}.arms.{name}"
        _require_keys(arms[name], at, required={"id", "scope", "metrics"})
        for key in ("id", "scope"):
            if not isinstance(arms[name][key], str) or not arms[name][key]:
                raise ValueError(f"{at}.{key} must be a non-empty string")
        metrics = arms[name]["metrics"]
        _require_keys(metrics, f"{at}.metrics", required=set(SINGLE_RANK_KL_METRICS))
        for metric in SINGLE_RANK_KL_METRICS:
            value = metrics[metric]
            if (isinstance(value, bool) or not isinstance(value, (int, float))
                    or not math.isfinite(value) or value < 0):
                raise ValueError(f"{at}.metrics.{metric} must be a finite number of at least 0, "
                                 f"got {value!r}")
            if metric.endswith("_pct") and value > 100:
                raise ValueError(f"{at}.metrics.{metric} is a percentage, got {value!r}")
            if metric == "topk_coverage_mean" and value > 1:
                raise ValueError(f"{at}.metrics.{metric} is a probability mass, got {value!r}")
    excess = block["excess_over_control"]
    _require_keys(excess, f"{where}.excess_over_control", required=set(SINGLE_RANK_KL_EXCESS))
    for metric in SINGLE_RANK_KL_EXCESS:
        control = arms["control"]["metrics"][metric]
        if control <= 0:
            raise ValueError(
                f"{where}.arms.control.metrics.{metric} is {control!r}: a control with no "
                "divergence cannot scale the quantized arm's, so there is no excess to publish")
        derived = round(arms["quantized"]["metrics"][metric] / control, 2)
        if excess[metric] != derived:
            raise ValueError(
                f"{where}.excess_over_control.{metric} is {excess[metric]!r}, but the arms "
                f"beside it derive {derived!r} (quantized / control, two decimals). The ratio "
                "is read off the metrics, not typed next to them.")


def _validate_world_size_receipt(receipt: Any, where: str, platforms: Mapping[str, Any],
                                 declared_units: set) -> None:
    """One two-rank (or wider) receipt: the serves, their traces, the KL.

    Every value a consumer could gate on is checked for its grammar here; that
    the named files exist and that ``executed_units`` is what the traces in
    them actually executed is a tree test's business, because the wheel ships
    neither ``docs/`` nor ``experiments/``.
    """
    _require_keys(receipt, where,
                  required={"id", "world_size", "platform", "receipt", "serves",
                            "executed_units", "single_rank_kl", "grade"})
    if not isinstance(receipt["id"], str) or not re.fullmatch(r"[a-z0-9_]+", receipt["id"]):
        raise ValueError(f"{where}.id must be a lower-case identifier, got {receipt['id']!r}")
    world = _require_count(receipt["world_size"], f"{where}.world_size", 2)
    if receipt["platform"] not in platforms:
        raise ValueError(f"{where}.platform {receipt['platform']!r} is not a platform "
                         f"lane_eligibility publishes ({sorted(platforms)})")
    _require_receipt_path(receipt["receipt"], where)
    serves = receipt["serves"]
    if not isinstance(serves, list) or not serves:
        raise ValueError(f"{where}.serves must be a non-empty list of serve records")
    traces_seen: set = set()
    for j, serve in enumerate(serves):
        at = f"{where}.serves[{j}]"
        _require_keys(serve, at, required={"role", "image", "tessera_tree", "hosts", "flags",
                                           "route_traces"})
        if not isinstance(serve["role"], str) or not serve["role"]:
            raise ValueError(f"{at}.role must say what the serve was for")
        require_runtime_image(serve["image"], f"{at}.image")
        if (not isinstance(serve["tessera_tree"], str)
                or not re.fullmatch(r"[0-9a-f]{40}", serve["tessera_tree"])):
            raise ValueError(f"{at}.tessera_tree must be a full 40-hex commit, "
                             f"got {serve['tessera_tree']!r}")
        _require_distinct_strings(serve["hosts"], f"{at}.hosts")
        flags = serve["flags"]
        if not isinstance(flags, list) or not all(isinstance(f, str) and f for f in flags):
            raise ValueError(f"{at}.flags must be the serve's argument list, got {flags!r}")
        asked = [flags[k + 1] for k, flag in enumerate(flags[:-1])
                 if flag == "--tensor-parallel-size"]
        asked += [flag.split("=", 1)[1] for flag in flags
                  if flag.startswith("--tensor-parallel-size=")]
        if asked != [str(world)]:
            raise ValueError(
                f"{at}.flags ask for tensor_parallel_size {asked or 'nothing'}, and this receipt "
                f"covers a world of {world}: a serve record must be the serve at that world")
        traces = serve["route_traces"]
        if not isinstance(traces, list) or len(traces) != world:
            raise ValueError(
                f"{at}.route_traces must name one route trace per rank, {world} of them, "
                f"got {traces!r}")
        for k, trace in enumerate(traces):
            _require_data_path(trace, f"{at}.route_traces[{k}]")
            if trace in traces_seen:
                raise ValueError(f"{at}.route_traces[{k}] {trace!r} is named twice; each rank of "
                                 "each serve writes its own trace")
            traces_seen.add(trace)
    executed = _require_distinct_strings(receipt["executed_units"], f"{where}.executed_units")
    undeclared = sorted(set(executed) - declared_units)
    if undeclared:
        raise ValueError(f"{where}.executed_units names {undeclared}, which tensor_parallel.units "
                         "does not declare")
    _validate_single_rank_kl(receipt["single_rank_kl"], f"{where}.single_rank_kl")
    if receipt["grade"] != WORLD_SIZE_RECEIPT_GRADE:
        raise ValueError(
            f"{where}.grade is {receipt['grade']!r}, and a world-size receipt grades "
            f"{WORLD_SIZE_RECEIPT_GRADE!r} only: its KL compares the checkpoint with itself at "
            "another world size, not with its reference, so it attests execution and publishes "
            "a divergence. A quality grade is a lane_eligibility cell's evidence.")


def _validate_kv_head_replication(rule: Any, where: str) -> None:
    """The replication rule, derived from the loader's own constant (#330).

    Above one rank vLLM's ``num_kv_head_replicas`` decides which rows of a
    GQA/MQA layer each rank loads; ``sharding.layer_replicas`` reads it off the
    layer.  Publishing it is a statement about what the LOADER does, checked
    against :data:`sharding.KV_REPLICAS_ATTRIBUTE` exactly as ``loader_axes``
    is checked against ``ROUTE_TP_AXES``.  Whether a served receipt exercised
    a replicated layer is its own boolean, because a world-size receipt on a
    model with at least one KV head per rank does not.
    """
    from .sharding import KV_REPLICAS_ATTRIBUTE

    _require_keys(rule, where, required={"attribute", "shard_index", "exercised_by_receipt"},
                  # Prose for a person; no gate reads it.
                  optional={"note"})
    if rule["attribute"] != KV_REPLICAS_ATTRIBUTE:
        raise ValueError(
            f"{where}.attribute is {rule['attribute']!r}, and the loader reads "
            f"{KV_REPLICAS_ATTRIBUTE!r} (tessera.serving.sharding.KV_REPLICAS_ATTRIBUTE)")
    expected = f"tp_rank // {KV_REPLICAS_ATTRIBUTE}"
    if rule["shard_index"] != expected:
        raise ValueError(f"{where}.shard_index is {rule['shard_index']!r}, and the loader's "
                         f"index arithmetic is {expected!r}")
    if not isinstance(rule["exercised_by_receipt"], bool):
        raise ValueError(f"{where}.exercised_by_receipt must be true or false")


def _validate_tensor_parallel(block: Any, platforms: Mapping[str, Any]) -> None:
    """``max_world_size`` above 1 names a receipt, or it is refused by name.

    The field is an ATTESTATION -- the largest world size a served receipt
    covers -- and NOT a statement about whether the bytes can shard: they can,
    the artifact is TP-agnostic and the loader cuts a unit at load
    (``tessera.layout.slice_unit``); that is ``loader_axes``.  A unit at 1
    names no receipt.  A unit above 1 names a ``world_size_receipts`` entry at
    exactly its world whose serves' traces executed it, and whose single-rank
    KL arms are published; with any unit above 1 the block also publishes the
    KV-head replication rule the loader applies there (#330).
    """
    where_tp = "runtime_contract.tensor_parallel"
    _require_keys(block, where_tp, required={"axis", "semantics", "units"},
                  # ``units_note`` is prose for a person; no gate reads it
                  # (principle 14).
                  optional={"units_note", "world_size_receipts", "kv_head_replication"})
    units = block["units"]
    if not isinstance(units, list) or not units:
        raise ValueError(f"{where_tp}.units must be a non-empty list")
    for i, unit in enumerate(units):
        _require_keys(unit, f"{where_tp}.units[{i}]",
                      required={"unit", "kind", "max_world_size", "loader_axes"},
                      optional={"world_size_receipt"})
    declared = {unit["unit"] for unit in units}

    receipts = block.get("world_size_receipts", [])
    if not isinstance(receipts, list):
        raise ValueError(f"{where_tp}.world_size_receipts must be a list")
    by_id: dict = {}
    for j, receipt in enumerate(receipts):
        at = f"{where_tp}.world_size_receipts[{j}]"
        _validate_world_size_receipt(receipt, at, platforms, declared)
        if receipt["id"] in by_id:
            raise ValueError(f"{at}.id {receipt['id']!r} is published twice")
        by_id[receipt["id"]] = receipt

    named: set = set()
    for i, unit in enumerate(units):
        where = f"{where_tp}.units[{i}]"
        world = _require_count(unit["max_world_size"], f"{where}.max_world_size", 1)
        family = unit["unit"]
        if world == 1:
            if "world_size_receipt" in unit:
                raise ValueError(
                    f"{where} ({family}) attests max_world_size 1 and names world_size_receipt "
                    f"{unit['world_size_receipt']!r}; one rank is the world every serve covers, "
                    "so there is nothing for a receipt to attest")
        else:
            name = unit.get("world_size_receipt")
            if name is None:
                raise ValueError(
                    f"{where} ({family}) attests max_world_size {world} and names no "
                    "world_size_receipt. The field is an ATTESTATION -- the largest world size a "
                    "served receipt covers -- and above 1 it must name the receipt that covers "
                    "it: a two-rank serve record, one route trace per rank recording this unit, "
                    "and a KL against the single-rank arm. It is NOT a statement that the bytes "
                    "cannot shard (they can; loader_axes says what the loader does with each "
                    "axis). Name a tensor_parallel.world_size_receipts entry, or put this unit "
                    "back to 1.")
            receipt = by_id.get(name)
            if receipt is None:
                raise ValueError(
                    f"{where} ({family}) names world_size_receipt {name!r}, and "
                    f"tensor_parallel.world_size_receipts publishes {sorted(by_id)}")
            if receipt["world_size"] != world:
                raise ValueError(
                    f"{where} ({family}) attests max_world_size {world} on receipt {name!r}, "
                    f"which covers a world of {receipt['world_size']}")
            if family not in receipt["executed_units"]:
                raise ValueError(
                    f"{where} ({family}) names receipt {name!r}, whose traces executed "
                    f"{receipt['executed_units']} and not this unit; a receipt covers the units "
                    "its ranks served, not every unit in the block")
            named.add(name)
        _validate_loader_axes(unit["loader_axes"], family, where)

    orphans = sorted(set(by_id) - named)
    if orphans:
        raise ValueError(f"{where_tp}.world_size_receipts publishes {orphans}, which no unit "
                         "names; a receipt nothing attests with is not a contract value")
    raised = any(unit["max_world_size"] > 1 for unit in units)
    if raised:
        if "kv_head_replication" not in block:
            raise ValueError(
                f"{where_tp} attests a world above 1 and publishes no kv_head_replication. Above "
                "one rank vLLM's num_kv_head_replicas decides which rows of a GQA/MQA layer each "
                "rank loads (tessera#330); publish the rule the loader applies, derived from "
                "tessera.serving.sharding.KV_REPLICAS_ATTRIBUTE.")
        _validate_kv_head_replication(block["kv_head_replication"],
                                      f"{where_tp}.kv_head_replication")
    elif "kv_head_replication" in block:
        raise ValueError(
            f"{where_tp}.kv_head_replication is published while every unit is at 1: at one rank "
            "the rule describes no served path, and #330 keeps the contract silent there")


def _validate_loader_axes(axes: Any, family: str, where: str) -> None:
    """``loader_axes`` must BE ``sharding.ROUTE_TP_AXES``, not agree with it in prose.

    Principle 14 applied to this package's own table: the status is the value a
    gate reads and it is compared against the dict the routes themselves gate
    on, so a contract that said a family shards an axis its loader refuses --
    or the reverse -- is a refusal here rather than a surprise at load.  The
    ``reason`` beside it is prose: required where the status is ``refused``
    (a refusal an operator cannot act on is a wall), and ``null`` otherwise.

    Imported here rather than at module scope because ``sharding`` imports
    ``scheme``, and this module is read by a producer on a machine with no
    torch; neither import pulls torch, but keeping the contract reader's
    module-level dependencies to json is the property that keeps it true.
    """
    from .sharding import AXES, ROUTE_TP_AXES, TP_REFUSED, TP_STATUSES

    route = _FAMILY_TO_ROUTE.get(family)
    if route is None or route not in ROUTE_TP_AXES:
        raise ValueError(
            f"{where}.unit {family!r} names no route this package serves, so nothing here can "
            "say what its loader does with a shard axis")
    if not isinstance(axes, Mapping) or sorted(axes) != sorted(AXES):
        raise ValueError(
            f"{where}.loader_axes must describe exactly the axes {sorted(AXES)}, got "
            f"{sorted(axes) if isinstance(axes, Mapping) else type(axes).__name__}")
    for axis in AXES:
        entry = axes[axis]
        _require_keys(entry, f"{where}.loader_axes[{axis!r}]",
                      required={"status", "reason"})
        status = entry["status"]
        if status not in TP_STATUSES:
            raise ValueError(
                f"{where}.loader_axes[{axis!r}].status {status!r} is not one of "
                f"{list(TP_STATUSES)}")
        expected = ROUTE_TP_AXES[route][axis]
        if status != expected:
            raise ValueError(
                f"{where}.loader_axes[{axis!r}].status is {status!r} but the {route} loader "
                f"{expected} a {axis} cut (tessera.serving.sharding.ROUTE_TP_AXES). The table "
                "the routes gate on is the authority; a document that disagreed with it would "
                "be a claim about a runtime that does not exist.")
        reason = entry["reason"]
        if status == TP_REFUSED and not (isinstance(reason, str) and reason.strip()):
            raise ValueError(
                f"{where}.loader_axes[{axis!r}] is refused and carries no reason; a refusal an "
                "operator cannot act on is a wall, not a contract")
        if status != TP_REFUSED and reason is not None:
            raise ValueError(
                f"{where}.loader_axes[{axis!r}] is {status!r} and still carries a reason "
                f"{reason!r}; the field explains a refusal and is null otherwise")


def _validate_fused_module(block: Any, where: str) -> None:
    """``fused_module`` must BE ``scheme.FUSED_MODULE_FIELDS``, not agree with it.

    The same move ``loader_axes`` makes against ``ROUTE_TP_AXES``, for the
    question a producer's group allocator actually asks: inside one vLLM-fused
    module, which of a scheme's facts must every role share, and which is free
    per role?  The answer is a property of the DECODERS -- they read each role
    from that role's own manifest -- so it is published as a value the allocator
    reads, and checked here against the dict the loader itself gates on.  A
    document that said the rate was shared would cost a producer every
    per-member rung its objective picked; one that said a family was free would
    invite a checkpoint vLLM cannot build a method for.

    ``mixed_rung_receipt`` is the OTHER claim, and it is not this one.  It says
    whether a container receipt has covered a served module whose members took
    different rungs -- the distinction ``loader_axes`` and ``max_world_size``
    already draw between what the loader does and what has been measured.  It
    is a boolean a gate reads, never prose.
    """
    from .scheme import (FUSED_CONTAINER, FUSED_MODULE_FIELDS, FUSED_MODULE_SCHEMA,
                         FUSED_Q256_SPELLING)

    _require_keys(block, where,
                  required={"schema", "container", "fields", "sidecar_q256",
                            "mixed_rung_receipt"},
                  # Prose for a person, exactly as ``tensor_parallel.units_note``
                  # is; no gate reads a ``*_note``, and none may.
                  optional={"fields_note", "sidecar_q256_note", "mixed_rung_receipt_note"})
    if block["schema"] != FUSED_MODULE_SCHEMA:
        raise ValueError(f"{where}.schema must be {FUSED_MODULE_SCHEMA!r}, got {block['schema']!r}")
    if block["container"] != FUSED_CONTAINER:
        raise ValueError(
            f"{where}.container must be {FUSED_CONTAINER!r}: it is the magic "
            "``tessera.fused.parse_fused`` refuses anything else on")
    if block["sidecar_q256"] != FUSED_Q256_SPELLING:
        raise ValueError(
            f"{where}.sidecar_q256 must be {FUSED_Q256_SPELLING!r} "
            "(tessera.serving.scheme.FUSED_Q256_SPELLING); it names how a mixed-rung module is "
            "spelled in the checkpoint, and a producer that wrote another spelling would write "
            "a checkpoint this build refuses at load")
    fields = block["fields"]
    if not isinstance(fields, Mapping) or dict(fields) != FUSED_MODULE_FIELDS:
        raise ValueError(
            f"{where}.fields must equal tessera.serving.scheme.FUSED_MODULE_FIELDS "
            f"{FUSED_MODULE_FIELDS}, got {dict(fields) if isinstance(fields, Mapping) else fields!r}. "
            "The dict the loader gates on is the authority; a document that disagreed with it "
            "would tell a producer's allocator that a fused group may vary something this build "
            "refuses, or may not vary something it serves.")
    if not isinstance(block["mixed_rung_receipt"], bool):
        raise ValueError(
            f"{where}.mixed_rung_receipt must be a boolean: it says whether a container receipt "
            "covers a SERVED module whose members took different rungs, which is a different "
            "claim from what the loader accepts and must not be inferred from it")


#: What a computed build identity becomes when a library's glob is checked by
#: meaning: the name a load path writes is ``<prefix><identity>.so``.
_BUILD_IDENTITY_PLACEHOLDER = "0123456789abcdef"


def _library_name(block: Mapping[str, Any]) -> str:
    """A library basename the load path behind ``block`` can produce."""
    return f"{block['module_name_prefix']}{_BUILD_IDENTITY_PLACEHOLDER}.so"


def _validate_library(block: Mapping[str, Any], at: str) -> None:
    """The legibility rules for a published native library, said once.

    A ``native_extensions`` entry carries these four fields itself and a
    ``stock_kernel_overrides`` entry carries them in its ``library`` block; a
    consumer that fingerprints native residency reads both the same way, so
    they are held to one rule.
    """
    import fnmatch
    import os

    from .ext import MATCH_BASENAME_FNMATCH, csrc_dir

    prefix = block["module_name_prefix"]
    if not isinstance(prefix, str) or not prefix:
        raise ValueError(f"{at}.module_name_prefix must be a non-empty string")
    if block["match"] != MATCH_BASENAME_FNMATCH:
        raise ValueError(
            f"{at}.match is {block['match']!r}; this contract publishes exactly "
            f"{MATCH_BASENAME_FNMATCH!r} -- fnmatch the glob against the BASENAME of a "
            "mapped .so. The rule is a value because a consumer cannot otherwise tell a "
            "stem from a prefix from a pattern.")
    glob = block["filename_glob"]
    # The library a load path writes is ``<module name><LIB_EXT>`` and the
    # module name is ``<prefix><build identity>``, so the pattern is the prefix
    # with the identity and the suffix globbed.  Checked by MEANING, not by
    # spelling: a name this load path can produce must match.
    if not isinstance(glob, str) or not fnmatch.fnmatch(_library_name(block), glob):
        raise ValueError(
            f"{at}.filename_glob {glob!r} does not match a library name the load path can "
            f"produce ({prefix}<build identity>.so); a glob that matches nothing a serve "
            "maps is a fingerprint that reports every serve identical")
    source = block["source"]
    if not isinstance(source, str) or not source.startswith("csrc/"):
        raise ValueError(
            f"{at}.source must be a path under 'csrc/' relative to this package, got "
            f"{source!r}")
    if not os.path.isfile(os.path.join(csrc_dir(), source[len("csrc/"):])):
        raise ValueError(
            f"{at}.source {source!r} is not packaged with this build; a contract may not "
            "publish an extension whose sources did not ship")


def _validate_serving_loader(loaded_by: Any, at: str) -> None:
    """``loaded_by`` names a module of this serving package that exists."""
    from importlib import util as importlib_util

    if not isinstance(loaded_by, str) or not loaded_by.startswith(f"{__package__}."):
        raise ValueError(
            f"{at}.loaded_by is {loaded_by!r}; an entry belongs in this table only when the "
            f"library can be resident in a SERVING process, so it is loaded by a "
            f"{__package__}.* module. A producer-side extension does not belong here.")
    if importlib_util.find_spec(loaded_by) is None:
        raise ValueError(f"{at}.loaded_by names no module in this build: {loaded_by!r}")


def _validate_native_extensions(entries: Any, where: str) -> None:
    """``native_extensions`` must BE ``ext.NATIVE_EXTENSIONS``, and be legible.

    The contract publishes what the plugin EXECUTES; this block publishes what
    it LOADS, because a consumer that keys reproducibility on native-extension
    residency has no other machine-readable source and was mirroring the name
    in its own repository -- principle 14's failure, one repository over.

    Two things are checked and they are different.  First AUTHORITY: the block
    equals :data:`ext.NATIVE_EXTENSIONS`, whose ``module_name_prefix`` is the
    very constant ``ext._load_locked`` asks ``cpp_extension.load`` for, so the
    published name is the loaded name by construction rather than by care.
    Second LEGIBILITY: a consumer must not have to guess whether the published
    string is a stem, a prefix or a pattern, so ``match`` names the rule and
    ``filename_glob`` is checked to actually match a filename this load path
    can produce -- the JIT module name carries a build-identity hash, so no
    exact basename exists to publish.

    ``when_unavailable`` is per RESIDENCY and not an ``optional`` boolean on
    purpose: "this build may not have compiled it" and "the route runs without
    it" are two facts, and the second differs by mode (resident substitutes a
    named decoder, streamed refuses).  A fingerprint that exists to tell those
    serves apart needs the substitute's name, and needs to know that an absent
    extension with a streamed route record is an impossible pair.

    Imported here rather than at module scope for the reason ``loader_axes``
    gives: this module is read by a producer with no torch, and ``ext`` and
    ``lane`` are torch-free, but keeping the contract reader's module-level
    dependencies to ``json`` is the property that keeps that true.
    """
    from .ext import FALLBACK_REFUSED, FALLBACK_STATUSES, LANE_FIELDS, \
        LANE_REQUIREMENT_FIELDS, NATIVE_EXTENSIONS
    from .lane import MODES
    from .scheme import ROUTES

    if not isinstance(entries, list):
        raise ValueError(f"{where} must be a JSON array")
    if entries != list(NATIVE_EXTENSIONS):
        raise ValueError(
            f"{where} is not what this build loads. It must equal "
            "tessera.serving.ext.NATIVE_EXTENSIONS, whose module_name_prefix is the constant "
            "the JIT load path itself asks cpp_extension.load for; a document that named a "
            "different extension -- or forgot one -- would be a claim about a runtime that "
            f"does not exist. Published {entries!r}, loaded {list(NATIVE_EXTENSIONS)!r}.")
    seen: set[str] = set()
    for i, entry in enumerate(entries):
        at = f"{where}[{i}]"
        _require_keys(entry, at,
                      required={"module_name_prefix", "filename_glob", "match", "source",
                                "loaded_by", "routes", "lane", "when_unavailable"})
        _validate_library(entry, at)
        prefix = entry["module_name_prefix"]
        if prefix in seen:
            raise ValueError(f"{at}.module_name_prefix {prefix!r} is declared twice")
        seen.add(prefix)
        _validate_serving_loader(entry["loaded_by"], at)
        routes = entry["routes"]
        if not isinstance(routes, list) or not routes:
            raise ValueError(f"{at}.routes must name at least one route that needs it")
        unknown = sorted(set(routes) - set(ROUTES))
        if unknown:
            raise ValueError(
                f"{at}.routes names {unknown}, which this package does not serve "
                f"(tessera.serving.scheme.ROUTES)")
        # THE LANE, AND WHAT IT CAN READ.  ``when_unavailable`` names the
        # SUBSTITUTE's decoder; this names the extension's OWN, so a consumer
        # can tell "the lane ran" from "the fallback ran" without inverting a
        # fallback table.  ``requires`` is the lane's wire predicate, and it is
        # published because it is decidable from a PLAN: every field is a
        # function of ``(grid, q256)``, so a producer can refuse a checkpoint
        # that could never reach the lane before it encodes one unit (#104).
        # Absent means the lane has no predicate beyond its route's own -- an
        # empty object would be a claim of no constraint, which is different.
        lane = entry["lane"]
        _require_keys(lane, f"{at}.lane", required={"decoder"},
                      optional={"requires"})
        if not isinstance(lane["decoder"], str) or not lane["decoder"]:
            raise ValueError(
                f"{at}.lane.decoder must be the non-empty name this lane stamps in "
                "tessera.serving.telemetry's 'decoder' field; it is how a census counts the "
                "modules that actually took the lane")
        if "requires" in lane:
            spot = f"{at}.lane.requires"
            _require_keys(lane["requires"], spot, required=set(),
                          optional=set(LANE_REQUIREMENT_FIELDS))
            if not lane["requires"]:
                raise ValueError(
                    f"{spot} is empty; a lane with no wire predicate omits the block rather "
                    "than publishing an empty one, because 'no constraint' and 'nobody wrote "
                    "the constraint down' must not read the same to a gate")
            for field in ("column_rates", "column_rates_routed_moe", "window_bits", "grid_arities"):
                if field not in lane["requires"]:
                    continue
                values = lane["requires"][field]
                if (not isinstance(values, list) or not values
                        or not all(isinstance(v, int) and not isinstance(v, bool) and v > 0
                                   for v in values)):
                    raise ValueError(
                        f"{spot}.{field} must be a non-empty list of positive integers -- the "
                        f"exact set the lane's kernel reads -- got {values!r}")
                if sorted(values) != list(values) or len(set(values)) != len(values):
                    raise ValueError(
                        f"{spot}.{field} must be ascending and without repeats, got {values!r}")
            # A structure-scoped rate set (tessera#694) narrows the lane's own:
            # a launch cannot reach a rate the lane does not read, and the
            # field is meaningless without the wire predicate it narrows.
            if "column_rates_routed_moe" in lane["requires"]:
                if "column_rates" not in lane["requires"]:
                    raise ValueError(
                        f"{spot}.column_rates_routed_moe narrows column_rates, which this lane "
                        "does not publish; a launch bound without the wire predicate it narrows "
                        "is not decidable")
                extra = sorted(set(lane["requires"]["column_rates_routed_moe"])
                               - set(lane["requires"]["column_rates"]))
                if extra:
                    raise ValueError(
                        f"{spot}.column_rates_routed_moe names {extra}, which column_rates does "
                        "not; the routed-expert launch cannot reach a rate the lane does not read")
            # The decoration classes (#264): whether the lane reads a unit
            # that CARRIES the thing.  A boolean, so 'false' is a claim ("it
            # does not") and an absent field is an absence, exactly as for
            # the block itself.
            for field in ("release_overrides", "diagonals", "start_state"):
                if field in lane["requires"] and not isinstance(lane["requires"][field], bool):
                    raise ValueError(
                        f"{spot}.{field} must be a JSON boolean -- whether this lane reads a "
                        f"unit that carries it -- got {lane['requires'][field]!r}")
            if "rotation" in lane["requires"]:
                value = lane["requires"]["rotation"]
                if (not isinstance(value, list) or not value
                        or any(v not in _ATTESTED_WIRE_ROTATION for v in value)
                        or len(set(value)) != len(value)):
                    raise ValueError(
                        f"{spot}.rotation must be a non-empty list, without repeats, of the "
                        f"rotation states this package names "
                        f"({sorted(_ATTESTED_WIRE_ROTATION)}); a lane predicate a gate cannot "
                        f"resolve is prose. Got {value!r}")
            # The CHECKPOINT's dialect for body and plane (``attested_wire``'s,
            # not ``ROUTES``'), because that is the vocabulary a plan speaks;
            # the map to the route's spelling is the one already written for
            # ``attested_wire``, so a rename fails in one place.
            for field, dialect in (("body", _ATTESTED_WIRE_BODY),
                                   ("plane", _ATTESTED_WIRE_PLANE)):
                if field not in lane["requires"]:
                    continue
                value = lane["requires"][field]
                if value not in dialect:
                    raise ValueError(
                        f"{spot}.{field} is {value!r}, which is not a {field} this package "
                        f"names ({sorted(dialect)}); a lane predicate a gate cannot resolve is "
                        "prose")
        if sorted(lane) != sorted(f for f in LANE_FIELDS if f in lane):
            raise ValueError(f"{at}.lane fields must come from {list(LANE_FIELDS)}")
        behaviours = entry["when_unavailable"]
        if not isinstance(behaviours, Mapping) or sorted(behaviours) != sorted(MODES):
            raise ValueError(
                f"{at}.when_unavailable must answer for exactly the residencies "
                f"{sorted(MODES)}: what a serve does without this library is a different answer "
                "per mode, which is why this is not an 'optional' boolean")
        for mode in MODES:
            spot = f"{at}.when_unavailable[{mode!r}]"
            _require_keys(behaviours[mode], spot, required={"status", "decoder"})
            status, decoder = behaviours[mode]["status"], behaviours[mode]["decoder"]
            if status not in FALLBACK_STATUSES:
                raise ValueError(
                    f"{spot}.status {status!r} is not one of {list(FALLBACK_STATUSES)}")
            if status == FALLBACK_REFUSED and decoder is not None:
                raise ValueError(
                    f"{spot} refuses and still names a decoder {decoder!r}; a refused serve does "
                    "not exist, so there is nothing for a census to have recorded")
            if status != FALLBACK_REFUSED and not (isinstance(decoder, str) and decoder):
                raise ValueError(
                    f"{spot} substitutes and names no decoder; the substitute's name is the "
                    "whole value of this field -- it is the value the route stamps in "
                    "tessera.serving.telemetry's 'decoder' field, and it is how a fingerprint "
                    "tells a native serve from a fallback one")


#: An override's flag: a ``TESSERA_*`` environment variable, parsed by
#: ``flags.latched_bool`` at the install path.
_OVERRIDE_FLAG = re.compile(r"TESSERA_[A-Z0-9_]+")


def _validate_stock_kernel_overrides(entries: Any, where: str,
                                     native_extensions: list[Mapping[str, Any]]) -> None:
    """``stock_kernel_overrides`` must BE ``ext.STOCK_KERNEL_OVERRIDES``, and be legible.

    AUTHORITY as for ``native_extensions``: the block equals the table the
    install paths read through :func:`stock_kernel_override_refusal`, so an
    override the contract does not publish cannot install.  LEGIBILITY: each
    entry's ``overrides`` is validated against its own ``kind``'s closed
    fields, its flag is unique and defaults off, the only identity it may claim
    is ``bitwise_vs_stock``, and its ``library`` -- when it maps one -- obeys
    the native-extension rules, with a prefix and glob that collide with no
    library either block publishes, so a fingerprint reading both blocks names
    one library per mapped ``.so``.
    """
    import fnmatch

    from .ext import (IDENTITY_BITWISE_VS_STOCK, OVERRIDE_DEFAULT_OFF,
                      STOCK_KERNEL_EVIDENCE_FIELDS, STOCK_KERNEL_LIBRARY_FIELDS,
                      STOCK_KERNEL_OVERRIDE_FIELDS, STOCK_KERNEL_OVERRIDE_KINDS,
                      STOCK_KERNEL_OVERRIDES)

    if not isinstance(entries, list):
        raise ValueError(f"{where} must be a JSON array")
    if entries != list(STOCK_KERNEL_OVERRIDES):
        raise ValueError(
            f"{where} is not what this build installs. It must equal "
            "tessera.serving.ext.STOCK_KERNEL_OVERRIDES, the table every override's install "
            "path checks itself against; a document naming a different override -- or "
            "forgetting one -- would be a claim about a serve that does not exist. "
            f"Published {entries!r}, installed {list(STOCK_KERNEL_OVERRIDES)!r}.")
    libraries = [(f"runtime_contract.native_extensions[{i}]", entry)
                 for i, entry in enumerate(native_extensions)]
    flags: set[str] = set()
    for i, entry in enumerate(entries):
        at = f"{where}[{i}]"
        _require_keys(entry, at, required=set(STOCK_KERNEL_OVERRIDE_FIELDS))
        kind = entry["kind"]
        if kind not in STOCK_KERNEL_OVERRIDE_KINDS:
            raise ValueError(
                f"{at}.kind is {kind!r}; this package overrides "
                f"{sorted(STOCK_KERNEL_OVERRIDE_KINDS)} and validates each kind's overrides "
                "against its own fields")
        _require_keys(entry["overrides"], f"{at}.overrides",
                      required=set(STOCK_KERNEL_OVERRIDE_KINDS[kind]))
        for field, value in entry["overrides"].items():
            if not isinstance(value, str) or not value:
                raise ValueError(
                    f"{at}.overrides.{field} must name the stock object replaced, got {value!r}")
        flag = entry["enabled_by"]
        if not isinstance(flag, str) or not _OVERRIDE_FLAG.fullmatch(flag):
            raise ValueError(
                f"{at}.enabled_by must be the TESSERA_* environment variable that installs "
                f"the override, got {flag!r}")
        if flag in flags:
            raise ValueError(f"{at}.enabled_by {flag!r} installs two overrides")
        flags.add(flag)
        if entry["default"] != OVERRIDE_DEFAULT_OFF:
            raise ValueError(
                f"{at}.default is {entry['default']!r}; an override is {OVERRIDE_DEFAULT_OFF!r} "
                "unless its flag is set, so a serve that did not ask for it is the stock serve")
        _validate_serving_loader(entry["loaded_by"], at)
        if entry["required_identity"] != IDENTITY_BITWISE_VS_STOCK:
            raise ValueError(
                f"{at}.required_identity is {entry['required_identity']!r}; the one identity "
                f"an override behind a stock name may claim is {IDENTITY_BITWISE_VS_STOCK!r}")
        evidence = entry["evidence"]
        if not isinstance(evidence, list):
            raise ValueError(f"{at}.evidence must be a JSON array ([] until a gate passes)")
        for j, item in enumerate(evidence):
            _require_keys(item, f"{at}.evidence[{j}]", required=set(STOCK_KERNEL_EVIDENCE_FIELDS))
            for field in STOCK_KERNEL_EVIDENCE_FIELDS:
                if not isinstance(item[field], str) or not item[field]:
                    raise ValueError(f"{at}.evidence[{j}].{field} must be a non-empty string")
        library = entry["library"]
        if library is not None:
            _require_keys(library, f"{at}.library", required=set(STOCK_KERNEL_LIBRARY_FIELDS))
            _validate_library(library, f"{at}.library")
            libraries.append((f"{at}.library", library))
    # One library per mapped name, across both blocks: no two prefixes are
    # equal and no glob matches a name another entry's load path can produce.
    for spot, block in libraries:
        for other_spot, other in libraries:
            if other is block:
                continue
            if fnmatch.fnmatch(_library_name(other), block["filename_glob"]):
                raise ValueError(
                    f"{spot}.filename_glob {block['filename_glob']!r} also matches "
                    f"{_library_name(other)!r}, a library {other_spot} publishes; a fingerprint "
                    "must name one library per mapped .so")


def stock_kernel_override_refusal(enabled_by: str, *, kind: str, overrides: Mapping[str, str],
                                  loaded_by: str, library_prefix: str | None,
                                  contract: Mapping[str, Any] | None = None) -> str | None:
    """Why an install path may NOT act on its stock-kernel override, or ``None``.

    The packaged contract is the authority, not the install path's own
    constants: an override installs only when the contract publishes an entry
    under the flag that enabled it, and that entry names exactly the stock
    object, the loader and the library the install is about to use.  A build
    whose contract lost the entry, or whose install drifted from it, installs
    nothing and says why -- the reason is the install line's text.
    """
    payload = cached_serving_contract() if contract is None else contract
    entry = next((e for e in payload["stock_kernel_overrides"]
                  if e["enabled_by"] == enabled_by), None)
    if entry is None:
        return (f"the packaged contract publishes no stock_kernel_overrides entry enabled by "
                f"{enabled_by}")
    library = entry["library"]
    published_prefix = None if library is None else library["module_name_prefix"]
    for field, published, installing in (
            ("kind", entry["kind"], kind),
            ("overrides", dict(entry["overrides"]), dict(overrides)),
            ("loaded_by", entry["loaded_by"], loaded_by),
            ("library.module_name_prefix", published_prefix, library_prefix)):
        if published != installing:
            return (f"the packaged contract's {enabled_by} entry publishes {field} "
                    f"{published!r} and this install would use {installing!r}")
    return None


def validate_serving_contract(contract: Mapping[str, Any]) -> None:
    """Refuse a contract this package would not itself honour.

    The point is not schema hygiene: it is that the packaged table and the code
    that serves are one artifact.  A cell naming a family no route serves, a
    structure the dispatch refuses, or a rung the reader will not accept would
    be a claim about a runtime that does not exist.
    """
    from .scheme import (MOE_BUILDERS, ROUTES, STRUCTURE_DENSE, STRUCTURE_ROUTED_MOE,
                         STRUCTURES)

    _require_keys(contract, "runtime_contract",
                  required={"schema", "contract_version", "quant_method", "versions",
                            "native_extensions", "stock_kernel_overrides", "formats",
                            "lane_eligibility",
                            "tensor_parallel", "expert_parallel", "fused_module",
                            "construction", "activation_quantizers",
                            "producer_interface"},
                  # History, not a gate input: a consumer reads the version, and
                  # the changelog says what the version changed for a person.
                  optional={"changelog"})
    if contract["schema"] != CONTRACT_SCHEMA:
        raise ValueError(
            f"runtime_contract.schema must be {CONTRACT_SCHEMA!r}, got {contract['schema']!r}")
    if contract["quant_method"].get("canonical") != REQUIRES_PLUGIN:
        raise ValueError(
            f"runtime_contract.quant_method.canonical must be {REQUIRES_PLUGIN!r}: it is the "
            "checkpoint field that selects this plugin")
    # ``versions`` (v6, #131): closed, every field checked, nothing about a
    # measured runtime -- that lives on the cells.  A reader that still wrote
    # ``attested_on`` learns here, at load, that it no longer means anything.
    versions = contract["versions"]
    _require_keys(versions, "runtime_contract.versions", required=set(VERSIONS_KEYS))
    if not isinstance(versions["tessera"], str) or not versions["tessera"]:
        raise ValueError(
            "runtime_contract.versions.tessera must be a non-empty string, the distribution "
            f"version; got {versions['tessera']!r}")
    if versions["plugin_entry_point"] != PLUGIN_ENTRY_POINT:
        raise ValueError(
            f"runtime_contract.versions.plugin_entry_point must be {PLUGIN_ENTRY_POINT!r}, the "
            f"entry point this package registers; got {versions['plugin_entry_point']!r}")
    default_serve_image = require_runtime_image(
        versions["default_serve_image"], "runtime_contract.versions.default_serve_image")

    _validate_native_extensions(contract["native_extensions"],
                                "runtime_contract.native_extensions")
    _validate_stock_kernel_overrides(contract["stock_kernel_overrides"],
                                     "runtime_contract.stock_kernel_overrides",
                                     contract["native_extensions"])
    _validate_construction(contract["construction"], "runtime_contract.construction")
    validate_producer_interface(contract["producer_interface"],
                                "runtime_contract.producer_interface")
    if contract["contract_version"] >= 57 and "routed_units" not in contract["producer_interface"]:
        raise ValueError("runtime_contract v57 requires producer_interface.routed_units")

    families = {}
    for i, entry in enumerate(contract["formats"]):
        where = f"runtime_contract.formats[{i}]"
        _require_keys(entry, where,
                      required={"kind", "family", "grid", "name_pattern",
                                "activation_contract",
                                "reader_rate_range_q256", "reader_rate_step_q256",
                                "reader_rate_bound", "attested_rungs_q256",
                                "attested_wire",
                                "native_terminal_q256", "residency_modes"},
                      optional={"candidate_rungs_q256", "structures", "allowable_rungs"})
        # The A side, where a gate can read it.  It belongs on the ROW and not
        # only on the cells because it is a claim about EXECUTION -- what this
        # family's route feeds the GEMM -- and a family can be decodable before
        # any receipt covers it.  Published only on cells, a family with no cell
        # yet had its activation contract in changelog prose, which a consumer
        # cannot tell apart from nobody having filled it in.  Checked against
        # the dict the routes dispatch on, exactly as ``loader_axes`` is checked
        # against ``ROUTE_TP_AXES``.
        route = _FAMILY_TO_ROUTE.get(entry["family"])
        if route is None or route not in ROUTES:
            raise ValueError(
                f"{where}.family {entry['family']!r} names no route this package serves, so "
                "nothing here can say what its A side executes")
        expected_contract = ROUTES[route]["activation_contract"]
        if entry["activation_contract"] != expected_contract:
            raise ValueError(
                f"{where}.activation_contract is {entry['activation_contract']!r} but the "
                f"{route} route executes {expected_contract!r} "
                "(tessera.serving.scheme.ROUTES). The route is the authority; a document that "
                "disagreed with it would price an A side the runtime does not execute.")
        if entry["kind"] != FORMAT_KIND:
            raise ValueError(f"{where}.kind must be {FORMAT_KIND!r}, got {entry['kind']!r}")
        # The residency, where a gate can read it.  It belongs on the ROW and
        # is checked against the tuple the serve gates on, exactly as
        # ``loader_axes`` is checked against ``ROUTE_TP_AXES``: a row claiming
        # a residency the build does not serve -- or inventing a mode, or a
        # typo -- would otherwise validate green while letting a producer
        # under-price or over-attest a residency.  Membership, not equality:
        # a family served in one residency only is an honest row.
        # Imported here rather than at module scope for the reason
        # ``loader_axes`` gives: this module is read by a producer with no
        # torch, and ``lane`` is torch-free, but keeping the contract
        # reader's module-level dependencies to ``json`` is the property that
        # keeps that true.
        from .lane import MODES

        modes = entry["residency_modes"]
        if (not isinstance(modes, list) or not modes
                or any(not isinstance(m, str) for m in modes)
                or len(set(modes)) != len(modes)
                or any(m not in MODES for m in modes)):
            raise ValueError(
                f"{where}.residency_modes must be the residencies this build serves: a "
                f"non-empty list of distinct modes from {list(MODES)} "
                "(tessera.serving.lane.MODES -- the set lane.serve_mode and "
                f"build_tessera_method gate on). Got {modes!r}.")
        # The STRUCTURES the plugin dispatches for this family (v27,
        # tessera#492), where a gate can read them.  A dispatch fact and not
        # an attestation -- the cells say what was served -- checked against
        # the dict the config dispatches on, exactly as ``activation_contract``
        # is checked against ``ROUTES`` and ``loader_axes`` against
        # ``ROUTE_TP_AXES``: every family has the dense route, and a family
        # has the routed_moe structure iff ``scheme.MOE_BUILDERS`` names a
        # builder for it.  Optional so a reader written against an earlier
        # version keeps reading the document.
        structures = entry.get("structures")
        if structures is not None:
            expected_structures = [STRUCTURE_DENSE] + (
                [STRUCTURE_ROUTED_MOE] if route in MOE_BUILDERS else [])
            if list(structures) != expected_structures:
                raise ValueError(
                    f"{where}.structures is {structures!r} but the {route} route dispatches "
                    f"{expected_structures!r} (tessera.serving.scheme.MOE_BUILDERS names "
                    f"{sorted(MOE_BUILDERS)}). The dispatch table is the authority; a document "
                    "that disagreed with it would offer a structure the plugin refuses, or hide "
                    "one it serves.")
        alias = entry.get("candidate_rungs_q256")
        if alias is not None and list(alias) != list(entry["attested_rungs_q256"]):
            raise ValueError(
                f"{where}: candidate_rungs_q256 is a DEPRECATED ALIAS of "
                f"attested_rungs_q256 and must carry the same list, got {alias!r} vs "
                f"{entry['attested_rungs_q256']!r}. It exists only so a reader written "
                "against schema v1 keeps reading this document; two names disagreeing "
                "about one set is the confusion the rename was for.")
        low, high, step = _reader_rate(entry, where)
        for rung in entry["attested_rungs_q256"]:
            if not reader_accepts(rung, low, high, step):
                raise ValueError(
                    f"{where}: attested rung {rung} is not one the reader accepts "
                    f"([{low}, {high}] step {step}). An attested rung is a rung that WAS served; "
                    "it cannot lie outside what the decoder takes.")
        _validate_attested_wire(entry, route, where)
        if "allowable_rungs" in entry:
            _validate_allowable_rungs(entry, route, where)
        families[entry["family"]] = entry

    block = contract["lane_eligibility"]
    _require_keys(block, "runtime_contract.lane_eligibility",
                  required={"schema", "platforms", "regimes", "structures", "cells"})
    if block["schema"] != LANE_ELIGIBILITY_SCHEMA:
        raise ValueError(
            f"runtime_contract.lane_eligibility.schema must be {LANE_ELIGIBILITY_SCHEMA!r}, "
            f"got {block['schema']!r}")
    if set(block["regimes"]) != set(CENSUS_PHASE_REGIMES.values()):
        raise ValueError(
            f"runtime_contract.lane_eligibility.regimes declares {sorted(block['regimes'])}, "
            f"but the serve-side observation exercises "
            f"{sorted(set(CENSUS_PHASE_REGIMES.values()))} "
            f"(contract.CENSUS_PHASE_REGIMES, read by tools/tessera_route_census.py). A regime "
            "this document declares and the census never drives is a cell nothing observes, and "
            "a phase the census drives under a name this document does not declare cannot be "
            "joined to a cell at all -- which is how a per-(family, regime) expectation goes "
            "vacuously true on half the matrix. Add the regime to BOTH sides, in this table.")
    declared_structures = block["structures"]
    if (not isinstance(declared_structures, list) or not declared_structures
            or any(not isinstance(s, str) for s in declared_structures)
            or len(set(declared_structures)) != len(declared_structures)):
        raise ValueError(
            "runtime_contract.lane_eligibility.structures must be a non-empty list of "
            f"distinct strings, got {declared_structures!r}")
    # ``scheme.STRUCTURES`` is the DISPATCH-capability bound, not an
    # attestation source.  A new dispatch structure must not become eligible
    # here merely because nobody remembered to add it to an ``unserved``
    # denylist: only a cell below is the published authority that a served
    # receipt exists.  First refuse anything the build cannot execute; after
    # validating the cells, derive the positive attested set from them.
    refused = sorted(set(declared_structures) - set(STRUCTURES))
    if refused:
        raise ValueError(
            f"runtime_contract.lane_eligibility.structures names {refused}, which "
            "scheme.STRUCTURES says the dispatch refuses outright")
    contracts_by_family = {
        # The route's own constant, not a copy: a cell that drifted from the
        # code would attest an activation contract the serve does not run.
        family: route["activation_contract"] for family, route in (
            (f, ROUTES[fam]) for f, fam in _FAMILY_TO_ROUTE.items())
    }

    # THE PLATFORM AXIS (v10, #456).  Before this, ``platforms`` was a set of
    # KEYS and the only thing read of it was whether a cell's platform was
    # declared.  A cell is a RECEIPT, so that made "has this been served here"
    # the only sentence the table could form -- and there is no way to say the
    # sentence an AMD box needs said: this family has NO native route on this
    # device.  Silence had to stand in for it, and a silence is not an
    # attestation.  An entry says it now, per family, in ``executes``.
    _validate_platform_entries(block, contracts_by_family)
    _cell_scope: dict = {}
    cell_ids: set[str] = set()
    cell_structures: list[str] = []
    toolchains_by_image: dict[str, tuple[tuple[str, str], str]] = {}
    for i, cell in enumerate(block["cells"]):
        where = f"runtime_contract.lane_eligibility.cells[{i}]"
        _require_keys(cell, where,
                      required={"id", "platform", "family", "structure", "regime",
                                "rungs_q256", "activation_contract", "executes",
                                "route_status", "qualification", "requires_plugin",
                                "requires_serve_flags", "predicates", "runtime", "evidence"},
                      # v11 (tessera#750): the run tables the cell's census rungs
                      # cover under the family's ``allowable_rungs`` rule.
                      optional={"run_tables"})
        if not isinstance(cell["id"], str) or not cell["id"]:
            raise ValueError(f"{where}.id must be a non-empty string")
        if cell["id"] in cell_ids:
            raise ValueError(f"{where} repeats cell id {cell['id']!r}; every cell has one identity")
        cell_ids.add(cell["id"])
        runtime_image, execution_modes = cell_runtime_scope(cell, where)
        # ONE IMAGE, ONE TOOLCHAIN (v6, #131): a digest names bytes, so two
        # cells naming one image and two vLLM builds would be two runtimes
        # under one digest, which a digest cannot be.
        toolchain = cell_runtime_versions(cell, where)
        cell_runtime_code(cell, where)
        known = toolchains_by_image.setdefault(runtime_image, (toolchain, cell["id"]))
        if known[0] != toolchain:
            raise ValueError(
                f"{where} ({cell['id']!r}) records (vllm, torch) {toolchain} on "
                f"{runtime_image}, but {known[1]!r} records {known[0]} on the same digest; "
                "one image cannot be two runtimes. One of the two receipts is misread.")
        if cell["platform"] not in block["platforms"]:
            raise ValueError(f"{where}.platform {cell['platform']!r} is not declared")
        if cell["regime"] not in block["regimes"]:
            raise ValueError(f"{where}.regime {cell['regime']!r} is not declared")
        if cell["structure"] not in block["structures"]:
            raise ValueError(f"{where}.structure {cell['structure']!r} is not declared")
        if cell["structure"] not in cell_structures:
            cell_structures.append(cell["structure"])
        if cell["family"] not in families:
            raise ValueError(f"{where}.family {cell['family']!r} is not published in formats[]")
        if cell["route_status"] not in _ROUTE_STATUSES:
            raise ValueError(f"{where}.route_status {cell['route_status']!r} is not a status")
        if cell["qualification"] not in _QUALIFICATIONS:
            raise ValueError(f"{where}.qualification {cell['qualification']!r} is not one")
        # A CELL IS A RECEIPT FROM A BACKED PLATFORM (v10, #456).  The entry
        # is the platform's statement about the family; a cell is a serve that
        # happened.  A cell sitting on a null entry is the document
        # contradicting itself -- an unbacked platform says so in ``executes``,
        # it does not mint cells.
        if block["platforms"][cell["platform"]]["executes"][cell["family"]] is None:
            raise ValueError(
                f"{where} publishes a cell for {cell['family']!r} on platform "
                f"{cell['platform']!r}, whose executes entry for that family is null. "
                "null means the pinned runtime has no native route for these bytes on "
                "this device; a receipt saying it served there is the opposite claim. "
                "One of the two is wrong, and this document cannot say which.")
        # A COMPILE RECEIPT CANNOT BACK A ROUTE (v10, #456).  compile_only
        # says a toolchain accepted the code; backed says a device ran it.
        # They are different measurements and the weaker one cannot carry the
        # stronger claim. Touches nothing shipped: every v22 cell is
        # device_qualified.
        if (cell["qualification"] == "compile_only"
                and cell["route_status"] != "unbacked"):
            raise ValueError(
                f"{where} is qualification 'compile_only' with route_status "
                f"{cell['route_status']!r}. A compile receipt proves a toolchain fact and "
                "a backed route needs a device: the only route_status a compile_only cell "
                "may carry is 'unbacked'.")
        if cell["requires_plugin"] != REQUIRES_PLUGIN:
            raise ValueError(
                f"{where}.requires_plugin must be {REQUIRES_PLUGIN!r}: stock vLLM has no reader "
                "for these bytes, so every cell here is plugin-gated")
        if not cell["requires_serve_flags"]:
            raise ValueError(
                f"{where}: every route is reached through a declared residency, so a cell names "
                "the serve flag that selects one")
        cell_predicates(cell, where)
        cell_evidence(cell, where, regimes=block["regimes"])
        expected = contracts_by_family[cell["family"]]
        if cell["activation_contract"] != expected:
            raise ValueError(
                f"{where}.activation_contract is {cell['activation_contract']!r} but the "
                f"{cell['family']} route executes {expected!r}")
        unknown_rungs = sorted(set(cell["rungs_q256"])
                               - set(families[cell["family"]]["attested_rungs_q256"]))
        if unknown_rungs:
            raise ValueError(
                f"{where}.rungs_q256 names {unknown_rungs}, which the family does not publish")
        # WHICH RUN TABLES IT COVERS (v11, tessera#750).  Derived, never
        # asserted: the run tables of the census rungs the family's rule
        # admits.  A census at one rung of a table plus the kernel oracle's
        # equivalence across the table is the whole claim, so a cell can
        # neither widen past its census nor forget a table its census covers.
        family_entry = families[cell["family"]]
        want_tables = derived_cell_run_tables(cell, family_entry)
        got_tables = cell.get("run_tables", [])
        if got_tables != want_tables:
            raise ValueError(
                f"{where}.run_tables is {got_tables!r} but its census rungs "
                f"{list(cell['rungs_q256'])} cover {want_tables!r} under {cell['family']}'s "
                "allowable_rungs rule. A cell covers the run table of each census rung the rule "
                "admits and no other: a table with no census rung was never served, and a "
                "census rung's table left out hides rungs the serve covers.")
        # WHAT IT EXECUTES (schema v4).  Shape first, then the value.
        executes = cell["executes"]
        if (not isinstance(executes, list) or not executes
                or any(not isinstance(e, Mapping) for e in executes)):
            raise ValueError(
                f"{where}.executes must be a non-empty list of {{symbol, decoder}} objects: a "
                "cell that names no launch attests a route nobody can identify, and an empty "
                "list would read as 'this regime runs nothing'")
        for j, launch in enumerate(executes):
            _require_keys(launch, f"{where}.executes[{j}]", required={"symbol", "decoder"})
        if len(cell_executes(cell)) != len(executes):
            raise ValueError(
                f"{where}.executes repeats a (symbol, decoder) pair; the field is a SET of "
                "launches and a duplicate would double-count a route in any histogram "
                "built from it")
        _validate_cell_executes(cell, _FAMILY_TO_ROUTE[cell["family"]],
                                families[cell["family"]], contract, where)
        # THE RESIDENCY IS A CONDITION, so two cells of one (platform, family,
        # structure, regime, runtime image, execution mode) must not both claim
        # one residency: a reader resolving
        # "what runs here" would otherwise get whichever cell it read first,
        # and that is the failure this schema version exists to close.
        modes = cell_residency_modes(cell, where)
        # THE ID NAMES THE SCOPE, NEVER THE LAUNCH.  Until v4 every id ended in
        # the launch it claimed (``..._decode_scaled_mm_w8a8``) -- an assertion
        # in a string no gate parses, which went stale the day the window-GEMV
        # lane became reachable while the id went on saying ``scaled_mm``
        # (#111). The launch is ``executes`` now. The id retains its base
        # scope, optionally with the v5 runtime suffix; explicit cell fields
        # remain the authority for matching either spelling.
        expected_id = "_".join(
            [cell["family"].lower(), cell["structure"], cell["platform"].replace("_", ""),
             cell["regime"]]
            + ([] if len(modes) == len(_all_modes()) else list(modes)))
        scoped_id = expected_id + cell_runtime_id_suffix(cell)
        if cell["id"] not in (expected_id, scoped_id):
            raise ValueError(
                f"{where}.id is {cell['id']!r}; a cell id is its SCOPE and must be "
                f"{expected_id!r}, optionally followed by its derived runtime suffix "
                "(family, structure, platform, regime, plus the residency where the cell "
                "covers only some). An id that names a launch is a second, "
                "unparsed spelling of `executes` -- exactly the one that went stale.")
        scope = (cell["platform"], cell["family"], cell["structure"], cell["regime"], runtime_image)
        for mode in modes:
            for execution_mode in execution_modes:
                key = (scope, mode, execution_mode)
                clash = _cell_scope.get(key)
                if clash is not None:
                    raise ValueError(
                        f"{where} ({cell['id']!r}) and {clash!r} both cover "
                        f"{scope} at residency {mode!r} and execution mode {execution_mode!r}. "
                        "A cell is resolved by these facts plus the rung, so two cells "
                        "claiming one of them would make the answer depend on table order.")
                _cell_scope[key] = cell["id"]

    # A PLATFORM'S SERVE IMAGE IS ONE OF ITS OWN (v10, #456).
    #
    # The design asked for the stronger rule -- every cell's ``runtime.image``
    # equals its platform's ``serve_image`` -- and the shipped document
    # falsifies it: ``sm_121`` already carries TWO attested images, the eight
    # dense cells on the vanilla pin and the two ``routed_moe`` cells on a
    # second build. Taken literally that rule refuses the contract in this
    # file. So the rule is the one the data supports: an image somebody
    # actually served on THIS platform, and null exactly when nobody has.
    # Measured, not softened.
    images_by_platform: dict[str, set[str]] = {}
    for cell in block["cells"]:
        images_by_platform.setdefault(cell["platform"], set()).add(cell["runtime"]["image"])
    serve_images: set[str] = set()
    for key, entry in block["platforms"].items():
        where = f"runtime_contract.lane_eligibility.platforms[{key!r}]"
        attested = images_by_platform.get(key, set())
        serve_image = entry["serve_image"]
        if not attested:
            if serve_image is not None:
                raise ValueError(
                    f"{where}.serve_image is {serve_image!r} but no cell on this platform "
                    "attests any image. A serve image is the runtime a receipt was taken "
                    "under; a platform with no receipts names null.")
            continue
        if serve_image is None:
            raise ValueError(
                f"{where}.serve_image is null but {len(attested)} cell(s) on this platform "
                f"attest {sorted(attested)}. null means nobody has served here.")
        require_runtime_image(serve_image, f"{where}.serve_image")
        if serve_image not in attested:
            raise ValueError(
                f"{where}.serve_image is {serve_image!r}, which no cell on this platform "
                f"attests (its cells attest {sorted(attested)}). A platform's serve image "
                "is one of its own receipts, never another platform's.")
        serve_images.add(serve_image)

    # THE PIN IS AN ATTESTED IMAGE (v6, #131).  ``default_serve_image`` is the
    # one digest every harness reads; a default no cell was measured on would
    # be a pin to a runtime nothing here says anything about.  Since v10 it is
    # also some platform's ``serve_image``: the pin names a place to serve,
    # and a digest no platform points at names a runtime with no home.
    if default_serve_image not in toolchains_by_image:
        raise ValueError(
            f"runtime_contract.versions.default_serve_image is {default_serve_image!r}, but no "
            f"lane_eligibility cell attests that image (cells attest "
            f"{sorted(toolchains_by_image)}). The default serve image is the pin harnesses "
            "read; it must be a runtime some receipt covers.")
    # ... and since v10 it belongs to a PLATFORM.  The older rule above says
    # some receipt covers the digest; this one says some platform points at
    # it, which is the sentence a consumer asking "where do I serve this"
    # actually needs.  It runs second so the historical diagnosis still wins
    # for a digest nothing attests at all -- the weaker fault gets the more
    # specific message.
    if serve_images and default_serve_image not in serve_images:
        raise ValueError(
            f"runtime_contract.versions.default_serve_image is {default_serve_image!r}, "
            f"which is no platform's serve_image (platforms name {sorted(serve_images)}). "
            "The pin is the default place to serve; it belongs to a platform.")

    # The structure axis is a projection of the receipt-bearing cells, never
    # of the dispatch roster.  This is intentionally positive authority: when
    # a future structure enters ``scheme.STRUCTURES`` it remains unattested
    # until a cell is published for an actual serve, without requiring a
    # second hand-maintained list of every runnable-but-unserved structure.
    if declared_structures != cell_structures:
        without_cells = sorted(set(declared_structures) - set(cell_structures))
        raise ValueError(
            "runtime_contract.lane_eligibility.structures names "
            f"{declared_structures}, but its receipt-bearing cells project exactly to "
            f"{cell_structures}. "
            + (f"no receipt-bearing cell names {without_cells}; lane_eligibility is where "
               "served facts go, so dispatch capability alone cannot attest a structure. "
               if without_cells else
               "The structure axis is ordered by first occurrence in the cells, so a second "
               "spelling cannot describe the same published contract. ")
            + "Publish the served cell only after its census, artifact, and quality receipt "
              "exist, then derive this axis from those cells.")

    _validate_tensor_parallel(contract["tensor_parallel"],
                              contract["lane_eligibility"]["platforms"])
    if contract["expert_parallel"]["units"]:
        raise ValueError(
            "runtime_contract.expert_parallel.units must be empty: no served measurement covers "
            "expert-parallel execution, so the contract makes no expert-parallel claim")
    _validate_fused_module(contract["fused_module"], "runtime_contract.fused_module")
    # What the activation quantizer EMITS, read from the kernel rather than
    # modelled (#484).  ``activation_contract`` is a name, and a name says the
    # grid, the group and the scale dtype -- not how a value becomes a code.
    # The route hands the static global to vLLM's ``scaled_fp4_quant``, so the
    # rounding is the runtime's; a consumer that re-implements it is asserting
    # a runtime behaviour.  The table is validated against the CELLS, because
    # an attestation for a contract nothing on that platform executes would be
    # a claim about a runtime that does not serve here.
    served: dict[str, set] = {}
    for cell in block["cells"]:
        served.setdefault(cell["platform"], set()).add(cell["activation_contract"])
    validate_activation_quantizers(
        contract["activation_quantizers"], platforms=block["platforms"],
        cell_contracts=served, require_image=require_runtime_image)


def _reader_rate(entry: Mapping[str, Any], where: str) -> tuple[int, int, int]:
    low, high = entry["reader_rate_range_q256"]
    step = entry["reader_rate_step_q256"]
    if not (isinstance(low, int) and isinstance(high, int) and isinstance(step, int)):
        raise ValueError(f"{where}: the reader rate range and step are integer q256 values")
    if low > high:
        raise ValueError(f"{where}: reader_rate_range_q256 is [{low}, {high}], which is empty")
    if step < 1:
        raise ValueError(f"{where}: reader_rate_step_q256 must be >= 1, got {step}")
    return low, high, step


def reader_accepts(q256: int, low: int, high: int, step: int) -> bool:
    """Is ``q256`` on the published grid of rates the decoder reads?"""
    return low <= q256 <= high and (q256 - low) % step == 0


# ---------------------------------------------------------------------------
# allowable rungs: a RULE over run tables, not a list of rungs (lane schema v11)
# ---------------------------------------------------------------------------
#
# A rung of a window-grammar family is a mix of at most two adjacent column
# rates -- its RUN TABLE, ``grammar.rate_set`` of its per-code root -- and the
# fused kernels are instantiated per run table: the mix fraction and the
# placement of the upper-rate columns are runtime data (the run pair's
# ``n_lo``/``w_hi`` and the block descriptors).  So a numerics oracle attests
# a KERNEL VARIANT, and every rung whose run table is that variant is the same
# kernel reading different data.  Until v11 the contract enumerated rungs one
# at a time (``attested_rungs_q256``, a cell's ``rungs_q256``), which offered a
# producer 8 of the 1,793 rungs the E4M3 reader takes.  ``allowable_rungs`` on
# a ``formats[]`` row states the rule instead:
#
# * ``rule`` -- ``"window_rate_set"``, the one rule defined: a rung ``q`` is
#   allowable when it lies in ``range_q256`` on ``step_q256``, is not in
#   ``excluded_q256``, and its run table (:func:`rung_rates`) is in
#   ``run_tables`` -- the variants the kernel oracle attests -- and not in
#   ``excluded_run_tables``, the variants a measured geometry sweep excludes.
# * ``wire`` -- the one ``wire.recipes`` entry (without ``q256``) every
#   allowable rung is cut on; an attested rung the rule covers must be stamped
#   with exactly this wire.
# * ``evidence`` -- repository paths to the oracle and sweep receipts.
#
# A CELL covers the run tables of its census rungs (``run_tables``, DERIVED
# here and refused when it disagrees): a served census at one rung of a run
# table, with the oracle's equivalence across the table, covers every
# allowable rung of it.  ``rungs_q256`` keeps listing the census rungs, and a
# census rung is covered whether or not the rule admits it.
# :func:`cell_covers_rung` is the one predicate every consumer asks.

#: The ``allowable_rungs.rule`` values this package defines.
ALLOWABLE_RULES = ("window_rate_set",)
_ALLOWABLE_KEYS = {"rule", "code_arity", "range_q256", "step_q256", "run_tables",
                   "excluded_run_tables", "excluded_q256", "wire", "evidence"}
_WIRE_STAMP_KEYS = {"body", "span", "plane", "window_bits", "seed", "sigma", "channel_sigma"}


def _family_arity_cap(entry: Mapping[str, Any], where: str = "formats row") -> tuple[int, int]:
    """``(arity, cap)``: weights per code of the family's grid, and its highest
    per-code column rate (``native_terminal_q256`` on the per-code axis)."""
    from ..alphabet import SERIALISABLE_GRIDS

    grid = next((g for g in SERIALISABLE_GRIDS.values() if g.name == str(entry["grid"])), None)
    if grid is None:
        raise ValueError(
            f"{where}: formats grid {entry['grid']!r} names no serialisable grid this "
            "package holds; a rung's rate set cannot be derived for it")
    ar = int(grid.arity)
    return ar, int(entry["native_terminal_q256"]) * ar // 256


def rung_rates(entry: Mapping[str, Any], q256: int) -> tuple[int, ...]:
    """The run table of rung ``q256`` of a ``formats[]`` row's family: the
    column rates its schedule mixes (``grammar.rate_set`` of the per-code root;
    a code covers ``arity`` weights, so the per-weight rung resolves onto the
    per-code root as ``_validate_cell_executes`` does).  Raises
    ``GrammarError`` for a rung the family cannot encode."""
    from fractions import Fraction

    from ..grammar import rate_set

    ar, cap = _family_arity_cap(entry)
    return tuple(int(r) for r in rate_set(Fraction(int(q256) * ar, 256), cap=cap))


def rung_allowable(entry: Mapping[str, Any], q256: int) -> bool:
    """Does the family's ``allowable_rungs`` rule admit ``q256``?  ``False``
    for a row with no rule and for a rule this package does not define: an
    unknown rule admits nothing (fail closed)."""
    from ..errors import GrammarError

    rule = entry.get("allowable_rungs")
    if not isinstance(rule, Mapping) or rule.get("rule") not in ALLOWABLE_RULES:
        return False
    q = int(q256)
    low, high = (int(v) for v in rule["range_q256"])
    if not reader_accepts(q, low, high, int(rule["step_q256"])):
        return False
    if q in {int(v) for v in rule["excluded_q256"]}:
        return False
    try:
        rates = rung_rates(entry, q)
    except GrammarError:
        return False
    tables = {tuple(int(r) for r in t) for t in rule["run_tables"]}
    excluded = {tuple(int(r) for r in t) for t in rule["excluded_run_tables"]}
    return rates in tables and rates not in excluded


def derived_cell_run_tables(cell: Mapping[str, Any],
                            entry: Mapping[str, Any]) -> list[list[int]]:
    """The run tables a cell covers: those of its census rungs the family's
    rule admits, ascending.  Empty for a family with no rule."""
    if not isinstance(entry.get("allowable_rungs"), Mapping):
        return []
    tables = {rung_rates(entry, int(r)) for r in cell["rungs_q256"]
              if rung_allowable(entry, int(r))}
    return [list(t) for t in sorted(tables)]


def cell_covers_rung(cell: Mapping[str, Any], q256: int,
                     entry: "Mapping[str, Any] | None") -> bool:
    """Does ``cell`` cover rung ``q256``?  A census rung (``rungs_q256``)
    always; any other rung when the family's rule (``entry``, the cell
    family's ``formats[]`` row) admits it and its run table is one of the
    cell's ``run_tables``.  The one predicate the export gate, the census
    join and ``attested_by`` read, so a rung one of them covers the others
    cover too."""
    q = int(q256)
    if q in {int(r) for r in cell.get("rungs_q256") or ()}:
        return True
    tables = {tuple(int(r) for r in t) for t in cell.get("run_tables") or ()}
    if not tables or entry is None or not rung_allowable(entry, q):
        return False
    return rung_rates(entry, q) in tables


def format_entry(family: str, contract: "Mapping[str, Any] | None" = None
                 ) -> "Mapping[str, Any] | None":
    """The ``formats[]`` row of ``family`` in ``contract`` (the packaged one
    by default), or ``None``."""
    payload = cached_serving_contract() if contract is None else contract
    return next((e for e in payload["formats"] if e.get("family") == family), None)


def _run_table_list(value: Any, where: str, cap: int) -> list[tuple[int, ...]]:
    """A JSON list of run tables: each ``[r]`` or ``[r, r + 1]`` with rates in
    ``1..cap``, strictly ascending and distinct."""
    if not isinstance(value, list):
        raise ValueError(f"{where} must be a JSON array of run tables")
    out = []
    for i, table in enumerate(value):
        ok = (isinstance(table, list) and len(table) in (1, 2)
              and all(isinstance(r, int) and not isinstance(r, bool) for r in table)
              and 1 <= table[0] <= cap and (len(table) == 1 or table[1] == table[0] + 1)
              and table[-1] <= cap)
        if not ok:
            raise ValueError(
                f"{where}[{i}] is {table!r}; a run table is one column rate [r] or two adjacent "
                f"ones [r, r + 1] with rates in 1..{cap} (grammar.rate_set: a schedule mixes "
                "only the two rates bracketing its root)")
        out.append(tuple(table))
    if out != sorted(set(out)):
        raise ValueError(f"{where} must be strictly ascending and distinct, got {value!r}")
    return out


def _validate_allowable_rungs(entry: Mapping[str, Any], route: str, where: str) -> None:
    """The rule is well formed, inside the reader, and consistent with the
    per-rung stamps it generalises."""
    rule = entry["allowable_rungs"]
    at = f"{where}.allowable_rungs"
    _require_keys(rule, at, required=set(_ALLOWABLE_KEYS))
    if rule["rule"] not in ALLOWABLE_RULES:
        raise ValueError(
            f"{at}.rule is {rule['rule']!r}; this package defines {list(ALLOWABLE_RULES)}. "
            "A consumer evaluates the rule, so a rule nobody defined admits nothing.")
    low, high, step = _reader_rate(entry, where)
    rng, rstep = rule["range_q256"], rule["step_q256"]
    if (not isinstance(rng, list) or len(rng) != 2
            or not all(isinstance(v, int) and not isinstance(v, bool) for v in rng)
            or not isinstance(rstep, int) or isinstance(rstep, bool) or rstep < 1):
        raise ValueError(f"{at}: range_q256 is [low, high] and step_q256 a positive integer")
    if not (reader_accepts(rng[0], low, high, step) and reader_accepts(rng[1], low, high, step)
            and rng[0] <= rng[1] and rstep % step == 0):
        raise ValueError(
            f"{at}: range {rng} step {rstep} is not inside the reader's grid [{low}, {high}] "
            f"step {step}. An allowable rung is one the decoder reads.")
    ar, cap = _family_arity_cap(entry, where)
    if rule["code_arity"] != ar or isinstance(rule["code_arity"], bool):
        raise ValueError(
            f"{at}.code_arity is {rule['code_arity']!r}; grid {entry['grid']!r} codes {ar} "
            "weight(s) per code.  A reader resolves a rung to its run table as "
            "rate_set(q256 * code_arity / 256) without knowing the grid, so the field must "
            "be the grid's own arity.")
    tables = _run_table_list(rule["run_tables"], f"{at}.run_tables", cap)
    excluded = _run_table_list(rule["excluded_run_tables"], f"{at}.excluded_run_tables", cap)
    both = sorted(set(tables) & set(excluded))
    if both:
        raise ValueError(
            f"{at}: run table(s) {both} are both attested and excluded; a variant is allowed "
            "or excluded by its measured geometry, not both")
    ex_q = rule["excluded_q256"]
    if (not isinstance(ex_q, list) or ex_q != sorted(set(ex_q))
            or not all(isinstance(q, int) and reader_accepts(q, rng[0], rng[1], rstep)
                       for q in ex_q)):
        raise ValueError(
            f"{at}.excluded_q256 must be distinct ascending rungs of the rule's grid, got {ex_q!r}")
    reached = set()
    for q in range(rng[0], rng[1] + 1, rstep):
        reached.add(rung_rates(entry, q))
    unreached = sorted(set(tables) - reached)
    if unreached:
        raise ValueError(
            f"{at}.run_tables names {unreached}, which no rung of [{rng[0]}, {rng[1]}] step "
            f"{rstep} resolves to; a variant no rung reaches is attested for nothing")
    wire = rule["wire"]
    _require_keys(wire, f"{at}.wire", required=set(_WIRE_STAMP_KEYS))
    _validate_wire_stamp(wire, route, f"{at}.wire")
    for item in entry["attested_wire"]:
        if rung_allowable(entry, item["q256"]) and {k: item[k] for k in _WIRE_STAMP_KEYS} != dict(wire):
            raise ValueError(
                f"{at}.wire is {dict(wire)!r} but attested rung {item['q256']} is stamped "
                f"{ {k: item[k] for k in _WIRE_STAMP_KEYS}!r}. The rule says every allowable rung is "
                "cut on one wire; a census rung it covers cut on another means one of the two "
                "stamps describes bytes no fresh export writes.")
    evidence = rule["evidence"]
    if not isinstance(evidence, list) or not evidence:
        raise ValueError(f"{at}.evidence must name the oracle and sweep receipts")
    for i, path in enumerate(evidence):
        _require_repository_path(path, f"{at}.evidence[{i}]", "path")


#: ``(route, grid) -> (family, low, high, step)`` for the PACKAGED contract.
_PACKAGED_RATE_GRID: dict[tuple[str, str], tuple[str, int, int, int]] = {}


def _rate_grids(payload: Mapping[str, Any]) -> dict:
    out = {}
    for entry in payload["formats"]:
        route = _FAMILY_TO_ROUTE.get(entry["family"])
        if route is None:
            continue
        low, high, step = _reader_rate(entry, f"runtime_contract format {entry['family']}")
        out[(route, entry["grid"])] = (entry["family"], low, high, step)
    return out


def reader_rate_grid(route: str, grid: str, contract: Mapping[str, Any] | None = None):
    """``(family, low, high, step)`` for a (route, grid) pair, or ``None``.

    ``None`` is not "anything goes": it means this build publishes no decodable
    rate range for that pair, which the caller must treat as a refusal.  The
    ``TESSERA_NVFP4`` route holds two grids and the contract describes one of
    them, so resolving by route alone would hand an ``E2M1`` checkpoint the
    ``E2M1x2`` numbers.
    """
    if contract is None:
        # The gate runs once per Linear at load; re-reading and re-validating
        # the packaged file each time would put a file read on the load path
        # for no reason.  Only the packaged contract is cached -- a caller that
        # passes one in gets it read fresh, which is what the tests need.
        if not _PACKAGED_RATE_GRID:
            _PACKAGED_RATE_GRID.update(_rate_grids(load_serving_contract()))
        return _PACKAGED_RATE_GRID.get((route, grid))
    payload = contract
    for entry in payload["formats"]:
        if entry.get("grid") != grid:
            continue
        if _FAMILY_TO_ROUTE.get(entry["family"]) != route:
            continue
        low, high, step = _reader_rate(entry, f"runtime_contract format {entry['family']}")
        return entry["family"], low, high, step
    return None


def extension_lane(module_name_prefix: str, contract: Mapping[str, Any] | None = None) -> dict:
    """The ``lane`` block a native extension publishes, or raise.

    A lane is addressed by the extension's ``module_name_prefix`` because that
    is the string the load path itself asks ``cpp_extension.load`` for -- the
    one name a lane cannot be renamed behind.  Raises rather than returning
    ``None``: a caller asking about a lane this build does not publish has
    asked a question with no answer, and the honest outcome is a refusal, not
    an empty dict that reads like "no requirements".
    """
    payload = load_serving_contract() if contract is None else contract
    for entry in payload["native_extensions"]:
        if entry["module_name_prefix"] == module_name_prefix:
            return dict(entry["lane"])
    known = [e["module_name_prefix"] for e in payload["native_extensions"]]
    raise ValueError(
        f"this build publishes no native extension {module_name_prefix!r}, so it publishes no "
        f"lane for it. Known: {known}.")


def lane_decoder(module_name_prefix: str, contract: Mapping[str, Any] | None = None) -> str:
    """The ``telemetry`` decoder name a serve ON this lane stamps.

    Not the substitute's (``when_unavailable[mode].decoder``): this is what a
    census counts when it asks how many modules actually took the lane.
    """
    return extension_lane(module_name_prefix, contract)["decoder"]


def lane_requirements(module_name_prefix: str,
                      contract: Mapping[str, Any] | None = None) -> dict:
    """What a unit's wire must be for this lane to read it; ``{}`` if unstated.

    ``{}`` here means the lane publishes no predicate of its own -- its
    eligibility is the route's, already published in ``formats[]``.  The
    distinction between that and "the block exists and is empty" is enforced
    at contract load: an empty ``requires`` is refused.
    """
    return dict(extension_lane(module_name_prefix, contract).get("requires", {}))


#: How a cell's ``requires_serve_flags`` names a residency.  The env var is
#: ``lane.TESSERA_MODE_ENV``'s and the values are ``lane.MODES``'; the pipe is
#: an OR, so ``TESSERA_SERVE_MODE=resident|streamed`` is a cell that covers
#: both.  Parsed rather than pattern-matched because since schema v4 the
#: residency is a CONDITION on the cell, not decoration: two cells of one
#: ``(platform, family, structure, regime)`` are told apart by it.
_MODE_FLAG_SEPARATOR = "|"


def cell_residency_modes(cell: Mapping[str, Any],
                         where: str = "lane_eligibility cell") -> tuple[str, ...]:
    """The residencies a cell's serve flags select, as a value a gate reads.

    A ``lane_eligibility`` cell is scoped to a ``(platform, family, structure,
    regime)`` and, since v4, to a set of RESIDENCIES: the window-GEMV lane
    exists in ``streamed`` alone (both window routes set
    ``layer.tessera_gemv = None`` in ``resident``), so the decode regime of one
    family executes two different launches depending on this flag.  It was
    always in the cell -- as a string a reader had to pattern-match.  This is
    the same string, read.
    """
    from .lane import MODES, TESSERA_MODE_ENV

    head = f"{TESSERA_MODE_ENV}="
    named = [f for f in cell.get("requires_serve_flags", ()) if str(f).startswith(head)]
    if len(named) != 1:
        raise ValueError(
            f"{where}.requires_serve_flags must name exactly one {TESSERA_MODE_ENV} flag "
            f"(got {named!r}): the residency is the axis that decides which launch a regime "
            "makes, so a cell that does not scope itself to one cannot be resolved")
    modes = tuple(str(named[0])[len(head):].split(_MODE_FLAG_SEPARATOR))
    if not modes or len(set(modes)) != len(modes) or any(m not in MODES for m in modes):
        raise ValueError(
            f"{where}.requires_serve_flags names residencies {list(modes)}; they must be "
            f"distinct values of {list(MODES)} (tessera.serving.lane.MODES, the set "
            "lane.serve_mode gates on)")
    return modes


def _all_modes() -> tuple:
    """``lane.MODES``, imported lazily so this module stays torch-free to read."""
    from .lane import MODES

    return MODES


def cell_executes(cell: Mapping[str, Any]) -> set:
    """``{(symbol, decoder)}`` a cell publishes -- the census's own shape."""
    return {(str(e["symbol"]), str(e["decoder"])) for e in cell["executes"]}


def _is_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def cell_predicates(cell: Mapping[str, Any],
                    where: str = "lane_eligibility cell") -> tuple[tuple[str, str, Any], ...]:
    """The ``(fact, op, value)`` triples a cell's ``predicates`` states, or raise.

    The field was required on every cell and read by no line of this package
    (#134): a cell could carry ``["anything"]`` and validate, so the first
    gate to start reading it would have inherited unvalidated content.  This
    is the grammar, refused where the bytes are decided: a JSON array of
    closed ``{fact, op, value}`` objects, ``fact`` from
    :data:`CELL_PREDICATE_FACTS`, ``op`` from :data:`CELL_PREDICATE_OPS`, and
    ``value`` typed by the op -- ``in`` takes a non-empty list of scalars,
    ``multiple_of`` a positive integer (a consumer evaluates ``actual % value``
    and treats 0 as false), ``at_least``/``at_most`` an integer, ``equals`` a
    scalar.  One ``(fact, op)`` pair at most once: two ``at_least`` rows on one
    fact are one bound written twice, or two bounds disagreeing.
    """
    payload = cell.get("predicates")
    at = f"{where}.predicates"
    if not isinstance(payload, list):
        raise ValueError(
            f"{at} must be a JSON array of {{fact, op, value}} objects, got {payload!r}")
    out: list[tuple[str, str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for i, item in enumerate(payload):
        spot = f"{at}[{i}]"
        _require_keys(item, spot, required={"fact", "op", "value"})
        fact, op, value = item["fact"], item["op"], item["value"]
        if fact not in CELL_PREDICATE_FACTS:
            raise ValueError(
                f"{spot}.fact {fact!r} is not a structural fact a cell may predicate on; the "
                f"closed set is {list(CELL_PREDICATE_FACTS)}. A predicate a consumer cannot "
                "resolve is a cell it must refuse, never a rule it may skip.")
        if op not in CELL_PREDICATE_OPS:
            raise ValueError(
                f"{spot}.op {op!r} is not one of {list(CELL_PREDICATE_OPS)}")
        scalar = (str, int, float)
        if op == "in":
            if (not isinstance(value, list) or not value
                    or any(not isinstance(v, scalar) or isinstance(v, bool) for v in value)):
                raise ValueError(
                    f"{spot}: 'in' takes a non-empty list of scalars, got {value!r}")
        elif op == "multiple_of":
            if not _is_int(value) or value <= 0:
                raise ValueError(
                    f"{spot}: 'multiple_of' takes a positive integer, got {value!r}; a consumer "
                    "evaluates actual % value and a zero modulus holds for nothing")
        elif op in ("at_least", "at_most"):
            if not _is_int(value):
                raise ValueError(f"{spot}: {op!r} takes an integer, got {value!r}")
        elif not isinstance(value, scalar) or isinstance(value, bool):
            raise ValueError(f"{spot}: 'equals' takes a scalar, got {value!r}")
        if (fact, op) in seen:
            raise ValueError(
                f"{spot} repeats ({fact!r}, {op!r}); one bound per fact and op, or two bounds "
                "disagree about one cell")
        seen.add((fact, op))
        out.append((str(fact), str(op), value))
    return tuple(out)


def cell_is_device_backed(cell: Mapping[str, Any],
                          where: str = "lane_eligibility cell") -> bool:
    """Does this cell attest a SERVE, or only a toolchain fact?

    A cell states two facts that answer two questions: ``qualification`` says
    who ran it -- ``device_qualified``, or ``compile_only`` for a toolchain that
    only accepted the code -- and ``route_status`` says whether a serve exists
    at all, with ``unbacked`` as this document's word for no.  v10 (#456)
    already refuses the document that states the contradiction
    (``compile_only`` beside a backed status, because a compile receipt cannot
    carry a device's claim); this predicate is the reader's half of the same
    rule.  A reader resolving "what has this build SERVED" must select on both
    facts -- reading every cell of a ``(family, structure)`` pair as a receipt
    is how a platform's first compiled-but-unserved route would admit rungs no
    device ever ran.

    FAILS CLOSED.  A cell missing either field, or naming a value outside the
    closed sets :func:`validate_serving_contract` publishes, raises rather than
    returning ``False``.  "cannot tell" is not "not backed": a reader that
    quietly answered ``False`` would make an unreadable document
    indistinguishable from the weaker fact, and the difference between the two
    is the whole reason this predicate exists.  A caller reading a table the
    validator has not seen (a test's copy, a staged contract) therefore gets the
    answer the validator would give -- a refusal, by name.
    """
    qualification = cell.get("qualification")
    if qualification not in _QUALIFICATIONS:
        raise ValueError(
            f"{where} states qualification {qualification!r}, which is not one of "
            f"{sorted(_QUALIFICATIONS)}. A cell's qualification says whether a DEVICE ran "
            "the route; this build cannot read an unknown value as served or as not served, "
            "and guessing either way would answer a question the document did not.")
    route_status = cell.get("route_status")
    if route_status not in _ROUTE_STATUSES:
        raise ValueError(
            f"{where} states route_status {route_status!r}, which is not one of "
            f"{sorted(_ROUTE_STATUSES)}. Whether a serve exists is the fact a consumer "
            "selecting served cells reads, so a value outside the closed set is refused "
            "rather than counted on the served side or the unserved one.")
    return qualification == DEVICE_QUALIFICATION and route_status in BACKED_ROUTE_STATUSES


def refuse_unevaluated_predicates(cell: Mapping[str, Any],
                                  where: str = "lane_eligibility cell") -> None:
    """Refuse a cell that states a narrowing no consumer in this build reads.

    :func:`cell_predicates` is the grammar; nothing in this build EVALUATES
    it.  Every consumer of a cell selects by the keys a cell carries flat --
    ``scheme.attested_cells`` by family and structure (and through it
    ``refuse_unserveable_wire`` and the export gate), ``census.
    cell_launch_agreement`` by platform, structure, runtime scope, residency
    and rung -- and a predicate is precisely the part of a cell that none of
    those keys carries.  A cell narrowed to some units would therefore be
    read as covering all of them: the unconditional reading of a conditional
    cell, which is the exact failure the closed grammar was written to
    prevent ("a consumer that cannot resolve a predicate must refuse the
    cell, not skip the rule").

    So the refusal lives here, in the module that owns the grammar, and the
    day a consumer learns to evaluate a predicate it drops one call rather
    than leaving three readers that quietly did not.  It is not a ban on
    publishing a narrowed cell: it is the statement that publishing one is a
    consumer change, not a document change.
    """
    # A cell that does not carry the field states nothing: the validator
    # requires ``predicates`` on every published cell, so an absent one is a
    # hand-built or pre-#134 cell rather than a narrowing being smuggled past.
    # A present-but-malformed value still meets the grammar's own refusal.
    stated = cell_predicates(cell, where) if cell.get("predicates") else ()
    if stated:
        raise ValueError(
            f"{where} {cell.get('id')!r} states predicates {[list(row) for row in stated]}, "
            "and no consumer in this build evaluates them: cells are selected by family, "
            "structure, platform, runtime scope, residency and rung, none of which carries "
            "a predicate, so this cell would be read as covering every unit of its scope "
            "rather than the ones it narrows itself to. Teach the consumer to resolve the "
            "predicate through contract.cell_predicates before publishing one.")


def _require_receipt_path(value: Any, where: str) -> str:
    """A repository path under :data:`EVIDENCE_RECEIPT_ROOT`, or raise.

    The grammar only: the wheel does not ship docs, so whether the file exists
    is a tree test's business (``tests/test_cell_evidence.py``).
    """
    if (not isinstance(value, str) or not value.startswith(EVIDENCE_RECEIPT_ROOT)
            or len(value) == len(EVIDENCE_RECEIPT_ROOT)
            or any(part in ("", ".", "..") for part in value.split("/"))):
        raise ValueError(
            f"{where}.receipt must be a repository path under {EVIDENCE_RECEIPT_ROOT!r} "
            f"(the receipt that holds the number and its caveats), got {value!r}")
    return value


def derive_evidence_grade(cell: Mapping[str, Any]) -> str:
    """The grade a cell's ``evidence.kl`` entries DERIVE, from kinds alone.

    Every entry is in the cell's own regime (:func:`cell_evidence` refuses
    any other), so the derivation is: no entry, ``route_only`` -- the census
    attests dispatch and nothing attests quality in this regime; any top-K
    intersection bound, ``kl_lower_bound``; any full-vocabulary KL,
    ``kl_full_vocab``.  ``qualification`` is deliberately not overloaded
    with this: one home per fact.
    """
    kinds = {entry["kind"] for entry in cell["evidence"]["kl"]}
    if "full_vocab" in kinds:
        return "kl_full_vocab"
    if "topk_intersection_lower_bound" in kinds:
        return "kl_lower_bound"
    return "route_only"


def smoke_status_is_derived(smoke: Mapping[str, Any]) -> bool:
    """Whether this smoke's ``status`` is derived or ASSERTED (schema v9, #327).

    ``True`` when the smoke carries a ``record``, in which case
    :func:`derive_smoke_status` computes the word and the validator refuses any
    other.  ``False`` when ``record`` is ``null``: the word is one a person read
    off a receipt, nothing here can check it, and the header comment on
    :data:`EVIDENCE_SMOKE_RECORD_KEYS` says which cells are in that state and
    what would have to be measured to leave it.
    """
    return smoke.get("record") is not None


def derive_smoke_status(smoke: Mapping[str, Any]) -> str:
    """The status word a smoke's ``record`` DERIVES (schema v9, #327).

    The aggregation from a set of scored completions to the cell's one
    published word, in its only home.  Each row is one (prompt, form) pair
    already scored under the instrument's per-completion rule, on this cell's
    arm and -- when a reference arm was run -- on the reference:

    * some row cycles on this arm and the reference does not: ``repetitive``.
      A degeneration the reference does not share is this route's, and that is
      what the word claims.
    * else some row reads ``recorded`` on this arm and on the reference (on
      this arm alone when there is no reference): ``recorded``.  That is the
      positive record principle 5's "generates correctly" leg asks for.
    * else some row cycles: ``repetitive``.  Every cycle is shared, but nothing
      positive was recorded, so there is no record to publish.
    * else ``not_recorded``: nothing came back.

    A row whose arm reads ``recorded`` while the reference cycles is neither: the
    route is not degenerating and the pair is not a two-arm positive record.
    An empty completion scores ``not_recorded`` at the instrument
    (``experiments/moe_greedy_smoke.py``), so it can never be or create one.

    With no record there is no derivation: the smoke's own asserted ``status``
    is returned unchanged, and :func:`smoke_status_is_derived` is how a caller
    tells that case apart rather than reading a word back from itself.
    """
    record = smoke.get("record")
    if record is None:
        return smoke.get("status")
    reference = record.get("reference")
    positive = unshared = cycled = False
    for row in record.get("rows") or []:
        status, against = row.get("status"), row.get("reference_status")
        if status == "recorded" and (reference is None or against == "recorded"):
            positive = True
        elif status == "repetitive":
            cycled = True
            if reference is None or against != "repetitive":
                unshared = True
    if unshared:
        return "repetitive"
    if positive:
        return "recorded"
    return "repetitive" if cycled else "not_recorded"


def derive_smoke_attribution(smoke: Mapping[str, Any]) -> str:
    """What a smoke's ``record`` -- or, without one, its ``control`` -- DERIVES
    about where the symptom lives.

    No reference arm, ``unattributed`` -- nobody ran one, so the status is an
    observation and not an attribution.  A reference that shares every cycle,
    ``shared_with_reference``: the model and the prompt produce it, not this
    route.  One that does not share some cycle, ``not_shared_with_reference``:
    the reference does not explain it, which is weaker than "the route is at
    fault" and is deliberately not spelled that way.  A record with a reference
    arm and no cycle anywhere is ``unattributed`` too: there is no symptom to
    attribute.

    Schema v9 moves the source from ``control`` to ``record`` for a smoke that
    carries one, and the two may not both be present (:func:`cell_evidence`
    refuses that by name): one derivation, one home.  The v7 ``control`` branch
    below is unchanged and is what a smoke with no record still reads.
    """
    if smoke.get("record") is not None:
        record = smoke["record"]
        if record.get("reference") is None:
            return "unattributed"
        cycles = [row for row in (record.get("rows") or [])
                  if row.get("status") == "repetitive"]
        if not cycles:
            return "unattributed"
        if all(row.get("reference_status") == "repetitive" for row in cycles):
            return "shared_with_reference"
        return "not_shared_with_reference"
    control = smoke.get("control")
    if control is None:
        return "unattributed"
    if control.get("outcome") == "identical_completion":
        return "shared_with_reference"
    return "not_shared_with_reference"


def _require_repository_path(value: Any, where: str, field: str) -> str:
    """A path inside this repository, or raise.

    Not under ``docs/measurements/`` -- an instrument is code, not a receipt --
    but under the same rule ``test_contract_is_portable.py`` reads the document
    by: relative, no traversal, and it must resolve in the checkout.
    """
    if (not isinstance(value, str) or not value or value.startswith("/")
            or "\\" in value or any(c.isspace() for c in value)
            or any(part in ("", ".", "..") for part in value.split("/"))):
        raise ValueError(
            f"{where}.{field} must be a repository path to the code that owns the rule "
            f"(relative, no traversal), got {value!r}")
    return value


def _evidence_smoke_record(payload: Any, where: str, control: Any,
                           smoke_at: str) -> dict[str, Any] | None:
    """The per-(prompt, form) scoring a smoke's word is DERIVED from (v9, #327).

    ``null`` when the smoke has no machine-readable record and its ``status`` is
    therefore ASSERTED (see :data:`EVIDENCE_SMOKE_RECORD_KEYS`).  Otherwise the
    closed ``{instrument, rule, reference, rows}``: ``instrument`` the
    repository path to the code that owns the per-completion rule, ``rule`` that
    code's own statement of it quoted verbatim so the rule is readable at the
    pin (the wheel does not ship ``experiments/``; a tree test pins the two
    equal), ``reference`` the arm the completions were compared against or
    ``null``, and ``rows`` a non-empty set of distinct (prompt, form) pairs.
    """
    if payload is None:
        return None
    if control is not None:
        raise ValueError(
            f"{smoke_at} carries BOTH a control and a record; the attribution is derived from "
            "one of them, and two homes for one derivation is exactly how they drift. A record "
            "names its reference arm and every row's verdict on it, so it says everything the "
            "v7 control says and says it per (prompt, form): drop the control")
    _require_keys(payload, where, required=set(EVIDENCE_SMOKE_RECORD_KEYS))
    _require_repository_path(payload["instrument"], where, "instrument")
    rule = payload["rule"]
    if not isinstance(rule, str) or not rule.strip():
        raise ValueError(
            f"{where}.rule must state the per-completion rule the rows were scored under, "
            f"verbatim from the instrument, got {rule!r}")
    reference = payload["reference"]
    if reference is not None and reference not in EVIDENCE_CONTROL_REFERENCES:
        raise ValueError(
            f"{where}.reference {reference!r} is not one of {list(EVIDENCE_CONTROL_REFERENCES)}; "
            "a reference this package cannot name is prose, and the whole point of the record "
            "is that a gate reads it")
    rows = payload["rows"]
    if not isinstance(rows, list) or not rows or any(not isinstance(r, Mapping) for r in rows):
        raise ValueError(
            f"{where}.rows must be a non-empty JSON array of {{prompt, form, interface, status, "
            f"reference_status}} objects; a record with no row scores nothing, got {rows!r}")
    seen: set[tuple[str, str]] = set()
    parsed_rows = []
    for i, row in enumerate(rows):
        spot = f"{where}.rows[{i}]"
        _require_keys(row, spot, required=set(EVIDENCE_SMOKE_ROW_KEYS))
        prompt = row["prompt"]
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError(f"{spot}.prompt must name the prompt the receipt names, "
                             f"got {prompt!r}")
        form, interface = row["form"], row["interface"]
        if form not in EVIDENCE_SMOKE_FORMS:
            raise ValueError(f"{spot}.form {form!r} is not one of {list(EVIDENCE_SMOKE_FORMS)}")
        if interface not in EVIDENCE_SMOKE_INTERFACES:
            raise ValueError(
                f"{spot}.interface {interface!r} is not one of {list(EVIDENCE_SMOKE_INTERFACES)}; "
                "the interface a prompt exercised is what separates a raw continuation from the "
                "checkpoint's own chat template, and a reader cannot infer it from the prompt id")
        status = row["status"]
        if status not in EVIDENCE_SMOKE_STATUSES:
            raise ValueError(
                f"{spot}.status {status!r} is not one of {list(EVIDENCE_SMOKE_STATUSES)}")
        against = row["reference_status"]
        if reference is None:
            if against is not None:
                raise ValueError(
                    f"{spot}.reference_status is {against!r} but the record names no reference "
                    "arm; a verdict on an arm nobody ran is a claim without a measurement")
        elif against not in EVIDENCE_SMOKE_STATUSES:
            raise ValueError(
                f"{spot}.reference_status {against!r} is not one of "
                f"{list(EVIDENCE_SMOKE_STATUSES)}; the record names reference {reference!r}, so "
                "every row states what that arm returned for the same (prompt, form)")
        key = (prompt, form)
        if key in seen:
            raise ValueError(
                f"{spot} repeats (prompt, form) {key}; the rows are a set of pairs, and a "
                "duplicate would weight one completion twice in the aggregation")
        seen.add(key)
        parsed_rows.append({"prompt": prompt, "form": form, "interface": interface,
                            "status": status, "reference_status": against})
    return {"instrument": payload["instrument"], "rule": rule,
            "reference": reference, "rows": parsed_rows}


def _evidence_artifact(payload: Any, where: str) -> dict[str, Any] | None:
    """A historical artifact and a scoped re-encode screen, or no record.

    Null means no encoder-reproduction evidence was recorded. It does not
    mean the current encoder reproduces any of the cell's served artifacts.
    A non-null record describes only the named commit and unit; it is not an
    assertion about every unit or about whatever encoder a future tag ships.
    """
    if payload is None:
        return None
    _require_keys(payload, where, required={"id", "encoder_commit", "reencode"})
    artifact_id = payload["id"]
    if (not isinstance(artifact_id, str) or not artifact_id
            or "\\" in artifact_id or any(c.isspace() for c in artifact_id)
            or any(p in ("", ".", "..") for p in artifact_id.split("/"))):
        raise ValueError(f"{where}.id must be a portable relative artifact identifier")
    reencode = payload["reencode"]
    spot = f"{where}.reencode"
    _require_keys(reencode, spot, required={
        "encoder_commit", "unit", "payload", "metric", "weight_error", "receipt"})
    for record, at in ((payload, where), (reencode, spot)):
        commit = record["encoder_commit"]
        if not isinstance(commit, str) or re.fullmatch(r"[0-9a-f]{40}", commit) is None:
            raise ValueError(f"{at}.encoder_commit must be a full lowercase Git SHA-1")
    unit = reencode["unit"]
    if not isinstance(unit, str) or not unit.strip():
        raise ValueError(f"{spot}.unit must name the single unit compared")
    if reencode["payload"] not in EVIDENCE_PAYLOAD_RELATIONS:
        raise ValueError(f"{spot}.payload must be one of {EVIDENCE_PAYLOAD_RELATIONS}")
    if reencode["metric"] != "weight_sse":
        raise ValueError(f"{spot}.metric must be 'weight_sse'; this screen is not served KL")
    if reencode["weight_error"] not in EVIDENCE_WEIGHT_ERROR_RELATIONS:
        raise ValueError(f"{spot}.weight_error must be one of {EVIDENCE_WEIGHT_ERROR_RELATIONS}")
    if reencode["payload"] == "identical" and reencode["weight_error"] != "equal":
        raise ValueError(f"{spot}.weight_error must be 'equal' for an identical payload")
    _require_receipt_path(reencode["receipt"], spot)
    return {"id": artifact_id, "encoder_commit": payload["encoder_commit"],
            "reencode": dict(reencode)}


def cell_evidence(cell: Mapping[str, Any], where: str = "lane_eligibility cell",
                  regimes: Any = None) -> dict[str, Any]:
    """The parsed ``evidence`` a cell states, or raise (#133).

    Closed at every level -- a prose ``detail`` beside the entries is exactly
    the field a gate cannot read.  ``kl`` entries are ``{kind, top_k, regime,
    execution_modes, receipt}``: ``kind`` from :data:`EVIDENCE_KL_KINDS`,
    ``top_k`` a positive integer for a top-K bound and ``null`` for a
    full-vocabulary KL, ``regime`` the CELL'S OWN regime (a prefill bound
    written into a decode cell is the confusion this field exists to refuse),
    ``execution_modes`` a non-empty distinct subset of the cell's, ``receipt``
    a repository path. A ``kl`` entry may stamp the rung its receipt measured
    in ``q256`` -- a KL bound scored at one rung bounds nothing at another --
    and when it does the rung must be one the cell publishes. ``smoke`` is
    ``{status, receipt, attribution, control}`` with ``status``
    from :data:`EVIDENCE_SMOKE_STATUSES` and a receipt exactly when a smoke
    was recorded. ``artifact`` is null when no encoder comparison was
    recorded, otherwise the historical artifact and its single-unit screen.
    It never contributes to ``grade``, which must equal
    :func:`derive_evidence_grade`.
    """
    payload = cell.get("evidence")
    at = f"{where}.evidence"
    _require_keys(payload, at, required={"grade", "kl", "smoke", "artifact"})
    artifact = _evidence_artifact(payload["artifact"], f"{at}.artifact")
    grade = payload["grade"]
    if grade not in EVIDENCE_GRADES:
        raise ValueError(f"{at}.grade {grade!r} is not one of {list(EVIDENCE_GRADES)}")
    entries = payload["kl"]
    if not isinstance(entries, list) or any(not isinstance(e, Mapping) for e in entries):
        raise ValueError(
            f"{at}.kl must be a JSON array of {{kind, top_k, regime, execution_modes, receipt}} "
            f"objects, got {entries!r}")
    cell_modes = None
    if "runtime" in cell:
        _, cell_modes = cell_runtime_scope(cell, where)
    cell_regime = cell.get("regime")
    seen: set[tuple] = set()
    parsed_kl = []
    for i, entry in enumerate(entries):
        spot = f"{at}.kl[{i}]"
        _require_keys(entry, spot,
                      required={"kind", "top_k", "regime", "execution_modes", "receipt"},
                      optional={"q256"})
        kind = entry["kind"]
        if kind not in EVIDENCE_KL_KINDS:
            raise ValueError(f"{spot}.kind {kind!r} is not one of {list(EVIDENCE_KL_KINDS)}")
        top_k = entry["top_k"]
        if kind == "topk_intersection_lower_bound":
            if not _is_int(top_k) or top_k <= 0:
                raise ValueError(
                    f"{spot}.top_k must be a positive integer for a top-K intersection bound, "
                    f"got {top_k!r}")
        elif top_k is not None:
            raise ValueError(
                f"{spot}.top_k must be null for a full-vocabulary KL, got {top_k!r}")
        regime = entry["regime"]
        if regimes is not None and regime not in regimes:
            raise ValueError(
                f"{spot}.regime {regime!r} is not a declared regime {sorted(regimes)} "
                "(the contract's own word, not the census phase name)")
        if cell_regime is not None and regime != cell_regime:
            raise ValueError(
                f"{spot}.regime {regime!r} is not the cell's regime {cell_regime!r}: a bound "
                "scored in another regime is another cell's evidence, and reading it here is "
                "how a prefill number came to stand in for decode quality")
        modes = entry["execution_modes"]
        if (not isinstance(modes, list) or not modes
                or any(not isinstance(m, str) or m not in EXECUTION_MODES for m in modes)
                or len(set(modes)) != len(modes)):
            raise ValueError(
                f"{spot}.execution_modes must be a non-empty list of distinct modes from "
                f"{list(EXECUTION_MODES)}, got {modes!r}")
        if cell_modes is not None:
            outside = sorted(set(modes) - set(cell_modes))
            if outside:
                raise ValueError(
                    f"{spot} claims execution_modes {outside} the cell does not cover "
                    f"({list(cell_modes)}); a KL under a mode the census never joined attests "
                    "a runtime this cell does not scope")
        receipt = _require_receipt_path(entry["receipt"], spot)
        stamp = entry.get("q256")
        if stamp is not None:
            # The rung the receipt measured, travelling with the entry: a top-K
            # intersection bound is rate-dependent, so a stamp outside the
            # cell's own rungs claims a measurement the cell does not publish.
            if not _is_int(stamp) or int(stamp) <= 0:
                raise ValueError(
                    f"{spot}.q256 must be a positive integer rung when present, "
                    f"got {stamp!r}")
            published = [int(r) for r in (cell.get("rungs_q256") or [])]
            if int(stamp) not in published:
                raise ValueError(
                    f"{spot}.q256={int(stamp)} is not one of the rungs this cell "
                    f"publishes ({sorted(published)}): a KL scored at a rung the "
                    "cell does not name bounds nothing the cell serves")
            stamp = int(stamp)
        key = (kind, top_k, regime, tuple(sorted(modes)), receipt, stamp)
        if key in seen:
            raise ValueError(f"{spot} repeats an entry; the field is a set of receipts")
        seen.add(key)
        parsed = {"kind": kind, "top_k": top_k, "regime": regime,
                  "execution_modes": list(modes), "receipt": receipt}
        if stamp is not None:
            parsed["q256"] = stamp
        parsed_kl.append(parsed)
    smoke = payload["smoke"]
    _require_keys(smoke, f"{at}.smoke",
                  required={"status", "receipt", "attribution", "control", "record"})
    status = smoke["status"]
    if status not in EVIDENCE_SMOKE_STATUSES:
        raise ValueError(
            f"{at}.smoke.status {status!r} is not one of {list(EVIDENCE_SMOKE_STATUSES)}")
    control = smoke["control"]
    if status == "not_recorded":
        if smoke["receipt"] is not None:
            raise ValueError(
                f"{at}.smoke: status not_recorded names a receipt {smoke['receipt']!r}; a "
                "receipt is where a recorded smoke lives, so one here says the status is wrong")
        if control is not None:
            raise ValueError(
                f"{at}.smoke: status not_recorded names a control {control!r}; no completion "
                "came back, so there is nothing for a reference to have matched")
        smoke_receipt = None
    else:
        if smoke["receipt"] is None:
            raise ValueError(
                f"{at}.smoke: status {status!r} names no receipt; a smoke nobody recorded "
                "is not_recorded")
        smoke_receipt = _require_receipt_path(smoke["receipt"], f"{at}.smoke")
    parsed_control = None
    if control is not None:
        spot = f"{at}.smoke.control"
        _require_keys(control, spot, required=set(EVIDENCE_CONTROL_KEYS))
        reference, outcome = control["reference"], control["outcome"]
        if reference not in EVIDENCE_CONTROL_REFERENCES:
            raise ValueError(
                f"{spot}.reference {reference!r} is not one of "
                f"{list(EVIDENCE_CONTROL_REFERENCES)}; a reference this package cannot name is "
                "prose, and the whole point of the control is that a gate reads it")
        if outcome not in EVIDENCE_CONTROL_OUTCOMES:
            raise ValueError(
                f"{spot}.outcome {outcome!r} is not one of {list(EVIDENCE_CONTROL_OUTCOMES)}")
        parsed_control = {"reference": reference, "outcome": outcome,
                          "receipt": _require_receipt_path(control["receipt"], spot)}
    parsed_record = _evidence_smoke_record(
        smoke["record"], f"{at}.smoke.record", parsed_control, f"{at}.smoke")
    attribution = smoke["attribution"]
    if attribution not in EVIDENCE_SMOKE_ATTRIBUTIONS:
        raise ValueError(
            f"{at}.smoke.attribution {attribution!r} is not one of "
            f"{list(EVIDENCE_SMOKE_ATTRIBUTIONS)}")
    read_from = {"control": parsed_control, "record": parsed_record}
    derived_attribution = derive_smoke_attribution(read_from)
    if attribution != derived_attribution:
        source = "record" if parsed_record is not None else "control"
        raise ValueError(
            f"{at}.smoke.attribution is {attribution!r} but its {source} derives "
            f"{derived_attribution!r}; the attribution is read off the {source}, never asserted "
            "beside it")
    if parsed_record is not None:
        derived_status = derive_smoke_status({"status": status, "record": parsed_record})
        if status != derived_status:
            raise ValueError(
                f"{at}.smoke.status is {status!r} but its record derives {derived_status!r}; "
                "the status is the aggregation of the rows, read off them exactly as grade is "
                "read off the kl entries and never asserted beside them "
                "(contract.derive_smoke_status is where the aggregation lives)")
    derived = derive_evidence_grade({"evidence": {"kl": parsed_kl}})
    if grade != derived:
        raise ValueError(
            f"{at}.grade is {grade!r} but its kl entries derive {derived!r}; the grade is read "
            "off the entries, never asserted beside them")
    return {"grade": grade, "kl": parsed_kl, "artifact": artifact,
            "smoke": {"status": status, "receipt": smoke_receipt,
                      "attribution": attribution, "control": parsed_control,
                      "record": parsed_record}}


def _lanes_a_rung_reaches(route: str, contract: Mapping[str, Any], wire: Mapping[str, Any],
                          rates: "tuple[int, ...]", grid: str, structure: str) -> tuple[str, ...]:
    """Which of ``route``'s extension lanes can read a rung, by the published predicate.

    The predicate is the one the extension itself publishes at
    ``native_extensions[].lane.requires``, decided by the ONE decision core
    every gate runs (``scheme.decide_lane_requirements``, #264) over the
    facts an attested wire stamp states.  A stamp is the pinned whole wire
    -- rotation, diagonals, RELEASE overrides and a shard start state are
    not representable in it -- so those facts are the pinned values, and the
    grid's arity comes off the family's own grid (``grid``, the formats
    row's name, resolved through ``tessera.alphabet``).  The numeric fields
    are tied to ``kernel_window_gemv``'s own constants by
    ``tests/test_lane_reachability.py``, so a cell whose ``executes`` names
    a lane launch is bound to the kernel transitively, and the day the
    kernel drops a rate the contract stops validating.  ``structure`` is the
    cell's: a lane may publish a rate set its routed-expert launch reaches
    that is narrower than what it reads (``column_rates_routed_moe``,
    tessera#694), and the decision core decides it against the structure.
    """
    from ..alphabet import SERIALISABLE_GRIDS
    from .scheme import decide_lane_requirements

    arities = {g.name: int(g.arity) for g in SERIALISABLE_GRIDS.values()}
    if grid not in arities:
        raise ValueError(
            f"formats grid {grid!r} names no serialisable grid this package holds "
            f"({sorted(arities)}); a rung's lane reachability cannot be derived for it")
    facts = {
        "rates": tuple(int(r) for r in rates),
        "window_bits": int(wire["window_bits"]),
        "body": route_wire_spelling("body", str(wire["body"])),
        "plane": route_wire_spelling("plane", str(wire["plane"])),
        "release_overrides": 0, "diagonals": False, "start_state": False,
        "rotation": "NONE", "grid_arity": arities[grid],
        "structure": str(structure),
    }
    out = []
    for entry in contract["native_extensions"]:
        lane = entry.get("lane")
        if not lane or route not in entry.get("routes", ()):
            continue
        requires = lane.get("requires") or {}
        # No predicate published means the lane's eligibility is the route's
        # own (formats[]), so every rung of its routes reaches it.
        if requires and decide_lane_requirements(
                entry["module_name_prefix"], requires, facts):
            continue
        out.append(entry["module_name_prefix"])
    return tuple(out)


def derive_cell_executes(cell: Mapping[str, Any], route: str, entry: Mapping[str, Any],
                         contract: Mapping[str, Any], where: str = "cell") -> set:
    """The launch pairs a cell's axes make: the value ``executes`` must equal.

    ``entry`` is the family's ``formats[]`` row and ``route`` its ``scheme.ROUTES``
    key.  This is ``_validate_cell_executes``'s derivation on its own, so a
    fixture that moves a cell onto another rung states the launches the
    validator will demand instead of restating the lane arithmetic by hand
    (a hand restatement with ``lanes=()`` went stale the day the E4M3
    instruction's lane reached every rate, contract v47).
    """
    from .scheme import launch_pairs

    wires = {int(w["q256"]): w for w in entry["attested_wire"]}
    # The family's own published terminal rate, so a rung above what this
    # family can encode raises here rather than resolving to a rate set.
    # The cell rungs are per WEIGHT and the bresenham schedule is per CODE: a
    # code covers ``arity`` weights (export.encode_linear_planes writes
    # ``q256 * grid.arity``; scheme._per_weight_q256 reads it back), so both
    # the cap and the rung resolve onto the per-code root (``rung_rates``).
    # Resolving the per-weight rung directly broke at the shaped domain's
    # floor: an arity-2 rung below q256 256 is a full unit at rate 1 per code,
    # not the sub-1-per-column rate rate_set would have to refuse.  The run
    # tables a v11 cell covers beyond its census rungs are each some census
    # rung's (``derived_cell_run_tables``), and a lane's reach is a function
    # of the rates and the wire facts only, so deriving over the census rungs
    # derives over every rung the cell covers.
    _family_arity_cap(entry, where)
    modes = cell_residency_modes(cell, where)
    want: set = set()
    for rung in cell["rungs_q256"]:
        rates = rung_rates(entry, int(rung))
        lanes = _lanes_a_rung_reaches(route, contract, wires[int(rung)], rates,
                                      str(entry["grid"]), str(cell["structure"]))
        for mode in modes:
            want |= launch_pairs(route, structure=cell["structure"],
                                 regime=cell["regime"], mode=mode, lanes=lanes)
    return want


def _validate_cell_executes(cell: Mapping[str, Any], route: str, entry: Mapping[str, Any],
                            contract: Mapping[str, Any], where: str) -> None:
    """``executes`` must BE the launches this build makes, not agree with them.

    Principle 14 applied to the launch: until schema v4 a cell said which A-side
    contract ran and which rungs a receipt covered, and the only place the
    LAUNCH appeared was the cell's ``id`` -- so the contract's machine-readable
    answer to "what does an E4M3 decode execute" was the materialised FP8 pair
    in every case, which stopped being true the moment an artifact at a
    lane-readable rung was served (#111).  The value is derived here from
    ``scheme.ROUTE_LAUNCHES``, the table the routes' own ``census_expected``
    is built from, narrowed by exactly the axes the cell already carries: the
    structure, regime, the residency its serve flag names, and the lanes each of its
    rungs can reach.
    """
    # The per-code root, the family cap and the covered run tables are
    # derive_cell_executes's; this compares.
    want = derive_cell_executes(cell, route, entry, contract, where)
    modes = cell_residency_modes(cell, where)
    got = cell_executes(cell)
    if got != want:
        raise ValueError(
            f"{where}.executes is {sorted(got)} but the {route} route makes "
            f"{sorted(want)} for structure {cell['structure']!r} in the "
            f"{cell['regime']!r} regime at residency {list(modes)} "
            f"on rung(s) {list(cell['rungs_q256'])} (tessera.serving.scheme.ROUTE_LAUNCHES, "
            "the table the routes' own census_expected is derived from). A cell states what "
            "the runtime EXECUTES; it is derived from the dispatch's table or it is a claim "
            "about a runtime nobody read.")


#: ``formats[]`` family -> the ``scheme.ROUTES`` key that serves it.  Two names
#: for one thing, and they are deliberately different: the contract's family is
#: a PAYLOAD name a producer prices (grid + arity), the route key is what the
#: tile IS on the hardware.
_FAMILY_TO_ROUTE = {
    "TESSERA_E2M1_K2": "TESSERA_NVFP4",
    "TESSERA_E4M3_K1": "TESSERA_FP8",
    "TESSERA_BF16_K1": "TESSERA_BF16",
}

#: The inverse, and it is a map a CONSUMER needs: a route record's ``policy``
#: names the ROUTE (``TESSERA_FP8:streamed``) while a ``lane_eligibility``
#: cell names the PAYLOAD FAMILY (``TESSERA_E4M3_K1``), so joining a served
#: record to the cell that covers it goes through here rather than through a
#: second table in the tool.  Derived, and asserted injective at import: the
#: day one route publishes two families, this map stops being the join and a
#: caller must say which family it means.
PAYLOAD_FAMILY_BY_ROUTE = {route: family for family, route in _FAMILY_TO_ROUTE.items()}
assert len(PAYLOAD_FAMILY_BY_ROUTE) == len(_FAMILY_TO_ROUTE), (
    "two payload families share a route, so route -> family is no longer a join")

#: What this document says about one ``(platform, family)`` pair, as three
#: states a caller can branch on rather than a boolean it must interpret.
#:
#: The distinction that matters is between a document that SAYS a platform
#: does not execute a family and a document that says nothing about it at all.
#: A null ``executes`` entry is an attestation -- somebody looked and the
#: route is not there -- and a refusal is the correct answer.  A platform the
#: table does not mention, or a contract written before the platform axis
#: existed, has attested nothing; refusing there would turn a silence into a
#: claim about a runtime nobody read, which is the opposite of principle "a
#: claim about another runtime is attested, never asserted".  So ``unstated``
#: is NOT a refusal, and every caller must spell that out for itself.
PLATFORM_BACKED = "backed"
PLATFORM_UNBACKED = "unbacked"
PLATFORM_UNSTATED = "unstated"
PLATFORM_BACKING_STATES = (PLATFORM_BACKED, PLATFORM_UNBACKED, PLATFORM_UNSTATED)


def platform_execution_contract(family: str, platform: str,
                                contract: Mapping[str, Any] | None = None
                                ) -> tuple[str, str | None]:
    """What ``platform`` executes for ``family``: a state and its contract.

    Returns ``(state, activation_contract)`` where ``state`` is one of
    :data:`PLATFORM_BACKING_STATES`:

    * ``backed`` -- the platform's ``executes`` entry names an activation
      contract, and it is that route's own constant.  The contract string is
      returned beside it so a caller can stamp what it was told rather than
      re-derive it.
    * ``unbacked`` -- the entry is present and null.  The platform is declared
      and this family is attested as having no native route on it.
    * ``unstated`` -- the platform is not declared, or the platform entry
      carries no ``executes`` key (every contract before the platform axis,
      i.e. ``contract_version`` 22 and earlier).  Nothing is attested either
      way; the contract is ``None``.

    The read is deliberately tolerant of a malformed table: this is consulted
    on a model-load hot path, and the document's SHAPE is validated once, by
    ``validate_serving_contract``, not again on every Linear.  A table that
    cannot be read the way this expects yields ``unstated`` -- the state that
    changes no behaviour -- and the validator is what refuses it.
    """
    if family not in _FAMILY_TO_ROUTE:
        raise KeyError(
            f"{family!r} is not a payload family this contract publishes; "
            f"known: {sorted(_FAMILY_TO_ROUTE)}")
    if contract is None:
        contract = cached_serving_contract()
    platforms = contract.get("lane_eligibility", {}).get("platforms", {})
    if not isinstance(platforms, Mapping):
        return PLATFORM_UNSTATED, None
    entry = platforms.get(platform)
    if not isinstance(entry, Mapping) or "executes" not in entry:
        return PLATFORM_UNSTATED, None
    executes = entry["executes"]
    if not isinstance(executes, Mapping) or family not in executes:
        return PLATFORM_UNSTATED, None
    value = executes[family]
    if value is None:
        return PLATFORM_UNBACKED, None
    return PLATFORM_BACKED, value


def platform_backs(family: str, platform: str,
                   contract: Mapping[str, Any] | None = None) -> bool:
    """Whether this document REFUSES ``family`` on ``platform``.

    ``False`` only for the attested ``unbacked``.  ``unstated`` is ``True``:
    a silence is not a refusal, and a caller that collapsed it to ``False``
    would refuse every platform the table has not reached yet -- which on
    ``contract_version`` 22 is every platform there is.
    """
    state, _ = platform_execution_contract(family, platform, contract)
    return state != PLATFORM_UNBACKED

#: The checkpoint's spelling of a body/plane beside the route's spelling of
#: the same fact.  ``attested_wire`` speaks ``wire.recipes`` -- the
#: vocabulary a checkpoint's config records per rung
#: (``export._BODY_NAMES`` / ``export._PLANE_NAMES``) -- while the authority
#: it is checked against speaks ``scheme.ROUTES``.  The map between the two
#: dialects is written once here, and
#: ``tests/test_serving_attested_wire.py`` compares both ends against their
#: sources, so a rename on either side fails there rather than drifting here.
_ATTESTED_WIRE_BODY = {"tcq": "TCQ", "window": "WINDOW"}
_ATTESTED_WIRE_PLANE = {"s6b": "S6B", "lut16": "LUT", "channel": "CHANNEL"}
#: ``manifest.RotationState`` names, in the checkpoint dialect a lane
#: predicate speaks (``lane.requires.rotation``, #264).
_ATTESTED_WIRE_ROTATION = {"none": "NONE", "r_in_only": "R_IN_ONLY"}


def route_wire_spelling(field: str, value: str) -> str:
    """``scheme.ROUTES``' spelling of a checkpoint-dialect wire fact name.

    The contract states a wire in the vocabulary a checkpoint's own config
    records (``window``, ``channel``, ``none``); the tables a loader gates on
    spell the same facts ``WINDOW``, ``CHANNEL`` and ``RotationState.NONE``.
    One map, the one ``attested_wire`` already uses for body and plane, so a
    caller comparing a recipe against a published predicate does not carry a
    second copy of it.
    """
    dialect = {"body": _ATTESTED_WIRE_BODY, "plane": _ATTESTED_WIRE_PLANE,
               "rotation": _ATTESTED_WIRE_ROTATION}.get(field)
    if dialect is None:
        raise ValueError(
            f"no wire dialect for field {field!r}; known: ['body', 'plane', 'rotation']")
    if value not in dialect:
        raise ValueError(f"{value!r} is not a {field} this package names ({sorted(dialect)})")
    return dialect[value]


def _validate_attested_wire(entry: Mapping[str, Any], route: str, where: str) -> None:
    """``attested_wire`` must be the wire each attested rung was cut on (#55).

    Checked in two halves, because they are two different claims.  COVERAGE:
    exactly one entry per rung in ``attested_rungs_q256`` -- a stamp that
    forgot a rung leaves bytes undescribed, and one that names a rung the
    family does not attest describes nothing.  SUBSTANCE: a body/span/plane
    the route decodes, read off ``scheme.ROUTES`` -- the table the loader
    itself gates on -- so a stamp no decoder in this build would read is a
    refusal here rather than a receipt for bytes that cannot serve.  The
    spreads (``sigma``/``channel_sigma``) are typed -- a number, or null for
    the pinned wire -- but not re-derived: they transcribe the receipt, and
    the receipt is prose.  What keeps the transcription honest is the
    tripwire in ``tests/test_serving_attested_wire.py``, which compares every
    stamp against what the exporter writes at that rung today.
    """
    stamped = entry["attested_wire"]
    if not isinstance(stamped, list):
        raise ValueError(
            f"{where}.attested_wire must be a JSON array, one entry per attested rung")
    rungs = entry["attested_rungs_q256"]
    for i, item in enumerate(stamped):
        at = f"{where}.attested_wire[{i}]"
        _require_keys(item, at,
                      required={"q256", "body", "span", "plane",
                                "window_bits", "seed", "sigma", "channel_sigma"})
        q256 = item["q256"]
        if not isinstance(q256, int) or q256 not in set(rungs):
            raise ValueError(
                f"{at}.q256 is {q256!r}, which {entry['family']} does not attest "
                f"(attested_rungs_q256 {list(rungs)}); a wire stamp beside a rung no receipt "
                "covers is a receipt for nothing")
    if sorted(item["q256"] for item in stamped) != sorted(rungs):
        raise ValueError(
            f"{where}.attested_wire must carry one entry per attested rung "
            f"{sorted(rungs)}, got {[item['q256'] for item in stamped]}; a rung with no stamp "
            "has bytes no receipt describes, and a stamp is meaningless anywhere else")
    for i, item in enumerate(stamped):
        _validate_wire_stamp(item, route, f"{where}.attested_wire[{i}]")


def _validate_wire_stamp(item: Mapping[str, Any], route: str, at: str) -> None:
    """One ``wire.recipes`` entry's SUBSTANCE: a body/span/plane ``route``
    decodes (``scheme.ROUTES``) and typed integers and spreads.  Shared by the
    per-rung ``attested_wire`` stamps and the ``allowable_rungs.wire`` rule
    stamp, so the two cannot be held to different vocabularies."""
    from .scheme import ROUTES

    expected = ROUTES[route]
    body = _ATTESTED_WIRE_BODY.get(item["body"])
    if body is None:
        raise ValueError(
            f"{at}.body {item['body']!r} is not a wire body the exporter spells "
            "(tessera.export._BODY_NAMES); a stamp outside the checkpoint's own "
            "vocabulary is nothing a preflight can compare")
    if body != expected["body"] or item["span"] != expected["span"]:
        raise ValueError(
            f"{at} stamps {item['body']!r} span {item['span']!r}, but {route} decodes the "
            f"span-{expected['span']} {expected['body']} body (tessera.serving.scheme.ROUTES). "
            "A stamp the route does not decode cannot be what a served receipt was cut on.")
    plane = _ATTESTED_WIRE_PLANE.get(item["plane"])
    if plane is None:
        raise ValueError(
            f"{at}.plane {item['plane']!r} is not a scale plane the exporter spells "
            "(tessera.export._PLANE_NAMES); a stamp outside the checkpoint's own "
            "vocabulary is nothing a preflight can compare")
    if plane != expected["plane"]:
        raise ValueError(
            f"{at} stamps the {item['plane']!r} plane, but {route} decodes the "
            f"{expected['plane']} plane to its {expected['tile']} tile "
            "(tessera.serving.scheme.ROUTES). "
            "A stamp the route does not decode cannot be what a served receipt was cut on.")
    for field in ("window_bits", "seed"):
        if not isinstance(item[field], int):
            raise ValueError(
                f"{at}.{field} is {item[field]!r}; a wire.recipes entry carries integers "
                "here, and a stamp that does not spell one is nothing a preflight can compare")
    for field in ("sigma", "channel_sigma"):
        value = item[field]
        if value is not None and not isinstance(value, (int, float)):
            raise ValueError(
                f"{at}.{field} is {value!r}; a modelled source spread in grid units is a "
                "number, or null for the pinned wire (sigma unset). A stamp that spells "
                "neither is nothing a preflight can compare")


# ---------------------------------------------------------------------------
# construction: which Linears the runtime OFFERS to a quant config at all
# ---------------------------------------------------------------------------
#
# The rest of this file answers "what does the plugin EXECUTE".  This block
# answers a question that comes earlier and that the plugin structurally cannot
# answer for itself: **is the plugin asked about this module at all**.
#
# ``LinearBase.__init__`` takes ``UnquantizedLinearMethod()`` in the
# ``quant_config is None`` branch *without calling* ``get_quant_method``
# (vLLM 0.28, ``model_executor/layers/linear.py:258``).  A model implementation
# that builds a projection with ``quant_config=None`` therefore takes vLLM's own
# BF16 method, and no plugin can refuse, warn, or even see the prefix.  On
# ``Glm5NextForConditionalGeneration`` that is every attention projection, the
# whole KDA layer, the sparse indexer and the entire vision tower.
#
# A producer that writes a wire there deletes the ``<module>.weight`` the
# runtime wants and puts bytes in its place that nothing decodes.  So the
# producer needs this fact BEFORE it encodes -- and principle 14 says it is
# derived from the runtime, never hand-kept beside it.  ``tools/
# tessera_construction_census.py`` derives it, by building the model the way the
# loader does with a probe quant config that records every prefix it is offered;
# the receipts it writes live in ``docs/measurements/construction/`` and this
# block is generated from them by :func:`construction_entry_from_receipt`,
# which ``tests/test_serving_construction.py`` re-derives and compares -- the
# same "table DERIVED from the code path, not typed beside it" rule
# ``native_extensions`` follows.

CONSTRUCTION_SCHEMA = "tessera.construction.v1"
CONSTRUCTION_CENSUS_SCHEMA = "tessera.construction-census.v1"

#: Any purely numeric path segment in a module prefix.  Must match
#: ``tools/tessera_construction_census.py``'s ``NUMERIC_SEGMENT``: a repeated
#: block is a repeated block whether the model spells its stack ``layers.N`` or
#: ``blocks.N``, and the census and the lookup have to normalise identically or
#: the join is silently empty.
_NUMERIC_SEGMENT = re.compile(r"(?<=\.)\d+(?=\.|$)")


def normalise_module(prefix: str) -> str:
    """A module prefix with its repeat indices collapsed to ``*``."""
    return _NUMERIC_SEGMENT.sub("*", prefix)


def construction_entry_from_receipt(receipt: Mapping[str, Any]) -> dict[str, Any]:
    """The contract row a construction census receipt implies.

    Generated, not transcribed: the receipt is the observation, this is the
    subset a gate reads, and the test that compares them is what keeps the two
    from drifting.

    A census row is a NORMALISED pattern over several modules, and the census
    does not let the last member win: it keeps the first member's answer and
    records the exact prefixes that disagreed under ``disagreements``.  Those
    rows travel into the entry and their patterns are struck from ``offered``,
    because a pattern whose observed members disagree answers nothing about the
    members that were not observed -- the GLM receipt is a 4-layer cut of a
    92-layer model -- and reading the first member's ``True`` as a clearance is
    how a wire gets written where the runtime builds BF16.  The key is present
    only when the census recorded one, which is the census's own spelling.
    """
    if receipt.get("schema") != CONSTRUCTION_CENSUS_SCHEMA:
        raise ValueError(
            f"construction census must declare schema {CONSTRUCTION_CENSUS_SCHEMA!r}, "
            f"got {receipt.get('schema')!r}")
    architectures = list(receipt["model"].get("architectures") or ())
    if len(architectures) != 1:
        raise ValueError(
            f"a construction census covers exactly one architecture; {architectures} "
            "does not say which module tree was walked")
    linears = receipt["linears"]
    ordered = sorted(linears, key=lambda r: r["prefix_pattern"])
    # Whatever the census recorded a disagreement on -- not a roster typed
    # here, so a field it starts recording tomorrow blocks tomorrow.
    disagreements = [
        {"prefix_pattern": row["prefix_pattern"],
         "fields": {field: sorted(prefixes)
                    for field, prefixes in sorted(row["disagreements"].items())}}
        for row in ordered if row.get("disagreements")]
    disagreeing = {row["prefix_pattern"] for row in disagreements}
    entry = {
        "architecture": architectures[0],
        "runtime": {key: receipt["runtime"][key] for key in ("image", "image_id", "vllm")},
        "model": {key: receipt["model"][key] for key in
                  ("model_type", "num_hidden_layers", "layer_types", "mlp_layer_types")},
        "supports_quant": bool(receipt["supports_quant"]),
        "hf_to_vllm_mapper_unstacked": receipt["hf_to_vllm_mapper_unstacked"] or {},
        "offered": sorted(row["prefix_pattern"] for row in linears
                          if row["offered_to_quant_config"]
                          and row["prefix_pattern"] not in disagreeing),
        "never_offered": [
            {"prefix_pattern": row["prefix_pattern"], "class": row["class"],
             "quant_method": row["quant_method"]}
            for row in ordered if not row["offered_to_quant_config"]],
        "offered_non_linear": [dict(row) for row in receipt["offered_non_linear"]],
    }
    if disagreements:
        entry["disagreements"] = disagreements
    # The runtime's output partition list per Linear, when the census recorded
    # one (receipts before tessera#377 did not).  A pattern whose members
    # disagreed is struck for the same reason it is struck from ``offered``:
    # it says nothing about the members that were not observed.
    output_sizes = {
        row["prefix_pattern"]: [int(s) for s in row["output_sizes"]]
        for row in ordered
        if row.get("output_sizes") is not None and row["prefix_pattern"] not in disagreeing}
    if output_sizes:
        entry["output_sizes"] = output_sizes
    return entry


#: The ``producer_interface`` block's schema (contract v40, tessera#599).
PRODUCER_INTERFACE_SCHEMA = "tessera.producer-interface.v1"
#: The option every listed driver declares, and the attribute the file it
#: names must define. :mod:`tessera.producer_authority` reads these two from
#: here, so the published block and the drivers' parsers are one spelling.
REUSE_AUTHORITY_OPTION = "--producer-authority"
REUSE_AUTHORITY_ATTRIBUTE = "PRODUCER_AUTHORITY"
REUSE_AUTHORITY_PROTOCOL = "tessera.cached_unit.ReuseAuthority"
REUSE_AUTHORITY_CANONICAL_ATTRIBUTE = "canonical_hessian_capture"


def validate_producer_interface(block: Any, where: str) -> None:
    """Refuse a ``producer_interface`` block that misstates the drivers' option.

    The block tells a producer, as data, which export drivers accept
    ``--producer-authority`` and what the file it names must define, so a
    producer decides whether to pass the option from the pinned runtime's own
    table.  Every value but ``drivers`` is a constant this module owns and
    :mod:`tessera.producer_authority` reads, and is checked here; the
    ``drivers`` list names the repository entry points that declare the
    option -- driver scripts outside the package (``experiments/``,
    ``tools/``) and package modules alike (``src/tessera/export_serving.py``
    since tessera#687) -- so its equality with the tree is held by
    ``tests/test_producer_authority_drivers.py``.
    """
    _require_keys(block, where, required={"schema", "reuse_authority"},
                  optional={"routed_units"})
    if "routed_units" in block:
        from ..serving_plan import ROUTED_UNIT_ASSIGNMENT
        if block["routed_units"] != ROUTED_UNIT_ASSIGNMENT:
            raise ValueError(f"{where}.routed_units must match the per-unit plan/loader contract")
    if block["schema"] != PRODUCER_INTERFACE_SCHEMA:
        raise ValueError(f"{where}.schema must be {PRODUCER_INTERFACE_SCHEMA!r}")
    reuse = block["reuse_authority"]
    row = f"{where}.reuse_authority"
    _require_keys(reuse, row, required={"option", "attribute", "protocol",
                                        "canonical_capture_attribute", "drivers"})
    expected = {"option": REUSE_AUTHORITY_OPTION,
                "attribute": REUSE_AUTHORITY_ATTRIBUTE,
                "protocol": REUSE_AUTHORITY_PROTOCOL,
                "canonical_capture_attribute": REUSE_AUTHORITY_CANONICAL_ATTRIBUTE}
    for key, value in expected.items():
        if reuse[key] != value:
            raise ValueError(
                f"{row}.{key} must be {value!r}, what tessera.producer_authority reads; "
                f"got {reuse[key]!r}")
    drivers = reuse["drivers"]
    if (not isinstance(drivers, list) or not drivers
            or not all(isinstance(d, str) and d.endswith(".py") and not d.startswith("/")
                       and ".." not in d.split("/") for d in drivers)
            or drivers != sorted(set(drivers))):
        raise ValueError(
            f"{row}.drivers must be a non-empty, sorted, duplicate-free list of "
            f"repository-relative .py paths; got {drivers!r}")


def _validate_construction(block: Any, where: str) -> None:
    """Refuse a construction block a gate could misread."""
    _require_keys(block, where, required={"schema", "architectures"}, optional={"note"})
    if block["schema"] != CONSTRUCTION_SCHEMA:
        raise ValueError(f"{where}.schema must be {CONSTRUCTION_SCHEMA!r}")
    seen: set[str] = set()
    for i, entry in enumerate(block["architectures"]):
        row = f"{where}.architectures[{i}]"
        _require_keys(entry, row,
                      required={"architecture", "runtime", "model", "supports_quant",
                                "hf_to_vllm_mapper_unstacked", "offered", "never_offered",
                                "offered_non_linear"},
                      optional={"receipt", "disagreements", "output_sizes"})
        name = entry["architecture"]
        if name in seen:
            raise ValueError(
                f"{row}: {name!r} is censused twice. Two censuses of one architecture are two "
                "claims about one runtime; merge them or drop the stale one")
        seen.add(name)
        overlap = sorted(set(entry["offered"]) &
                         {r["prefix_pattern"] for r in entry["never_offered"]})
        if overlap:
            raise ValueError(
                f"{row}: {overlap} are both offered and never offered; a census cannot say both")
        _validate_construction_disagreements(entry, row)
        _validate_construction_output_sizes(entry, row)
        for key in ("image", "image_id", "vllm"):
            if not entry["runtime"].get(key):
                raise ValueError(
                    f"{row}.runtime.{key} is empty: a construction answer is a property of the "
                    "image it was observed in, and an unstamped one cannot be checked against "
                    "the image a serve actually runs")


def _validate_construction_output_sizes(entry: Mapping[str, Any], where: str) -> None:
    """Refuse an output-partition table a producer could pair wrongly.

    Every key is a pattern the census walked (offered or never offered), every
    value a non-empty list of positive partition sizes, and no disagreeing
    pattern carries one -- ``construction_entry_from_receipt`` strikes those,
    and a hand-typed block cannot put one back.
    """
    table = entry.get("output_sizes")
    if table is None:
        return
    if not isinstance(table, Mapping):
        raise ValueError(f"{where}.output_sizes must map module patterns to partition lists")
    disagreeing = {r["prefix_pattern"] for r in entry.get("disagreements", ())}
    # A disagreeing pattern is struck from ``offered`` too, so it is asked
    # first: the refusal names the reason the census recorded.
    walked = (set(entry["offered"]) | {r["prefix_pattern"] for r in entry["never_offered"]}
              | disagreeing)
    for pattern, sizes in table.items():
        at = f"{where}.output_sizes[{pattern!r}]"
        if pattern in disagreeing:
            raise ValueError(
                f"{at}: the pattern's members disagreed, so no one partition list is attested")
        if pattern not in walked:
            raise ValueError(f"{at}: the census walked no Linear of that pattern")
        if (not isinstance(sizes, list) or not sizes
                or any(not isinstance(v, int) or isinstance(v, bool) or v <= 0 for v in sizes)):
            raise ValueError(f"{at} must be a non-empty list of positive partition sizes")


def output_partitions(entry: Mapping[str, Any], checkpoint_module: str) -> "list[int] | None":
    """The runtime's output partition list for one checkpoint module, or ``None``.

    ``None`` means the census that covers this architecture predates the
    field (tessera#377) or observed this pattern's members disagreeing: the
    geometry is UNATTESTED, not "one partition".  A producer that reads
    ``None`` declares its roles the way it did before and must say so in the
    artifact; it may not read it as a clearance.
    """
    table = entry.get("output_sizes")
    if not table:
        return None
    pattern = normalise_module(vllm_module_name(entry, checkpoint_module))
    sizes = table.get(pattern)
    return None if sizes is None else [int(s) for s in sizes]


def _validate_construction_disagreements(entry: Mapping[str, Any], where: str) -> None:
    """Refuse a disagreement row a gate could read as nothing.

    The block carries the census's ``disagreements`` so ``classify_construction``
    can refuse a pattern whose members were observed answering differently. A
    row that names no field says nothing, and a pattern that is disagreeing AND
    cleared is the contradiction this whole block exists to keep out of an
    exporter -- both are refused here rather than at the far end.
    """
    patterns: set[str] = set()
    for j, item in enumerate(entry.get("disagreements", ())):
        at = f"{where}.disagreements[{j}]"
        _require_keys(item, at, required={"prefix_pattern", "fields"})
        pattern = item["prefix_pattern"]
        if not isinstance(pattern, str) or not pattern:
            raise ValueError(f"{at}.prefix_pattern must name the normalised module pattern")
        if pattern in patterns:
            raise ValueError(f"{at}: {pattern!r} is recorded twice")
        patterns.add(pattern)
        fields = item["fields"]
        if not isinstance(fields, Mapping) or not fields:
            raise ValueError(
                f"{at}.fields is empty: a disagreement that names no census field and no "
                "disagreeing prefix is not an observation a gate can act on")
        for field, prefixes in fields.items():
            if not isinstance(prefixes, list) or not prefixes or not all(
                    isinstance(p, str) and p for p in prefixes):
                raise ValueError(
                    f"{at}.fields.{field} must list the exact module prefixes that disagreed")
    cleared = sorted(patterns & set(entry["offered"]))
    if cleared:
        raise ValueError(
            f"{where}: {cleared} disagreed across their observed members and are still listed as "
            "offered. A normalised pattern whose members answer differently clears none of them; "
            "regenerate the block with tools/tessera_update_construction_block.py")


def construction_entry(architectures, contract: Mapping[str, Any] | None = None):
    """The censused entry for a checkpoint's ``architectures``, or ``None``."""
    payload = contract if contract is not None else load_serving_contract()
    block = payload.get("construction")
    if not block:
        return None
    wanted = [architectures] if isinstance(architectures, str) else list(architectures or ())
    for entry in block["architectures"]:
        if entry["architecture"] in wanted:
            return entry
    return None


#: The ``WeightsMapper`` fields ``vllm_module_name`` replays, in vLLM's own
#: order (``_map_name_with_shard``, vLLM 0.28 ``model_executor/models/
#: utils.py``).  Everything else in that dataclass -- ``orig_to_new_renaming``,
#: ``orig_to_new_regex``, ``orig_to_new_stacked``, and whatever vLLM adds next
#: -- is REFUSED rather than skipped, because a rule silently not applied is a
#: wrong module name and a wrong module name is a dead wire.
_MAPPER_FIELDS_REPLAYED = ("orig_to_new_substr", "orig_to_new_prefix", "orig_to_new_suffix")


def _require_replayable_mapper(table: Mapping[str, Any]) -> None:
    """Refuse a mapper table carrying a rule this producer cannot replay.

    Principle 14 has no exemption for "the algorithm is code, not a table".
    vLLM publishes the TABLE (the census reads it off the model class); the
    ALGORITHM that consumes it lives in ``WeightsMapper._map_name_with_shard``
    and cannot be derived from the table.  So the producer replays the three
    fields whose semantics are pinned in the pure suite and attested against
    the real mapper in ``tests/test_serving_name_mapping.py`` -- and refuses,
    by name, on every other field.

    ``orig_to_new_stacked`` is in the refused set on purpose.  vLLM applies it
    inside ``_map_name``, and ``get_unstacked_mapper()`` -- the variant
    ``configure_quant_config`` hands a quant config -- empties it.  A receipt
    field named ``hf_to_vllm_mapper_unstacked`` carrying a populated stacked
    map therefore says the census fell back to the raw mapper, which is a
    contradiction in the receipt rather than a case to implement.
    """
    unknown = sorted(field for field, value in table.items()
                     if value and field not in _MAPPER_FIELDS_REPLAYED)
    if unknown:
        raise ValueError(
            f"the census recorded hf_to_vllm_mapper fields this producer does not replay: "
            f"{unknown}. vLLM applies them in WeightsMapper._map_name_with_shard, so the "
            f"vLLM-side module name computed here would be wrong and the wire written to it "
            f"dead. Extend vllm_module_name AND its attestation in "
            f"tests/test_serving_name_mapping.py, or export this architecture through a "
            f"runtime whose mapper uses only {list(_MAPPER_FIELDS_REPLAYED)}.")


def vllm_module_name(entry: Mapping[str, Any], checkpoint_module: str) -> str:
    """A checkpoint module name in the namespace the runtime builds it under.

    A line-for-line replay of vLLM's ``WeightsMapper._map_name_with_shard``
    over the three fields ``_MAPPER_FIELDS_REPLAYED`` names, in its order and
    with its semantics: a substring rule replaces ONE occurrence
    (``key.replace(substr, new_key, 1)``), and the prefix and suffix loops fall
    THROUGH -- each rule sees the key the previous rule rewrote.  Only the
    unstacked fields matter, which is exactly what ``configure_quant_config``
    hands a quant config and therefore exactly what
    ``TesseraConfig.apply_vllm_mapper`` will apply to this name at load.

    The replay is a claim about another runtime, so it is attested rather than
    asserted: ``tests/test_serving_name_mapping.py`` runs these same names
    through the real ``WeightsMapper`` inside the serving image and fails on
    any disagreement, and ``_require_replayable_mapper`` refuses a table
    carrying a rule the replay does not cover.
    """
    table = entry.get("hf_to_vllm_mapper_unstacked") or {}
    _require_replayable_mapper(table)
    name = checkpoint_module

    def _dropped() -> None:
        # vLLM's WeightsMapper spells "discard this weight" as a None
        # replacement (``_map_name`` returns None and ``apply_list`` drops the
        # entry).  A module the runtime maps away is a module it never builds,
        # so a wire written there is dead -- the same refusal
        # ``TesseraConfig.apply_vllm_mapper`` raises at load, taken here at
        # export instead.
        raise ValueError(
            f"the runtime's hf_to_vllm_mapper DROPS {checkpoint_module!r}, so it builds no "
            "module for this name at all. A wire written here is dead weight; that is a "
            "refusal, not a warning.")

    for old, new in (table.get("orig_to_new_substr") or {}).items():
        if old in name:
            if new is None:
                _dropped()
            name = name.replace(old, new, 1)
    for old, new in (table.get("orig_to_new_prefix") or {}).items():
        if name.startswith(old):
            if new is None:
                _dropped()
            name = name.replace(old, new, 1)
    for old, new in (table.get("orig_to_new_suffix") or {}).items():
        if name.endswith(old):
            if new is None:
                _dropped()
            name = new.join(name.rsplit(old, 1))
    return name


def classify_construction(entry: Mapping[str, Any], checkpoint_module: str) -> tuple[str, str]:
    """``(verdict, vllm module pattern)`` for one checkpoint module name.

    ``offered`` -- the runtime builds this module and offers it to the quant
    config, so a wire written here is executed.  ``never_offered`` -- it builds
    it with ``quant_config=None``, so the plugin is never asked and the wire is
    dead.  ``absent`` -- the census walked the whole module tree and this name
    is not a module the runtime builds at all (a fused role named at its leaf,
    a name from another architecture).  ``disagreement`` -- the census observed
    the members of this pattern answering differently and recorded which ones,
    so the pattern says nothing about any of them.  The last three are the same
    outcome for a producer and are told apart only so the refusal can say which
    it is.

    ``offered`` IS TWO LISTS, because "was this prefix offered a quant config"
    and "is this prefix a Linear" are different questions and the census
    records them separately.  ``offered`` holds the ``LinearBase`` rows;
    ``offered_non_linear`` holds every prefix the probe config WAS asked about
    that is not one -- the LM head, and the ``RoutedExperts`` stack a routed
    MoE layer builds.  An expert stack read only the first list resolved
    ``absent``, which would have refused the one module the expert route
    exists to serve while the census receipt said, in the same file, that the
    runtime asks about it.  The census is the attestation either way
    (principle 14); this reads all of what it wrote.

    That includes what it wrote about members that DISAGREED, which is checked
    first: a pattern the census saw answer both ways is not evidence for either
    answer, and reading the first member's ``True`` as a clearance is how a
    producer deletes a ``<module>.weight`` the runtime builds with
    ``quant_config=None`` (#204).
    """
    pattern = normalise_module(vllm_module_name(entry, checkpoint_module))
    if pattern in {row["prefix_pattern"] for row in entry.get("disagreements", ())}:
        return "disagreement", pattern
    if pattern in set(entry["offered"]):
        return "offered", pattern
    if pattern in {row["prefix_pattern"] for row in entry.get("offered_non_linear", ())}:
        return "offered", pattern
    if pattern in {row["prefix_pattern"] for row in entry["never_offered"]}:
        return "never_offered", pattern
    return "absent", pattern
