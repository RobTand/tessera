"""The grouped window GEMM: many experts, one launch, device-side routing.

WHAT IT SERVES.  A stack of window units (BF16 value family or FP8 E4M3
family) with per-expert tables, rate runs and row-cut history, computed
against one activation batch under a token->expert routing.  Every expert's
weight tile is decoded inside the kernel from its own packed planes and kept
in registers/SMEM; no decoded expert weight ever reaches global memory.

DEVICE-SIDE ROUTING.  ``__call__`` builds the token->expert CSR with device
operations only: a fixed-size ``scatter_add_`` histogram (never ``bincount``,
whose CUDA output size is data-dependent and synchronises), a stable
``argsort`` of the flat route ids, and a cumsum over the fixed ``[E]``
histogram.  One grid over ``(expert, N block, M block)`` follows; a block
whose token range is empty returns before decoding anything, and every
program gathers its tokens by index.  There is no CPU loop over tokens or
experts and no synchronisation in the forward.

MODES (matching vLLM's ``TopKWeightAndReduce`` semantics).

* ``preserve=True`` -- route-preserving first projection: fp32 accumulation,
  one bf16 output per route, shape ``[T, top_k, rows]``.  With
  ``apply_router_weight_on_input=True`` the route weight multiplies this
  projection's fp32 accumulator -- vLLM's gemm1 ``MUL_ROUTED_WEIGHT``
  placement, which is the input-weight semantics up to rounding; otherwise
  the weight belongs to the reduction stage.
* ``preserve=False`` (default) -- reduction: fp32 accumulation, the route
  weight applied to the fp32 accumulator unless ``apply_router_weight_on_input``
  (the input then already carries it), summed into ``[T, rows]`` with atomics
  and cast once to bf16.  ``route_input=True`` indexes ``x`` by route instead
  of by token, so the down projection of a two-stage MoE consumes the
  per-route activations directly and still reduces over ``top_k``.
  ``round_routes=True`` rounds each route's down output to bf16 *before* the
  atomic reduction, which is the stock runtime boundary (vLLM's bf16 cache13
  plus ``moe_sum``); without it the whole reduction stays fp32 and rounds
  once, a different arithmetic for the same weights.
* Both modes apply the family epilogues: BF16 row scale only under
  ``arithmetic="epilogue"``; FP8 ``y = acc * a_scale[t] * w_scale[e, n]``
  under vLLM's native per-token quantizer.  ``prepare_grouped_window_gemm``'s
  ``arithmetic="folded"`` selects the **BF16 folded contract** instead -- one
  bf16 rounding of ``(value * row_scale)`` per weight in registers before the
  dot, exactly ``bf16_route.decode_folded``'s
  ``(values.float() * scale[:, :, None]).to(torch.bfloat16)``, with no scale
  in the epilogue.  It is a prepare-time property, not a call flag, and the
  FP8 family refuses it.  It is the same arithmetic the dense
  ``window_gemm`` runs under the same name, which is what the BF16 route
  serves for both its dense and its routed modules (tessera#614).

``preserve`` + a per-route activation + ``reduce`` is the two-stage MoE shape
(gate/up -> activation -> down); the module itself never assumes that a sum
of linears can stand in for the activation.  The placement follows vLLM's own
fused path rather than an algebraic equivalent: in
``model_executor/layers/fused_moe/fused_moe.py`` gemm1 is dispatched with
``apply_router_weight_on_input`` and each kernel multiplies the fp32
accumulator by the route weight when ``MUL_ROUTED_WEIGHT`` is set -- before
the nonlinear activation and before the next A-side quant -- while gemm2 is
dispatched with ``not apply_router_weight_on_input``; and
``topk_weight_and_reduce.py`` weights the per-route outputs only when the
input did not already carry the weights, then sums.  A combination this
module does not serve fails closed (``preserve`` with ``route_input`` is two
different stages) rather than silently changing the placement.

VALIDATION BOUNDARY.  Constants are validated once in
``prepare_grouped_window_gemm``; the forward checks cheap metadata only
(rank, width, dtype, device, contiguity, ``T`` agreement) and never reads a
tensor back to the host.  Routing ids are per-forward: ``routing_ids_ok`` is
a device predicate the caller inspects on its own schedule; a bad id is not
silently dropped (``scatter_add_`` refuses it on device).
"""
from __future__ import annotations

import dataclasses
from typing import Sequence

import torch
import triton
import triton.language as tl

from .errors import GrammarError
from .kernel_window_gemv import TILE_ROWS, WindowGemvUnit
from .window_gemm import prepare_window_gemm

__all__ = ["prepare_grouped_window_gemm", "PreparedGroupedWindowGemm", "routing_ids_ok"]


@triton.jit
def _grouped_window_gemm_kernel(
    words_all, table_all, codes_all, native_all, x_ptr, out_ptr,
    scale_all, a_scale_ptr, rw_ptr, flat_ptr, offset_ptr,
    runs_all, init_all, has_init_ptr,
    word_off_ptr, tile_words_ptr, total_words_ptr, run_off_ptr, perm_ptr,
    rows, cols, E, P, top_k,
    L: tl.constexpr, TILE: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
    FP8: tl.constexpr, PRESERVE: tl.constexpr,
    MUL_WEIGHT: tl.constexpr, ROUTE_INPUT: tl.constexpr, FOLDED: tl.constexpr,
    ROUND_ROUTES: tl.constexpr,
):
    e = tl.program_id(0)
    pid_n = tl.program_id(1)
    pid_m = tl.program_id(2)

    start = tl.load(offset_ptr + e)
    end = tl.load(offset_ptr + e + 1)

    if pid_m * BM < end - start:
        pos = start + pid_m * BM + tl.arange(0, BM)
        live_tok = pos < end
        safe_pos = tl.minimum(pos, P - 1)
        flat = tl.load(flat_ptr + safe_pos, mask=live_tok, other=0)
        tok = flat // top_k
        rw = tl.load(rw_ptr + safe_pos, mask=live_tok, other=0.0)

        n0 = pid_n * BN
        g = n0 // TILE
        t = n0 - g * TILE
        offs_n = n0 + tl.arange(0, BN)
        live_n = offs_n < rows

        word_off = tl.load(word_off_ptr + e)
        tile_words = tl.load(tile_words_ptr + e)
        total_words = tl.load(total_words_ptr + e)
        run_off = tl.load(run_off_ptr + e)
        n_runs = tl.load(run_off_ptr + e + 1) - run_off
        has_init = tl.load(has_init_ptr + e)
        words = words_all + word_off
        wscale = tl.load(scale_all + e * rows + offs_n, mask=live_n, other=0.0)

        rows_v = tl.arange(0, BN)
        acc = tl.zeros((BM, BN), dtype=tl.float32)

        for r in range(n_runs):
            rate = tl.load(runs_all + (run_off + r) * 4 + 0)
            col0 = tl.load(runs_all + (run_off + r) * 4 + 1)
            ncols = tl.load(runs_all + (run_off + r) * 4 + 2)
            word0 = tl.load(runs_all + (run_off + r) * 4 + 3)
            CHUNK = 16 * rate
            tile_base = g * tile_words + word0

            for c0 in range(0, ncols, BK):
                offs_k = c0 + tl.arange(0, BK)
                live_k = offs_k < ncols
                live_k2 = live_k[:, None]
                kglob = col0 + offs_k
                base = tile_base + offs_k * CHUNK

                qq = (t + 1 + rows_v) * rate
                length = tl.where(has_init != 0, L,
                                  tl.minimum(qq + g * TILE * rate, L))
                qb = qq - L
                neg = qb < 0
                wi = tl.where(neg, -1, qb >> 5)
                d1 = wi + 1
                shift = 64 - qq + 32 * wi

                prev_off = -tile_words + CHUNK - 1
                idx_prev = base[:, None] + prev_off
                idx_norm = base[:, None] + wi[None, :]
                idx1 = base[:, None] + d1[None, :]
                live_prev = live_k2 & (g > 0) & (idx_prev >= 0) & (idx_prev < total_words)
                live_norm = live_k2 & (idx_norm >= 0) & (idx_norm < total_words)
                live1 = live_k2 & (idx1 >= 0) & (idx1 < total_words)
                w0_prev = tl.load(words + idx_prev, mask=live_prev, other=0).to(tl.int64) & 0xFFFFFFFF
                w0_norm = tl.load(words + idx_norm, mask=live_norm, other=0).to(tl.int64) & 0xFFFFFFFF
                w0_init = tl.load(init_all + e * cols + kglob, mask=live_k, other=0).to(tl.int64) & 0xFFFFFFFF
                w0 = tl.where(neg[None, :] & (g == 0), w0_init[:, None],
                              tl.where(neg[None, :], w0_prev, w0_norm))
                w1 = tl.load(words + idx1, mask=live1, other=0).to(tl.int64) & 0xFFFFFFFF

                combined = (w0 << 32) | w1
                state = (combined >> shift[None, :]) & ((1 << length) - 1)[None, :]

                if FP8:
                    code = tl.load(codes_all + e * (1 << L) + state, mask=live_k2, other=0)
                    byte = tl.load(native_all + e * 256 + code.to(tl.int32), mask=live_k2, other=0)
                    val = byte.to(tl.float8e4nv, bitcast=True)
                else:
                    val = tl.load(table_all + e * (1 << L) + state, mask=live_k2, other=0.0)
                    if FOLDED:
                        # the BF16 folded contract: one bf16 rounding of
                        # (value * row scale) in registers, before the dot
                        val = (val.to(tl.float32) * wscale[None, :]).to(tl.bfloat16)

                kcol = tl.load(perm_ptr + e * cols + kglob, mask=live_k, other=0)
                if ROUTE_INPUT:
                    xrow = flat
                else:
                    xrow = tok
                xk = tl.load(
                    x_ptr + xrow[:, None] * cols + kcol[None, :],
                    mask=live_tok[:, None] & live_k[None, :], other=0.0
                )
                acc += tl.dot(xk, val, out_dtype=tl.float32)

        wscale = tl.load(scale_all + e * rows + offs_n, mask=live_n, other=0.0)
        contrib = acc if FOLDED else acc * wscale[None, :]
        if FP8:
            if ROUTE_INPUT:
                a_s = tl.load(a_scale_ptr + flat, mask=live_tok, other=0.0)
            else:
                a_s = tl.load(a_scale_ptr + tok, mask=live_tok, other=0.0)
            # Stock's Triton kernel computes ``accumulator * a_scale * b_scale``
            # left to right (fused_moe.py); keep the same fp32 operation order.
            contrib = (acc * a_s[:, None]) * wscale[None, :]
        if MUL_WEIGHT:
            contrib = contrib * rw[:, None]      # vLLM multiplies the fp32 accumulator
        if PRESERVE:
            tl.store(
                out_ptr + flat[:, None] * rows + offs_n[None, :],
                contrib.to(tl.bfloat16), mask=live_tok[:, None] & live_n[None, :],
            )
        else:
            if ROUND_ROUTES:
                # the stock runtime boundary: each route's down output is
                # rounded to the compute dtype before the reduction, exactly
                # what vLLM's cache13 (bf16) + moe_sum performs
                contrib = contrib.to(tl.bfloat16).to(tl.float32)
            tl.atomic_add(
                out_ptr + tok[:, None] * rows + offs_n[None, :],
                contrib, mask=live_tok[:, None] & live_n[None, :],
            )

@dataclasses.dataclass(frozen=True)
class PreparedGroupedWindowGemm:
    """The frozen stack: SoA planes, per-expert headers, geometry."""

    words_all: torch.Tensor
    table_all: torch.Tensor | None
    codes_all: torch.Tensor | None
    native_all: torch.Tensor | None
    scale_all: torch.Tensor
    runs_all: torch.Tensor | None
    init_all: torch.Tensor
    has_init: torch.Tensor
    word_off: torch.Tensor | None
    tile_words: torch.Tensor | None
    total_words: torch.Tensor | None
    run_off: torch.Tensor | None
    perm_all: torch.Tensor | None
    rows: int
    cols: int
    experts: int
    window_bits: int
    family: str
    block_m: int
    block_n: int
    block_k: int
    quantizer: str | None = "native"
    arithmetic: str = "epilogue"
    #: The resident word order of ``words_all`` (``kernel_window_gemv``
    #: ``WORD_LAYOUT_*``).  The compact Triton kernel reads the legacy
    #: ``[column][chunk]`` order only; a stack in any other order is refused
    #: at ``__call__`` rather than mis-read.
    word_layout: str = "legacy"
    #: The ``e2m1`` family's scale (E2M1x2 window body over LUT16): per expert,
    #: the group-16 nibble plane (uint8 ``[E, rows * cols / 32]``), the
    #: 16-entry UE4M3 table (uint8 ``[E, 16]``) and the fp32 global.  ``None``
    #: on the other two families, whose scale is ``scale_all``.
    scale_plane_all: "torch.Tensor | None" = None
    scale_lut_all: "torch.Tensor | None" = None
    global_all: "torch.Tensor | None" = None

    @property
    def device(self) -> torch.device:
        return self.words_all.device

    def __call__(self, x: torch.Tensor,
                 expert_ids: torch.Tensor,
                 routing_weights: torch.Tensor,
                 a_scale: torch.Tensor | None = None,
                 out: torch.Tensor | None = None,
                 *,
                 preserve: bool = False,
                 apply_router_weight_on_input: bool = False,
                 route_input: bool = False,
                 round_routes: bool = False) -> torch.Tensor:
        if self.perm_all is None:
            raise GrammarError(
                "this native projection retired its compact planes; "
                "only its already-prepared fused owner can execute it")
        if self.family == "e2m1":
            raise GrammarError(
                "the e2m1 family has no grouped Triton GEMM; its stacks are served by the "
                "fused routed window lane (tessera.routed_fused) only")
        from .kernel_window_gemv import require_legacy_word_layout
        require_legacy_word_layout(self.word_layout, "the compact Triton grouped GEMM")
        if x.dim() != 2 or x.shape[1] != self.cols or x.device != self.device:
            raise GrammarError(
                f"x must be a [T, {self.cols}] tensor on {self.device}, got "
                f"{tuple(x.shape)} on {x.device}"
            )
        if not x.is_contiguous():
            raise GrammarError("x must be contiguous; the kernel indexes it with one stride")
        if expert_ids.dim() != 2 or routing_weights.shape != expert_ids.shape:
            raise GrammarError("expert_ids and routing_weights must share [T, top_k]")
        if expert_ids.device != self.device or routing_weights.device != self.device:
            raise GrammarError("routing tensors must live on the compute device")
        if routing_weights.dtype != torch.float32:
            routing_weights = routing_weights.float()
        t_tokens, top_k = expert_ids.shape
        if preserve and route_input:
            raise GrammarError(
                "preserve mode and route_input describe two different stages: a "
                "route-preserving projection takes token-indexed input"
            )
        expected_rows = t_tokens * top_k if route_input else t_tokens
        if x.shape[0] != expected_rows:
            raise GrammarError(
                f"x has {x.shape[0]} rows, the routing calls for {expected_rows} "
                f"({'route' if route_input else 'token'}-indexed input)"
            )
        if t_tokens == 0:
            shape = (0, top_k, self.rows) if preserve else (0, self.rows)
            return torch.empty(shape, dtype=torch.bfloat16, device=self.device)

        if self.family == "value":
            if x.dtype != torch.bfloat16 or a_scale is not None:
                raise GrammarError("the value family takes a bf16 x and no activation scale")
            xq = x
            fp8 = False
        else:
            if x.dtype == torch.float8_e4m3fn:
                if a_scale is None:
                    raise GrammarError(
                        "an fp8 x must carry its per-token activation scale; a bare fp8 "
                        "or bf16 activation would change the contract"
                    )
                a_scale = a_scale.reshape(-1)
                if a_scale.numel() != expected_rows or a_scale.dtype != torch.float32 \
                        or a_scale.device != self.device:
                    raise GrammarError(
                        f"a_scale must be fp32 [{expected_rows}] on {self.device} "
                        f"({'route' if route_input else 'token'}-indexed input)"
                    )
                if not a_scale.is_contiguous():
                    raise GrammarError(
                        "a_scale must be contiguous after flattening; the kernel reads it "
                        "with one stride"
                    )
                xq = x
            else:
                if x.dtype != torch.bfloat16:
                    raise GrammarError(f"the E4M3 family takes bf16 or fp8 x, got {x.dtype}")
                if a_scale is not None:
                    raise GrammarError("a_scale belongs with a prequantized fp8 x")
                if self.quantizer != "native":
                    raise GrammarError(
                        "this bundle was prepared without a quantizer; pass the "
                        "prequantized fp8 activation together with its per-token scale"
                    )
                from .serving.native_ops import native_fp8_quant
                xq, s = native_fp8_quant(x)
                a_scale = s.reshape(-1)
            fp8 = True

        ids = expert_ids.reshape(-1)
        if ids.dtype not in (torch.int32, torch.int64):
            raise GrammarError("expert_ids must be int32 or int64")
        ids = ids.to(torch.int64)
        rw = routing_weights.reshape(-1).contiguous()
        p = int(ids.numel())

        if preserve:
            result = (torch.empty(t_tokens, top_k, self.rows, dtype=torch.bfloat16,
                                  device=self.device) if out is None else out)
            if result.shape != (t_tokens, top_k, self.rows) \
                    or result.dtype != torch.bfloat16 or result.device != self.device:
                raise GrammarError(
                    f"out must be bf16 [{t_tokens}, {top_k}, {self.rows}] on {self.device}"
                )
            if not result.is_contiguous():
                raise GrammarError("out must be contiguous; the kernel writes row-major")
        else:
            result = (torch.zeros(t_tokens, self.rows, dtype=torch.float32, device=self.device)
                      if out is None else out)
            if result.shape != (t_tokens, self.rows) or result.dtype != torch.float32 \
                    or result.device != self.device:
                raise GrammarError(f"out must be fp32 [{t_tokens}, {self.rows}] on {self.device}")
            if not result.is_contiguous():
                raise GrammarError("out must be contiguous; the kernel accumulates row-major")
            result.zero_()          # overwrite semantics: the caller's buffer is consumed

        if p:
            counts = torch.zeros(self.experts, dtype=torch.int32, device=self.device)
            counts.scatter_add_(0, ids, torch.ones_like(ids, dtype=torch.int32))
            offsets = torch.zeros(self.experts + 1, dtype=torch.int32, device=self.device)
            offsets[1:] = torch.cumsum(counts, 0)
            order = torch.argsort(ids, stable=True)
            flat_sorted = order.to(torch.int32).contiguous()
            rw_sorted = rw[order].contiguous()
            grid = (self.experts, triton.cdiv(self.rows, self.block_n),
                    triton.cdiv(p, self.block_m))
            _grouped_window_gemm_kernel[grid](
                self.words_all, self.table_all, self.codes_all, self.native_all, xq, result,
                self.scale_all,
                a_scale if a_scale is not None else self.scale_all.new_zeros(1),
                rw_sorted, flat_sorted, offsets,
                self.runs_all, self.init_all, self.has_init,
                self.word_off, self.tile_words, self.total_words, self.run_off, self.perm_all,
                self.rows, self.cols, self.experts, p, top_k,
                L=self.window_bits, TILE=TILE_ROWS,
                BM=self.block_m, BN=self.block_n, BK=self.block_k,
                FP8=fp8, PRESERVE=preserve,
                MUL_WEIGHT=(apply_router_weight_on_input == preserve),
                ROUTE_INPUT=route_input,
                FOLDED=(self.arithmetic == "folded"),
                ROUND_ROUTES=round_routes,
                num_warps=8,
            )
        return result if preserve else result.to(torch.bfloat16)


def prepare_grouped_window_gemm_from_soa(
    *,
    words_all: torch.Tensor,
    table_all: torch.Tensor,
    codes_all: torch.Tensor,
    native_all: torch.Tensor,
    scale_all: torch.Tensor,
    runs_all: torch.Tensor,
    init_all: torch.Tensor,
    has_init: torch.Tensor,
    word_off: torch.Tensor,
    tile_words: torch.Tensor,
    total_words: torch.Tensor,
    run_off: torch.Tensor,
    perm_all: torch.Tensor,
    rows: int,
    cols: int,
    experts: int,
    window_bits: int,
    family: str,
    block_m: int = 64,
    block_n: int = 64,
    block_k: int = 64,
    quantizer: str | None = "native",
    arithmetic: str = "epilogue",
    scale_plane_all: "torch.Tensor | None" = None,
    scale_lut_all: "torch.Tensor | None" = None,
    global_all: "torch.Tensor | None" = None,
    word_layout: str = "legacy",
) -> PreparedGroupedWindowGemm:
    """A prebuilt SoA stack -- what a loader fills incrementally -- validated
    once and wrapped.  Shapes, dtypes and the per-expert offsets must already
    be the kernel's contract; anything else refuses by name.  ``words_all`` is
    the uniform ``[E, W]`` rectangle or, for a mixed per-unit stack (#967), the
    flat int32 stream each expert's ``word_off`` bounds exactly.

    ``family="e2m1"`` is the E2M1x2 window body over the LUT16 plane: its
    ``codes_all`` holds tuple code bytes, its ``rows`` are weight rows (two
    per code), and its scale is ``scale_plane_all``/``scale_lut_all``/
    ``global_all`` instead of ``scale_all``.  Such a bundle is data for the
    fused routed lane; calling it refuses."""
    if arithmetic not in ("epilogue", "folded"):
        raise GrammarError(f"unknown weight arithmetic {arithmetic!r}")
    if arithmetic == "folded" and family != "value":
        raise GrammarError("the folded weight arithmetic is the BF16 (value family) contract")
    if family not in ("value", "e4m3", "e2m1"):
        raise GrammarError(
            f"window_gemm_grouped serves the value, e4m3 and e2m1 families, got {family!r}")
    e2m1 = family == "e2m1"
    if e2m1 != (scale_plane_all is not None) or e2m1 != (scale_lut_all is not None) \
            or e2m1 != (global_all is not None):
        raise GrammarError(
            "the scale plane, table and global are the e2m1 family's scale and only its: "
            f"family {family!r} got plane={scale_plane_all is not None}, "
            f"table={scale_lut_all is not None}, global={global_all is not None}")
    for name, t, shape in (("word_off", word_off, (experts,)),
                           ("tile_words", tile_words, (experts,)),
                           ("total_words", total_words, (experts,)),
                           ("run_off", run_off, (experts + 1,)),
                           ("has_init", has_init, (experts,))):
        if tuple(t.shape) != shape:
            raise GrammarError(f"{name} must be [{shape[0]}], got {tuple(t.shape)}")
    if words_all.dim() == 1:
        # A mixed per-unit stack (#967): one flat int32 word stream and one
        # flat run table, each expert's slice the exact place its loader
        # declared.  The kernel indexes words/runs through word_off/run_off
        # already; what is new here is only accepting non-uniform offsets --
        # bound to the per-expert totals, so a hole or an overlap refuses by
        # name instead of reading one expert's words as another's.
        if int(word_off[0]) != 0:
            raise GrammarError("word_off must start at expert 0's first word: 0")
        ends = word_off[:-1].to(torch.int64) + total_words[:-1].to(torch.int64)
        if not bool((ends == word_off[1:].to(torch.int64)).all()) \
                or int(word_off[-1]) + int(total_words[-1]) != int(words_all.numel()):
            raise GrammarError(
                "word_off must be each expert's exact place in the flat word stream: "
                "word_off[e + 1] == word_off[e] + total_words[e], ending at the stream's "
                f"{int(words_all.numel())} word(s)")
        runs_rows = int(runs_all.reshape(-1, 4).shape[0])
        if int(run_off[0]) != 0 or int(run_off[-1]) != runs_rows:
            raise GrammarError(
                f"run_off must bound the flat run table: 0 to {runs_rows} run(s)")
        if not bool((run_off[1:] > run_off[:-1]).all()):
            raise GrammarError("run_off must give every expert a positive, ordered run range")
    else:
        word_width = int(words_all.shape[1])
        expected_off = torch.arange(experts, device=word_off.device, dtype=word_off.dtype) * word_width
        if not bool((word_off == expected_off).all()):
            raise GrammarError("word_off must be the uniform per-expert word stride")
    shapes = [("perm_all", perm_all, (experts, cols)), ("init_all", init_all, (experts, cols))]
    if not e2m1:
        shapes.insert(0, ("scale_all", scale_all, (experts, rows)))
    for name, t, shape in shapes:
        if tuple(t.shape) != shape:
            raise GrammarError(f"{name} must be {shape}, got {tuple(t.shape)}")
    if e2m1:
        if rows % 2 or cols % 16:
            raise GrammarError(
                f"an E2M1x2 stack is whole tuples over whole 16-column scale groups: rows "
                f"{rows} must be even and cols {cols} a multiple of 16")
        for name, t, shape, dtype in (
                ("codes_all", codes_all, (experts, 1 << window_bits), torch.uint8),
                # two rows' nibbles per byte for each 16-column group
                ("scale_plane_all", scale_plane_all, (experts, rows * (cols // 16) // 2),
                 torch.uint8),
                ("scale_lut_all", scale_lut_all, (experts, 16), torch.uint8),
                ("global_all", global_all, (experts,), torch.float32)):
            if tuple(t.shape) != shape or t.dtype != dtype:
                raise GrammarError(
                    f"{name} must be {dtype} {shape}, got {t.dtype} {tuple(t.shape)}")
    elif family == "value":
        if tuple(table_all.shape) != (experts, 1 << window_bits) or table_all.dtype != torch.bfloat16:
            raise GrammarError(
                f"table_all must be bf16 [E, {1 << window_bits}], got "
                f"{table_all.dtype} {tuple(table_all.shape)}")
    else:
        if tuple(codes_all.shape) != (experts, 1 << window_bits) or codes_all.dtype != torch.uint8:
            raise GrammarError("codes_all must be uint8 [E, 2^L]")
        if tuple(native_all.shape) != (experts, 256) or native_all.dtype != torch.uint8:
            raise GrammarError("native_all must be uint8 [E, 256]")
    return PreparedGroupedWindowGemm(
        words_all=words_all, table_all=table_all, codes_all=codes_all, native_all=native_all,
        scale_all=scale_all, runs_all=runs_all, init_all=init_all, has_init=has_init,
        word_off=word_off, tile_words=tile_words, total_words=total_words, run_off=run_off,
        perm_all=perm_all, rows=rows, cols=cols, experts=experts, window_bits=window_bits,
        family=family, block_m=block_m, block_n=block_n, block_k=block_k,
        quantizer=quantizer if family == "e4m3" else "native", arithmetic=arithmetic,
        scale_plane_all=scale_plane_all, scale_lut_all=scale_lut_all, global_all=global_all,
        word_layout=str(word_layout),
    )


def routing_ids_ok(expert_ids: torch.Tensor, experts: int) -> torch.Tensor:
    """A device predicate: every id in ``[0, experts)``.  No synchronisation;
    the caller reads it when it chooses (never on the hot path)."""
    return ((expert_ids >= 0) & (expert_ids < experts)).all()


def prepare_grouped_window_gemm(
    units: Sequence[WindowGemvUnit],
    *,
    initial_state: torch.Tensor | None = None,
    block_m: int = 64,
    block_n: int = 64,
    block_k: int = 64,
    quantizer: str | None = "native",
    arithmetic: str = "epilogue",
) -> PreparedGroupedWindowGemm:
    """Validate every unit once and freeze the SoA stack.

    ``initial_state`` may be ``[E, cols]`` int32 in original column order (one
    row per expert); a unit's own ``initial_state`` field is used where the
    stack does not carry a row.  Families, ``cols``, ``rows`` and
    ``window_bits`` must agree across the stack, and so must the block sizes.

    ``arithmetic`` names the weight-side contract, once and explicitly:

    * ``"epilogue"`` (default): the row scale multiplies the fp32
      accumulator after the dot;
    * ``"folded"``: the BF16 contract (dense and routed, production and
      research-selected; tessera#614), exactly
      ``bf16_route.decode_folded``'s ``(values.float() * scale[:, :, None])
      .to(torch.bfloat16)`` -- one bf16 rounding of (value * row scale) in
      registers, before ``tl.dot``, and no scale in the epilogue.  The FP8
      family has no folded form (its per-token A quant and row-scale epilogue
      are the published contract), so ``"folded"`` is refused there.
    """
    if arithmetic not in ("epilogue", "folded"):
        raise GrammarError(f"unknown weight arithmetic {arithmetic!r}")
    units = list(units)
    if not units:
        raise GrammarError("a grouped stack needs at least one expert")
    prepared = []
    for e, unit in enumerate(units):
        row = None if initial_state is None else initial_state[e]
        # The per-expert bundles carry the stack's arithmetic, so no object in
        # the stack states a second answer (and an E4M3 unit refuses "folded").
        prepared.append(prepare_window_gemm(
            unit, initial_state=row, block_m=block_m, block_n=block_n, block_k=block_k,
            quantizer=quantizer, arithmetic=arithmetic,
        ))
    first = prepared[0]
    for e, p in enumerate(prepared[1:], start=1):
        for name in ("family", "cols", "rows", "window_bits"):
            if getattr(p, name) != getattr(first, name):
                raise GrammarError(
                    f"expert {e}: {name}={getattr(p, name)} differs from expert 0's "
                    f"{getattr(first, name)}; a grouped stack is homogeneous"
                )
        if str(getattr(p, "word_layout", "legacy")) != str(getattr(first, "word_layout", "legacy")):
            raise GrammarError(
                f"expert {e}: word_layout {getattr(p, 'word_layout', 'legacy')!r} differs from "
                f"expert 0's {getattr(first, 'word_layout', 'legacy')!r}; one grouped stack "
                "needs one resident word order")
    device = first.device
    if arithmetic == "folded" and first.family != "value":
        raise GrammarError(
            "the folded weight arithmetic is the BF16 (value family) contract; the E4M3 "
            "family keeps the per-token A quant and the row-scale epilogue"
        )
    run_lengths = torch.tensor([p.runs.numel() // 4 for p in prepared], dtype=torch.int32)
    run_off = torch.cat([torch.zeros(1, dtype=torch.int32), torch.cumsum(run_lengths, 0)])
    word_sizes = torch.tensor([p.words.numel() for p in prepared], dtype=torch.int32)
    word_off = torch.cat([torch.zeros(1, dtype=torch.int32), torch.cumsum(word_sizes, 0)[:-1]])
    return PreparedGroupedWindowGemm(
        words_all=torch.cat([p.words for p in prepared]).contiguous(),
        table_all=torch.stack([p.table for p in prepared]).contiguous(),
        codes_all=torch.stack([p.codes for p in prepared]).contiguous(),
        native_all=torch.stack([p.native for p in prepared]).contiguous(),
        scale_all=torch.stack([p.scale for p in prepared]).contiguous(),
        runs_all=torch.cat([p.runs for p in prepared]).contiguous(),
        init_all=torch.stack([p.init_perm for p in prepared]).contiguous(),
        has_init=torch.tensor([1 if p.has_init else 0 for p in prepared],
                              dtype=torch.int32, device=device),
        word_off=word_off.to(device),
        tile_words=torch.tensor([p.tile_words for p in prepared], dtype=torch.int32, device=device),
        total_words=torch.tensor([p.total_words for p in prepared], dtype=torch.int32, device=device),
        run_off=run_off.to(device),
        perm_all=torch.stack([p.perm for p in prepared]).contiguous(),
        rows=first.rows,
        cols=first.cols,
        experts=len(prepared),
        window_bits=first.window_bits,
        family=first.family,
        block_m=block_m,
        block_n=block_n,
        block_k=block_k,
        quantizer=quantizer if first.family == "e4m3" else "native",
        arithmetic=arithmetic,
        word_layout=str(getattr(first, "word_layout", "legacy")),
    )
